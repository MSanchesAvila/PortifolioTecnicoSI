# 🌐 Security Learning Hub

Hub visual de aprendizado em cibersegurança — funciona localmente e como site público via GitHub Pages.

## Acesso local

Basta abrir o `index.html` no navegador. Sem servidor, sem dependências.

## Publicar no GitHub Pages (acesso de qualquer lugar)

```bash
# 1. Crie um repositório público no GitHub chamado "security-hub"
# 2. Clone e suba os arquivos
git init
git add index.html README.md
git commit -m "feat: security learning hub"
git remote add origin https://github.com/<seu-usuario>/security-hub.git
git push -u origin main

# 3. No GitHub: Settings → Pages → Source: "main" → / (root) → Save
# 4. Seu hub estará em: https://<seu-usuario>.github.io/security-hub/
```

## Atualizar os links dos repositórios

No `index.html`, localize as linhas do sidebar com `openUrl('https://github.com')` e substitua pela URL real de cada repositório.

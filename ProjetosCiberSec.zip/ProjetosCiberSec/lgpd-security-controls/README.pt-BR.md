# 🔒 lgpd-security-controls

> 🇧🇷 Leia em Português | [🇺🇸 Read in English](README.md)

Controles técnicos, templates de políticas e guias de implementação para conformidade com a **LGPD — Lei Geral de Proteção de Dados** (Lei nº 13.709/2018).

Este repositório traduz os requisitos da LGPD em controles concretos que equipes de segurança e privacidade podem implementar, auditar e documentar.

---

## 📂 Estrutura

```
lgpd-security-controls/
├── checklist/
│   └── lgpd_technical_checklist.md   # 61 controles técnicos auditáveis
├── policies/
│   ├── privacy_policy_template.md    # Template de Política de Privacidade
│   └── data_retention_policy.md      # Política de retenção e descarte
├── controls/
│   ├── access_control.md             # Controles de acesso (Art. 46)
│   ├── encryption_standards.md       # Padrões de criptografia
│   └── incident_response.md          # Resposta a incidentes e notificação (Art. 48)
└── scripts/
    └── data_inventory.py             # Inventário de dados pessoais (Art. 37)
```

---

## 🗺️ Mapeamento LGPD → Controles

| Artigo | Tema | Controles Implementados |
|--------|------|------------------------|
| Art. 6 | Princípios | Minimização de dados, limitação de finalidade |
| Art. 7–11 | Bases legais e consentimento | Mecanismo de coleta, registro, revogação |
| Art. 14 | Dados de crianças | Consentimento parental, fluxos específicos |
| Art. 15–16 | Encerramento do tratamento | Política de retenção e descarte seguro |
| Art. 18 | Direitos do titular | Processo DSR, prazos, portabilidade |
| Art. 37 | Registro das operações | Inventário de ativos de dados pessoais |
| Art. 39–40 | Operadores (terceiros) | DPA, avaliação de segurança, cadeia de sub-operadores |
| Art. 46 | Medidas de segurança | Controle de acesso, criptografia, auditoria |
| Art. 48 | Incidentes de segurança | Processo de notificação à ANPD |
| Art. 50 | Governança | DPO, Privacy by Design, DPIA |

---

## 📋 Como Usar Este Repositório

### 1. Avalie sua postura atual
Comece pelo checklist em `checklist/lgpd_technical_checklist.md`. São **61 controles** organizados em 10 seções, cada um com campo de status (✅ / 🔄 / ❌) e espaço para observações. Use como workpaper de auditoria interna ou para preparação de due diligence.

### 2. Adapte os templates de política
Os documentos em `policies/` são templates prontos para customizar com os dados da sua organização. Escritos em linguagem clara, com placeholders marcados.

### 3. Implemente os controles técnicos
Os arquivos em `controls/` detalham como implementar cada categoria de controle com critérios objetivos de conformidade e referências normativas (CIS, ISO 27001, ISO 27701).

### 4. Mapeie seus ativos de dados
```bash
# Carregar dados de demonstração para entender a estrutura
python scripts/data_inventory.py demo

# Adicionar uma atividade de tratamento interativamente
python scripts/data_inventory.py add

# Listar todos os ativos mapeados
python scripts/data_inventory.py list

# Gerar relatório de riscos (ativos sem base legal, sem retenção definida, dados sensíveis)
python scripts/data_inventory.py report

# Exportar para CSV (Excel-compatível)
python scripts/data_inventory.py export -o inventario.csv
```

---

## 🛠️ Ferramenta: Inventário de Dados (`data_inventory.py`)

Implementa o **Registro das Operações de Tratamento** exigido pelo Art. 37 da LGPD.

Para cada atividade de tratamento, documenta:

| Campo | Exemplo |
|-------|---------|
| Nome da atividade | "Cadastro de clientes" |
| Sistema/aplicação | "CRM, Portal Web" |
| Base legal | `contract`, `consent`, `legal_obligation` |
| Categorias de dados | `identification`, `financial`, `health` |
| Titulares | "clientes, colaboradores" |
| Período de retenção | "5 anos após último pedido" |
| Operadores terceiros | "Transportadora X, Gateway de Pagamento Y" |
| Finalidade | "Processamento de pedidos e entrega" |

**Dados sensíveis (Art. 11)** são sinalizados automaticamente: saúde, biometria, origem racial/étnica, convicção religiosa, opinião política, orientação sexual e dados de crianças.

**Relatório de risco** aponta:
- Atividades sem base legal documentada
- Atividades sem período de retenção definido
- Quantidade de ativos com dados sensíveis
- Atividades compartilhadas com terceiros

---

## 📄 Processo de Resposta a Incidentes (Art. 48)

O arquivo `controls/incident_response.md` detalha o processo completo alinhado à **Resolução CD/ANPD nº 4/2023**, incluindo:

**Classificação de severidade:**

| Nível | Critério | Notificação ANPD | Notificação Titulares |
|-------|----------|------------------|-----------------------|
| Crítico | Dados sensíveis expostos, grande escala | Sim — 3 dias úteis | Sim — imediatamente |
| Alto | Dados pessoais com risco moderado de dano | Sim — 3 dias úteis | Sim — se dano provável |
| Médio | Exposição limitada, baixo risco | Sim — 3 dias úteis | Avaliar com o DPO |
| Baixo | Incidente interno, sem exposição externa | Avaliar com DPO | Geralmente não |

**5 fases do processo:**
1. Detecção e triagem (0–4h)
2. Avaliação e contenção (4–24h)
3. Notificação ANPD e titulares (24–72h)
4. Remediação e recuperação
5. Revisão pós-incidente (PIR)

---

## 📊 Pontuação do Checklist

O checklist possui **61 controles** distribuídos em 10 seções. Ao final de cada avaliação, você preenche a tabela de pontuação:

| Seção | Controles | Implementados | Parcial | Gap |
|-------|-----------|---------------|---------|-----|
| Governança | 6 | | | |
| Mapeamento de Dados | 6 | | | |
| Consentimento | 5 | | | |
| Direitos do Titular | 8 | | | |
| Controle de Acesso | 7 | | | |
| Criptografia | 6 | | | |
| Logs e Auditoria | 6 | | | |
| Resposta a Incidentes | 7 | | | |
| Terceiros | 5 | | | |
| Retenção | 5 | | | |
| **TOTAL** | **61** | | | |

---

## 🔗 Referências Normativas

- [Lei nº 13.709/2018 — LGPD](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709.htm)
- [ANPD — Autoridade Nacional de Proteção de Dados](https://www.gov.br/anpd)
- [Resolução CD/ANPD nº 4/2023 — Regulamento de Incidentes](https://www.gov.br/anpd/pt-br/documentos-e-publicacoes/resolucao-cd_anpd-no-4-de-24-de-fevereiro-de-2023.pdf)
- [ISO/IEC 27701:2019 — Privacy Information Management](https://www.iso.org/standard/71670.html)
- [ISO/IEC 27001:2022 — Information Security Management](https://www.iso.org/standard/27001)
- [NIST Privacy Framework](https://www.nist.gov/privacy-framework)

---

## ⚠️ Aviso

Este repositório é para fins de referência e suporte técnico. Os templates e controles **não constituem aconselhamento jurídico**. Para decisões de conformidade, consulte seu DPO e assessoria jurídica especializada em proteção de dados.

---

## 👨‍💻 Autor

**Matheus Sanches**  
Especialista em Cibersegurança & Privacidade | [SecureScope AI](https://securescopeai.com)  
📧 matheus.sanches@securescopeai.com

---

## 📄 Licença

MIT License — templates livres para adaptar à sua organização com atribuição.

#!/usr/bin/env python3
"""
data_inventory.py — Personal data asset mapping tool for LGPD compliance
Helps security/privacy teams document processing activities (Art. 37 LGPD)
Part of: lgpd-security-controls
Author: Matheus Sanches | securescopeai.com
"""

import json
import csv
import argparse
from datetime import datetime
from pathlib import Path


LEGAL_BASES = [
    "consent",
    "contract",
    "legal_obligation",
    "vital_interests",
    "public_policy",
    "legitimate_interest",
]

DATA_CATEGORIES = [
    "identification",        # name, CPF, RG, email
    "contact",               # phone, address
    "financial",             # bank data, credit card
    "health",                # medical records (sensitive - Art. 11)
    "biometric",             # fingerprint, face (sensitive)
    "racial_ethnic",         # sensitive - Art. 11
    "religious",             # sensitive - Art. 11
    "political",             # sensitive - Art. 11
    "sexual_orientation",    # sensitive - Art. 11
    "behavioral",            # browsing, purchase history
    "professional",          # employment, performance
    "location",              # GPS, IP address
    "children",              # data of minors (Art. 14)
]

SENSITIVE_CATEGORIES = {
    "health", "biometric", "racial_ethnic", "religious",
    "political", "sexual_orientation", "children"
}


class DataInventory:
    def __init__(self, inventory_file: str = "data_inventory.json"):
        self.path = Path(inventory_file)
        self.inventory: list[dict] = []
        if self.path.exists():
            with open(self.path) as f:
                self.inventory = json.load(f)

    def save(self):
        with open(self.path, "w") as f:
            json.dump(self.inventory, f, indent=2, ensure_ascii=False)
        print(f"[*] Inventory saved to {self.path}")

    def add_asset(self, asset: dict):
        asset["id"] = f"ASSET-{len(self.inventory) + 1:04d}"
        asset["created_at"] = datetime.now().isoformat()
        asset["is_sensitive"] = any(
            c in SENSITIVE_CATEGORIES for c in asset.get("data_categories", [])
        )
        self.inventory.append(asset)
        print(f"[+] Asset added: {asset['id']} — {asset['name']}")

    def list_assets(self):
        if not self.inventory:
            print("No assets in inventory.")
            return
        print(f"\n{'ID':<12} {'Name':<30} {'Sensitive':<10} {'Legal Basis':<20} {'Retention'}")
        print("─" * 90)
        for a in self.inventory:
            sensitive = "⚠️  YES" if a.get("is_sensitive") else "No"
            print(
                f"{a['id']:<12} {a['name']:<30} {sensitive:<15} "
                f"{a.get('legal_basis','?'):<20} {a.get('retention_period','?')}"
            )
        print()

    def risk_report(self):
        total = len(self.inventory)
        sensitive_count = sum(1 for a in self.inventory if a.get("is_sensitive"))
        missing_basis = [a for a in self.inventory if not a.get("legal_basis")]
        no_retention = [a for a in self.inventory if not a.get("retention_period")]
        shared_processors = [a for a in self.inventory if a.get("third_party_processors")]

        print("\n" + "═" * 55)
        print("  LGPD DATA INVENTORY RISK REPORT")
        print("═" * 55)
        print(f"  Total assets         : {total}")
        print(f"  Sensitive data assets: {sensitive_count} {'⚠️' if sensitive_count > 0 else '✅'}")
        print(f"  Missing legal basis  : {len(missing_basis)} {'⚠️' if missing_basis else '✅'}")
        print(f"  No retention defined : {len(no_retention)} {'⚠️' if no_retention else '✅'}")
        print(f"  Third-party sharing  : {len(shared_processors)}")

        if missing_basis:
            print("\n  ⚠️  Assets without legal basis:")
            for a in missing_basis:
                print(f"    • {a['id']} — {a['name']}")

        if no_retention:
            print("\n  ⚠️  Assets without retention period:")
            for a in no_retention:
                print(f"    • {a['id']} — {a['name']}")

        print("═" * 55 + "\n")

    def export_csv(self, output_file: str):
        if not self.inventory:
            print("No data to export.")
            return
        fields = ["id", "name", "system", "legal_basis", "data_categories",
                  "retention_period", "is_sensitive", "third_party_processors",
                  "data_subjects", "created_at"]
        with open(output_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for asset in self.inventory:
                row = asset.copy()
                # Flatten lists to strings for CSV
                for field in ("data_categories", "third_party_processors", "data_subjects"):
                    if isinstance(row.get(field), list):
                        row[field] = "; ".join(row[field])
                writer.writerow(row)
        print(f"[*] CSV exported to {output_file}")


def interactive_add(inventory: DataInventory):
    print("\n─── Add Processing Activity ───")
    name = input("Activity name (e.g. 'Customer registration'): ").strip()
    system = input("System/application (e.g. 'CRM', 'Website'): ").strip()

    print(f"\nLegal bases: {', '.join(LEGAL_BASES)}")
    legal_basis = input("Legal basis: ").strip()

    print(f"\nCategories: {', '.join(DATA_CATEGORIES)}")
    cats_input = input("Data categories (comma-separated): ").strip()
    categories = [c.strip() for c in cats_input.split(",") if c.strip() in DATA_CATEGORIES]

    subjects = input("Data subjects (e.g. 'customers, employees'): ").strip()
    subjects_list = [s.strip() for s in subjects.split(",")]

    retention = input("Retention period (e.g. '5 years', '12 months after contract end'): ").strip()

    processors = input("Third-party processors (comma-separated, or leave blank): ").strip()
    processors_list = [p.strip() for p in processors.split(",") if p.strip()]

    purpose = input("Processing purpose: ").strip()

    asset = {
        "name": name,
        "system": system,
        "legal_basis": legal_basis,
        "data_categories": categories,
        "data_subjects": subjects_list,
        "retention_period": retention,
        "third_party_processors": processors_list,
        "purpose": purpose,
    }

    inventory.add_asset(asset)
    inventory.save()


def seed_demo(inventory: DataInventory):
    """Add sample assets for demonstration."""
    samples = [
        {
            "name": "Customer Registration",
            "system": "E-commerce Platform",
            "legal_basis": "contract",
            "data_categories": ["identification", "contact", "financial"],
            "data_subjects": ["customers"],
            "retention_period": "5 years after last purchase",
            "third_party_processors": ["Payment Gateway Inc", "Shipping Co"],
            "purpose": "Order processing and delivery",
        },
        {
            "name": "Employee Health Records",
            "system": "HR System",
            "legal_basis": "legal_obligation",
            "data_categories": ["identification", "health"],
            "data_subjects": ["employees"],
            "retention_period": "20 years (CIPA requirement)",
            "third_party_processors": ["Occupational Health Clinic"],
            "purpose": "Occupational health compliance",
        },
        {
            "name": "Website Analytics",
            "system": "Analytics Platform",
            "legal_basis": "consent",
            "data_categories": ["behavioral", "location"],
            "data_subjects": ["website visitors"],
            "retention_period": "13 months",
            "third_party_processors": ["Analytics Vendor"],
            "purpose": "Website performance and UX improvement",
        },
    ]
    for s in samples:
        inventory.add_asset(s)
    inventory.save()
    print("[*] Demo data loaded successfully.")


def main():
    parser = argparse.ArgumentParser(description="LGPD Personal Data Inventory Tool")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List all data assets")
    sub.add_parser("add", help="Interactively add a new processing activity")
    sub.add_parser("report", help="Show risk report")
    sub.add_parser("demo", help="Load demo data")
    export_p = sub.add_parser("export", help="Export to CSV")
    export_p.add_argument("-o", "--output", default="data_inventory.csv")

    parser.add_argument("-f", "--file", default="data_inventory.json", help="Inventory JSON file")
    args = parser.parse_args()

    inventory = DataInventory(args.file)

    if args.command == "list":
        inventory.list_assets()
    elif args.command == "add":
        interactive_add(inventory)
    elif args.command == "report":
        inventory.risk_report()
    elif args.command == "demo":
        seed_demo(inventory)
    elif args.command == "export":
        inventory.export_csv(args.output)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

# Incident Response — LGPD Breach Notification (Art. 48)

**Reference:** LGPD Art. 48 + ANPD Resolução CD/ANPD nº 4/2023

---

## Scope

This document defines the process for detecting, classifying, responding to, and notifying data breaches involving personal data, in compliance with Art. 48 of the LGPD.

---

## 1. Breach Definition (LGPD Art. 48)

A data breach is any **accidental or unlawful** event that results in:

- **Unauthorized access** to personal data
- **Accidental or unlawful destruction** of personal data
- **Loss, alteration, communication, or disclosure** of personal data

> Note: Not every security incident is a breach. Only those affecting personal data trigger LGPD notification obligations.

---

## 2. Breach Severity Classification

| Level | Criteria | ANPD Notification | Data Subject Notification |
|-------|----------|-------------------|--------------------------|
| **Critical** | Sensitive data (Art. 11), financial data, credentials exposed. Large scale or high harm potential. | Yes — within 3 business days | Yes — promptly |
| **High** | Personal data exposed with moderate harm risk (identity theft, discrimination) | Yes — within 3 business days | Yes — if harm likely |
| **Medium** | Limited exposure, low harm potential, pseudonymized data | Yes — within 3 business days | Evaluate per case |
| **Low** | Internal incident, no external exposure, minimal risk | Evaluate with DPO | Generally not required |

---

## 3. Incident Response Steps

### Phase 1 — Detection & Triage (0–4 hours)

- [ ] Security team identifies potential breach
- [ ] Initial triage: is personal data involved?
- [ ] Incident ticket opened (assign unique ID, timestamp)
- [ ] DPO immediately notified
- [ ] Containment measures initiated (isolate system, revoke access, etc.)

### Phase 2 — Assessment (4–24 hours)

- [ ] Identify what personal data was affected
- [ ] Estimate number of data subjects impacted
- [ ] Determine cause (technical failure, attack, human error, etc.)
- [ ] Assess harm potential: financial, reputational, physical, psychological
- [ ] Classify breach severity (Critical / High / Medium / Low)
- [ ] Preserve evidence (logs, forensic copies)

### Phase 3 — Notification (24–72 hours)

#### ANPD Notification (Art. 48 + Resolução nº 4/2023)

Required information:
- Description of the nature of the breach
- Categories and approximate number of affected data subjects
- Categories and approximate volume of personal data records affected
- Contact details of the DPO
- Likely consequences of the breach
- Measures taken or proposed to address and mitigate the breach

Submit via: [Portal Gov.br – ANPD](https://www.gov.br/anpd)

#### Data Subject Notification

Notify affected individuals when the breach is **likely to result in significant risk or damage**. Include:
- What happened (in plain language)
- What data was involved
- Potential consequences
- Measures taken to protect them
- How to contact the DPO / exercise rights

### Phase 4 — Remediation & Recovery

- [ ] Root cause analysis (RCA) completed
- [ ] Technical and procedural fixes implemented
- [ ] Affected systems restored and validated
- [ ] Additional monitoring deployed if needed

### Phase 5 — Post-Incident Review

- [ ] PIR meeting within 5 business days of resolution
- [ ] Lessons learned documented
- [ ] Checklist and procedures updated
- [ ] Breach register updated with final details

---

## 4. Breach Register Template

| Field | Value |
|-------|-------|
| Incident ID | INC-YYYY-XXX |
| Detection Date | |
| Reported by | |
| Data Types Affected | |
| Number of Data Subjects | |
| Cause | |
| Severity | |
| ANPD Notified | Yes / No / N/A |
| ANPD Notification Date | |
| Data Subjects Notified | Yes / No / N/A |
| Remediation Completed | |
| PIR Completed | |
| PIR Notes | |

---

## 5. Key Contacts

| Role | Name | Contact |
|------|------|---------|
| DPO (Encarregado) | | |
| Security Lead | | |
| Legal Counsel | | |
| CISO / IT Director | | |
| PR / Communications | | |

---

## References

- LGPD Art. 48: https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709.htm#art48
- ANPD Resolução CD/ANPD nº 4/2023 (Regulamento de Comunicação de Incidentes de Segurança)
- ENISA Guidelines on Personal Data Breach Notification

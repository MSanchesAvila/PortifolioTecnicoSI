# 🔒 lgpd-security-controls

Technical controls, policy templates, and implementation guides for LGPD (Lei Geral de Proteção de Dados) compliance — Brazil's data protection law (Law 13.709/2018).

> This repository maps LGPD requirements to concrete technical and organizational controls that security teams can implement and audit.

---

## Structure

```
lgpd-security-controls/
├── checklist/
│   └── lgpd_technical_checklist.md   # Full technical controls checklist
├── policies/
│   ├── privacy_policy_template.md    # Privacy policy template (pt-BR)
│   └── data_retention_policy.md      # Data retention and disposal policy
├── controls/
│   ├── access_control.md             # Access control controls (Art. 46)
│   ├── encryption_standards.md       # Encryption standards and requirements
│   └── incident_response.md          # Breach notification (Art. 48)
└── scripts/
    └── data_inventory.py             # Script to help map personal data assets
```

---

## LGPD Key Articles → Controls Mapping

| Article | Topic | Controls Implemented |
|---------|-------|---------------------|
| Art. 6  | Principles | Data minimization, purpose limitation |
| Art. 18 | Data Subject Rights | DSR process, deletion workflows |
| Art. 37 | Data Mapping | Asset inventory, data flows |
| Art. 46 | Security Measures | Access control, encryption, audit logs |
| Art. 48 | Breach Notification | Incident response, ANPD reporting |
| Art. 50 | Governance | DPO role, privacy by design |

---

## How to Use

1. Start with `checklist/lgpd_technical_checklist.md` to assess your current posture
2. Adapt `policies/` templates to your organization
3. Implement `controls/` as technical safeguards
4. Run `scripts/data_inventory.py` to map personal data in your systems

---

## References

- [LGPD — Lei nº 13.709/2018](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709.htm)
- [ANPD — Autoridade Nacional de Proteção de Dados](https://www.gov.br/anpd)
- [NIST Privacy Framework](https://www.nist.gov/privacy-framework)
- [ISO/IEC 27701:2019](https://www.iso.org/standard/71670.html)

---

## Author

**Matheus Sanches** — [@securescopeai](https://github.com/securescopeai)  
SecureScope AI | matheus.sanches@securescopeai.com

---

## License

MIT License — templates are free to adapt for your organization.

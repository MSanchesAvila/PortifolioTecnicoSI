# LGPD Technical Controls Checklist

**Version:** 1.0  
**Reference:** Lei nº 13.709/2018 (LGPD) + ANPD Guidelines  
**Last updated:** 2025

---

## How to Use

Rate each control:
- ✅ **Implemented** — fully in place
- 🔄 **Partial** — in progress or partially implemented  
- ❌ **Not implemented** — gap to be addressed
- N/A — not applicable to your context

---

## 1. Data Governance (Art. 50)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 1.1 | DPO (Encarregado) formally appointed and published | | |
| 1.2 | Privacy policy publicly available and up to date | | |
| 1.3 | Privacy by design applied to new projects | | |
| 1.4 | Periodic privacy risk assessments (DPIA) conducted | | |
| 1.5 | Staff trained on LGPD annually | | |
| 1.6 | Privacy governance committee or responsibility defined | | |

---

## 2. Data Mapping & Inventory (Art. 37)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 2.1 | Complete inventory of personal data assets maintained | | |
| 2.2 | Legal basis documented for each processing activity | | |
| 2.3 | Data flows mapped (collection → processing → storage → deletion) | | |
| 2.4 | Third-party processors (operadores) identified and contracted | | |
| 2.5 | Sensitive data (Art. 11) inventoried separately | | |
| 2.6 | International data transfers identified and controlled | | |

---

## 3. Consent & Legal Basis (Art. 7–11)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 3.1 | Consent collection mechanism is specific, informed, free, and unambiguous | | |
| 3.2 | Consent can be withdrawn as easily as it was given | | |
| 3.3 | Legal basis (besides consent) documented where applicable | | |
| 3.4 | Consent records stored with timestamp and version of privacy notice | | |
| 3.5 | Children's data processing complies with Art. 14 (parental consent) | | |

---

## 4. Data Subject Rights (Art. 18)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 4.1 | Process defined to handle data subject requests (DSR) | | |
| 4.2 | Response time SLA ≤ 15 days (ANPD recommendation) | | |
| 4.3 | Right to access: subject can receive copy of their data | | |
| 4.4 | Right to correction: data can be updated upon request | | |
| 4.5 | Right to deletion: data can be erased (with exceptions) | | |
| 4.6 | Right to portability: data exportable in structured format | | |
| 4.7 | Right to object: processing can be contested | | |
| 4.8 | DSR log maintained for accountability | | |

---

## 5. Access Control (Art. 46)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 5.1 | Role-based access control (RBAC) implemented | | |
| 5.2 | Principle of least privilege enforced | | |
| 5.3 | MFA required for systems processing personal data | | |
| 5.4 | Access reviews conducted at least quarterly | | |
| 5.5 | Privileged access managed and monitored (PAM) | | |
| 5.6 | Access revoked within 24h of employee departure | | |
| 5.7 | Shared accounts prohibited for personal data systems | | |

---

## 6. Encryption & Data Protection (Art. 46)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 6.1 | Personal data encrypted at rest (AES-256 or equivalent) | | |
| 6.2 | Personal data encrypted in transit (TLS 1.2+ enforced) | | |
| 6.3 | Encryption keys managed separately from data | | |
| 6.4 | Backups encrypted and tested regularly | | |
| 6.5 | Pseudonymization applied where full anonymization is not possible | | |
| 6.6 | Anonymized data confirmed irreversible before treating as non-personal | | |

---

## 7. Audit Logging & Monitoring (Art. 46)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 7.1 | Access to personal data systems logged | | |
| 7.2 | Logs include: who, what, when, from where | | |
| 7.3 | Log integrity protected (immutable storage or WORM) | | |
| 7.4 | Logs retained for minimum 12 months | | |
| 7.5 | Anomaly detection / SIEM alerting in place | | |
| 7.6 | Unauthorized access attempts alerted and investigated | | |

---

## 8. Incident Response & Breach Notification (Art. 48)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 8.1 | Incident response plan documented and tested | | |
| 8.2 | Data breach definition and classification criteria defined | | |
| 8.3 | ANPD notification process defined (Art. 48: reasonable timeframe) | | |
| 8.4 | Affected data subjects notified when risk/damage likely | | |
| 8.5 | Breach incident register maintained | | |
| 8.6 | Post-incident review (PIR) process defined | | |
| 8.7 | DPO included in breach escalation path | | |

---

## 9. Third-Party Management (Art. 39–40)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 9.1 | Data Processing Agreement (DPA) in place with all processors | | |
| 9.2 | Processor security posture assessed before onboarding | | |
| 9.3 | Processor access limited to necessary data only | | |
| 9.4 | Sub-processor (sub-operador) chain documented | | |
| 9.5 | Annual review of processor compliance | | |

---

## 10. Retention & Disposal (Art. 15–16)

| # | Control | Status | Notes |
|---|---------|--------|-------|
| 10.1 | Retention schedule defined for each data category | | |
| 10.2 | Automated deletion / anonymization triggers configured | | |
| 10.3 | Secure disposal method applied (DoD 5220.22-M or equivalent) | | |
| 10.4 | Disposal records maintained | | |
| 10.5 | Data retained beyond purpose only with explicit legal basis | | |

---

## Scoring Summary

| Section | Controls | Implemented | Partial | Gap |
|---------|----------|-------------|---------|-----|
| 1. Governance | 6 | | | |
| 2. Data Mapping | 6 | | | |
| 3. Consent | 5 | | | |
| 4. Data Subject Rights | 8 | | | |
| 5. Access Control | 7 | | | |
| 6. Encryption | 6 | | | |
| 7. Audit Logging | 6 | | | |
| 8. Incident Response | 7 | | | |
| 9. Third-Party | 5 | | | |
| 10. Retention | 5 | | | |
| **TOTAL** | **61** | | | |

---

*This checklist is for self-assessment purposes. It does not constitute legal advice. Consult your DPO and legal counsel for compliance decisions.*

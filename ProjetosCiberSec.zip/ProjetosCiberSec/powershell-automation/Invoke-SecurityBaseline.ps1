<#
.SYNOPSIS
    Checks Windows security baseline settings (CIS Benchmark-aligned).

.DESCRIPTION
    Invoke-SecurityBaseline.ps1 evaluates the local machine against common
    security hardening controls inspired by CIS Microsoft Windows Benchmarks.
    Covers: password policy, audit policy, network settings, services, registry.

.PARAMETER Category
    Check only one category: PasswordPolicy | AuditPolicy | NetworkSecurity |
    Services | RegistryHardening | All (default: All)

.PARAMETER ExportHTML
    Path to save an HTML report

.PARAMETER ExportCSV
    Path to save results as CSV

.EXAMPLE
    .\Invoke-SecurityBaseline.ps1
    .\Invoke-SecurityBaseline.ps1 -Category PasswordPolicy
    .\Invoke-SecurityBaseline.ps1 -ExportHTML .\baseline_report.html

.NOTES
    Requires: Run as Administrator
    Author: Matheus Sanches | securescopeai.com
#>

[CmdletBinding()]
param(
    [ValidateSet("PasswordPolicy","AuditPolicy","NetworkSecurity","Services","RegistryHardening","All")]
    [string]$Category = "All",
    [string]$ExportHTML,
    [string]$ExportCSV
)

Set-StrictMode -Version Latest
$results = @()

function Add-Check {
    param(
        [string]$Category,
        [string]$Control,
        [string]$Expected,
        [string]$Actual,
        [bool]$Pass,
        [string]$Severity = "Medium",
        [string]$Reference = ""
    )
    $script:results += [PSCustomObject]@{
        Category  = $Category
        Control   = $Control
        Expected  = $Expected
        Actual    = $Actual
        Status    = if ($Pass) { "PASS" } else { "FAIL" }
        Severity  = $Severity
        Reference = $Reference
    }
    $color = if ($Pass) { "Green" } else { if ($Severity -eq "High") { "Red" } else { "Yellow" } }
    $icon  = if ($Pass) { "[PASS]" } else { "[FAIL]" }
    Write-Host "  $icon [$Severity] $Control" -ForegroundColor $color
    if (-not $Pass) {
        Write-Host "         Expected: $Expected | Actual: $Actual" -ForegroundColor Gray
    }
}

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  Windows Security Baseline Audit" -ForegroundColor Cyan
Write-Host "  Host: $env:COMPUTERNAME | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
Write-Host "============================================`n" -ForegroundColor Cyan

# ── Password Policy ─────────────────────────────────────────────────────────────

if ($Category -in "PasswordPolicy","All") {
    Write-Host "[ Password Policy ]" -ForegroundColor Cyan
    try {
        $policy = net accounts 2>&1

        $minLen = ($policy | Select-String "Minimum password length").ToString() -replace "\D+","" -as [int]
        Add-Check "PasswordPolicy" "Minimum password length >= 14" ">= 14" "$minLen" ($minLen -ge 14) "High" "CIS 1.1.1"

        $maxAge = ($policy | Select-String "Maximum password age").ToString() -replace "\D+","" -as [int]
        Add-Check "PasswordPolicy" "Maximum password age <= 90 days" "<= 90" "$maxAge" ($maxAge -le 90 -and $maxAge -gt 0) "Medium" "CIS 1.1.2"

        $minAge = ($policy | Select-String "Minimum password age").ToString() -replace "\D+","" -as [int]
        Add-Check "PasswordPolicy" "Minimum password age >= 1 day" ">= 1" "$minAge" ($minAge -ge 1) "Low" "CIS 1.1.3"

        $history = ($policy | Select-String "Length of password history").ToString() -replace "\D+","" -as [int]
        Add-Check "PasswordPolicy" "Password history >= 24" ">= 24" "$history" ($history -ge 24) "Medium" "CIS 1.1.4"

        $lockout = ($policy | Select-String "Lockout threshold").ToString() -replace "\D+","" -as [int]
        Add-Check "PasswordPolicy" "Account lockout threshold <= 5 attempts" "<= 5 (not 0)" "$lockout" ($lockout -le 5 -and $lockout -gt 0) "High" "CIS 1.2.1"
    }
    catch { Write-Warning "Could not retrieve password policy: $_" }
}

# ── Audit Policy ────────────────────────────────────────────────────────────────

if ($Category -in "AuditPolicy","All") {
    Write-Host "`n[ Audit Policy ]" -ForegroundColor Cyan
    $auditCategories = @{
        "Account Logon"        = @("Success", "Failure")
        "Account Management"   = @("Success", "Failure")
        "Logon/Logoff"         = @("Success", "Failure")
        "Object Access"        = @("Failure")
        "Policy Change"        = @("Success")
        "Privilege Use"        = @("Failure")
        "System"               = @("Success", "Failure")
    }
    try {
        $auditOutput = auditpol /get /category:* 2>&1
        foreach ($cat in $auditCategories.Keys) {
            $line = $auditOutput | Select-String $cat | Select-Object -First 1
            if ($line) {
                $lineStr = $line.ToString()
                $requiredSettings = $auditCategories[$cat]
                $pass = $true
                foreach ($setting in $requiredSettings) {
                    if ($lineStr -notmatch $setting) { $pass = $false }
                }
                Add-Check "AuditPolicy" "Audit $cat" ($requiredSettings -join " & ") $lineStr.Trim() $pass "High" "CIS 17.x"
            }
        }
    }
    catch { Write-Warning "Could not retrieve audit policy. Run as Administrator." }
}

# ── Network Security ────────────────────────────────────────────────────────────

if ($Category -in "NetworkSecurity","All") {
    Write-Host "`n[ Network Security ]" -ForegroundColor Cyan

    # SMBv1
    try {
        $smb1 = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction SilentlyContinue
        $smb1Disabled = ($smb1.State -ne "Enabled")
        Add-Check "NetworkSecurity" "SMBv1 disabled" "Disabled" $(if ($smb1Disabled) {"Disabled"} else {"ENABLED"}) $smb1Disabled "High" "CIS 18.3.3"
    } catch {
        # Fallback via registry
        $smb1Reg = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name SMB1 -ErrorAction SilentlyContinue
        $smb1Disabled = ($smb1Reg.SMB1 -eq 0)
        Add-Check "NetworkSecurity" "SMBv1 disabled (registry)" "0" "$($smb1Reg.SMB1)" $smb1Disabled "High" "CIS 18.3.3"
    }

    # NTLMv2 enforcement
    $ntlm = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name LmCompatibilityLevel -ErrorAction SilentlyContinue
    $ntlmLevel = if ($ntlm) { $ntlm.LmCompatibilityLevel } else { 0 }
    Add-Check "NetworkSecurity" "NTLMv2 enforced (LmCompatibilityLevel >= 5)" ">= 5" "$ntlmLevel" ($ntlmLevel -ge 5) "High" "CIS 2.3.11.7"

    # Windows Firewall
    $fwProfiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue
    $allEnabled = ($fwProfiles | Where-Object { $_.Enabled -eq $false }).Count -eq 0
    Add-Check "NetworkSecurity" "Windows Firewall enabled (all profiles)" "Enabled" $(if ($allEnabled) {"All enabled"} else {"Some disabled"}) $allEnabled "High" "CIS 9.1.1"

    # Remote Registry
    $remoteReg = Get-Service -Name RemoteRegistry -ErrorAction SilentlyContinue
    $regDisabled = ($remoteReg.StartType -eq "Disabled")
    Add-Check "NetworkSecurity" "RemoteRegistry service disabled" "Disabled" "$($remoteReg.StartType)" $regDisabled "Medium" "CIS 5.x"
}

# ── Services ─────────────────────────────────────────────────────────────────────

if ($Category -in "Services","All") {
    Write-Host "`n[ Services ]" -ForegroundColor Cyan

    $riskySvcs = @{
        "Telnet"          = "Disabled"
        "FTPSVC"          = "Disabled"
        "TlntSvr"         = "Disabled"
        "SNMP"            = "Disabled"
        "RasMan"          = "Manual/Disabled"
        "RemoteAccess"    = "Disabled"
    }

    foreach ($svcName in $riskySvcs.Keys) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $disabled = ($svc.StartType -in "Disabled","Manual")
            Add-Check "Services" "$svcName service not running" $riskySvcs[$svcName] "$($svc.StartType) / $($svc.Status)" $disabled "Medium" "CIS 5.x"
        }
    }
}

# ── Registry Hardening ───────────────────────────────────────────────────────────

if ($Category -in "RegistryHardening","All") {
    Write-Host "`n[ Registry Hardening ]" -ForegroundColor Cyan

    $regChecks = @(
        @{
            Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
            Name = "EnableLUA"; Expected = 1; Desc = "UAC enabled"; Severity = "High"; Ref = "CIS 2.3.17.1"
        },
        @{
            Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
            Name = "ConsentPromptBehaviorAdmin"; Expected = 2; Desc = "UAC prompts for elevation"; Severity = "Medium"; Ref = "CIS 2.3.17.5"
        },
        @{
            Path = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
            Name = "RestrictAnonymous"; Expected = 1; Desc = "Restrict anonymous enumeration"; Severity = "High"; Ref = "CIS 2.3.10.2"
        },
        @{
            Path = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
            Name = "DisableDomainCreds"; Expected = 1; Desc = "Do not store credentials in Credential Manager"; Severity = "Medium"; Ref = "CIS 2.3.11.2"
        },
        @{
            Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
            Name = "NoAutoUpdate"; Expected = 0; Desc = "Automatic updates not disabled"; Severity = "High"; Ref = "CIS 18.9.x"
        },
        @{
            Path = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"
            Name = "RequireSignOrSeal"; Expected = 1; Desc = "Secure channel data encrypted/signed"; Severity = "Medium"; Ref = "CIS 2.3.6.1"
        }
    )

    foreach ($check in $regChecks) {
        try {
            $val = Get-ItemProperty -Path $check.Path -Name $check.Name -ErrorAction Stop
            $actual = $val.($check.Name)
            $pass = ($actual -eq $check.Expected)
            Add-Check "RegistryHardening" $check.Desc "= $($check.Expected)" "= $actual" $pass $check.Severity $check.Ref
        } catch {
            Add-Check "RegistryHardening" $check.Desc "= $($check.Expected)" "KEY NOT FOUND" $false $check.Severity $check.Ref
        }
    }
}

# ── Summary ─────────────────────────────────────────────────────────────────────

$pass  = ($results | Where-Object { $_.Status -eq "PASS" }).Count
$fail  = ($results | Where-Object { $_.Status -eq "FAIL" }).Count
$high  = ($results | Where-Object { $_.Status -eq "FAIL" -and $_.Severity -eq "High" }).Count
$score = if ($results.Count -gt 0) { [math]::Round(($pass / $results.Count) * 100, 1) } else { 0 }

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  BASELINE RESULTS" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Total checks  : $($results.Count)"
Write-Host "  Passed        : $pass" -ForegroundColor Green
Write-Host "  Failed        : $fail" -ForegroundColor $(if ($fail -gt 0) { "Red" } else { "Green" })
Write-Host "  High severity : $high" -ForegroundColor $(if ($high -gt 0) { "Red" } else { "Green" })
Write-Host "  Score         : $score%" -ForegroundColor $(if ($score -ge 80) { "Green" } elseif ($score -ge 60) { "Yellow" } else { "Red" })
Write-Host "============================================`n" -ForegroundColor Cyan

if ($ExportCSV) {
    $results | Export-Csv -Path $ExportCSV -NoTypeInformation -Encoding UTF8
    Write-Host "[*] CSV saved: $ExportCSV" -ForegroundColor Green
}

if ($ExportHTML) {
    $html = @"
<!DOCTYPE html><html><head><title>Security Baseline Report</title>
<style>
  body { font-family: Segoe UI, Arial; background: #1a1a2e; color: #eee; margin: 2em; }
  h1 { color: #00d4ff; } h2 { color: #aaa; font-size: 1em; }
  table { border-collapse: collapse; width: 100%; }
  th { background: #0f3460; color: #00d4ff; padding: 8px; text-align:left; }
  td { padding: 8px; border-bottom: 1px solid #333; font-size: 0.9em; }
  .PASS { color: #4caf50; font-weight: bold; }
  .FAIL { color: #f44336; font-weight: bold; }
  .High { color: #f44336; }
  .Medium { color: #ff9800; }
  .Low { color: #4caf50; }
</style></head><body>
<h1>Windows Security Baseline Report</h1>
<h2>Host: $env:COMPUTERNAME | Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm') | Score: $score% ($pass/$($results.Count))</h2>
<table><tr><th>Category</th><th>Control</th><th>Status</th><th>Severity</th><th>Expected</th><th>Actual</th><th>Ref</th></tr>
"@
    foreach ($r in $results) {
        $html += "<tr><td>$($r.Category)</td><td>$($r.Control)</td>"
        $html += "<td class='$($r.Status)'>$($r.Status)</td>"
        $html += "<td class='$($r.Severity)'>$($r.Severity)</td>"
        $html += "<td>$($r.Expected)</td><td>$($r.Actual)</td><td>$($r.Reference)</td></tr>`n"
    }
    $html += "</table></body></html>"
    $html | Out-File -FilePath $ExportHTML -Encoding UTF8
    Write-Host "[*] HTML report saved: $ExportHTML" -ForegroundColor Green
}

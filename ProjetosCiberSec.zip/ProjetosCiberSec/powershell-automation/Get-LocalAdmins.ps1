<#
.SYNOPSIS
    Enumerates local administrator accounts on local or remote machines.

.DESCRIPTION
    Get-LocalAdmins.ps1 queries the local Administrators group on one or more
    machines and reports all members, flagging accounts that shouldn't typically
    be there (service accounts, domain users with admin rights, etc.).

.PARAMETER ComputerName
    Single target computer name

.PARAMETER ComputerList
    Path to a text file with one computer name per line

.PARAMETER ExportCSV
    Save results to CSV

.PARAMETER Credential
    PSCredential for remote connections (uses current session if omitted)

.EXAMPLE
    .\Get-LocalAdmins.ps1 -ComputerName "WORKSTATION01"
    .\Get-LocalAdmins.ps1 -ComputerList .\computers.txt -ExportCSV .\admins.csv
    .\Get-LocalAdmins.ps1 -ComputerName "SERVER01" -Credential (Get-Credential)

.NOTES
    Requires: WinRM enabled on remote machines OR local admin rights
    Author: Matheus Sanches | securescopeai.com
#>

[CmdletBinding()]
param(
    [string]$ComputerName,
    [string]$ComputerList,
    [string]$ExportCSV,
    [System.Management.Automation.PSCredential]$Credential
)

Set-StrictMode -Version Latest

# ── Build target list ───────────────────────────────────────────────────────────

$targets = @()
if ($ComputerName) {
    $targets = @($ComputerName)
} elseif ($ComputerList) {
    if (-not (Test-Path $ComputerList)) {
        Write-Error "Computer list file not found: $ComputerList"
        exit 1
    }
    $targets = Get-Content $ComputerList | Where-Object { $_.Trim() -ne "" }
} else {
    Write-Host "[*] No target specified, using localhost" -ForegroundColor Yellow
    $targets = @($env:COMPUTERNAME)
}

Write-Host "`n[*] Enumerating local admins on $($targets.Count) machine(s)...`n" -ForegroundColor Cyan

$allResults = @()
$errors     = @()

# ── Enumerate per machine ───────────────────────────────────────────────────────

foreach ($computer in $targets) {
    Write-Host "  [>] $computer" -ForegroundColor Gray -NoNewline

    $scriptBlock = {
        $groupName = "Administrators"
        $members = @()
        try {
            $group = [ADSI]"WinNT://$env:COMPUTERNAME/$groupName,group"
            $group.Members() | ForEach-Object {
                $adspath = $_.GetType().InvokeMember("ADsPath", "GetProperty", $null, $_, $null)
                $name    = $_.GetType().InvokeMember("Name", "GetProperty", $null, $_, $null)
                $class   = $_.GetType().InvokeMember("Class", "GetProperty", $null, $_, $null)

                # Determine source: local or domain
                $source = if ($adspath -match "WinNT://($env:COMPUTERNAME)/") { "Local" } else { "Domain" }

                $members += [PSCustomObject]@{
                    Computer = $env:COMPUTERNAME
                    Account  = $name
                    Type     = $class
                    Source   = $source
                    AdsPath  = $adspath
                }
            }
        } catch {
            $members += [PSCustomObject]@{
                Computer = $env:COMPUTERNAME
                Account  = "ERROR: $_"
                Type     = "Error"
                Source   = "N/A"
                AdsPath  = ""
            }
        }
        return $members
    }

    try {
        if ($computer -eq $env:COMPUTERNAME) {
            $results = & $scriptBlock
        } else {
            $invokeParams = @{
                ComputerName = $computer
                ScriptBlock  = $scriptBlock
                ErrorAction  = "Stop"
            }
            if ($Credential) { $invokeParams["Credential"] = $Credential }
            $results = Invoke-Command @invokeParams
        }

        $count = ($results | Measure-Object).Count
        Write-Host " → $count admin(s)" -ForegroundColor $(if ($count -gt 3) { "Yellow" } else { "Green" })

        # Flag suspicious: domain accounts, service accounts pattern
        foreach ($r in $results) {
            $flags = @()
            if ($r.Source -eq "Domain") { $flags += "DOMAIN_ACCOUNT" }
            if ($r.Account -match "svc|service|svc_|_svc") { $flags += "SERVICE_ACCOUNT_PATTERN" }
            if ($r.Account -match "test|temp|tmp|demo") { $flags += "TEMP_ACCOUNT_PATTERN" }

            $allResults += [PSCustomObject]@{
                Computer     = $r.Computer
                Account      = $r.Account
                Type         = $r.Type
                Source       = $r.Source
                Flags        = ($flags -join "; ")
                SuspiciousCount = $flags.Count
            }
        }
    } catch {
        Write-Host " → ERROR: $_" -ForegroundColor Red
        $errors += [PSCustomObject]@{ Computer = $computer; Error = $_.Exception.Message }
    }
}

# ── Summary ─────────────────────────────────────────────────────────────────────

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  LOCAL ADMINS ENUMERATION RESULTS" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Machines scanned : $($targets.Count)"
Write-Host "  Errors           : $($errors.Count)"
Write-Host "  Total admin accts: $($allResults.Count)"

$suspicious = $allResults | Where-Object { $_.SuspiciousCount -gt 0 }
if ($suspicious) {
    Write-Host "`n  ⚠️  SUSPICIOUS ACCOUNTS ($($suspicious.Count)):" -ForegroundColor Yellow
    $suspicious | Format-Table Computer, Account, Source, Flags -AutoSize
}

$domainAdmins = $allResults | Where-Object { $_.Source -eq "Domain" }
if ($domainAdmins) {
    Write-Host "  Domain accounts with local admin:" -ForegroundColor Yellow
    $domainAdmins | Format-Table Computer, Account -AutoSize
}

Write-Host "  All Entries:" -ForegroundColor Cyan
$allResults | Format-Table Computer, Account, Type, Source, Flags -AutoSize

if ($errors.Count -gt 0) {
    Write-Host "  Failed machines:" -ForegroundColor Red
    $errors | Format-Table Computer, Error -AutoSize
}

if ($ExportCSV) {
    $allResults | Export-Csv -Path $ExportCSV -NoTypeInformation -Encoding UTF8
    Write-Host "[*] Results saved to: $ExportCSV" -ForegroundColor Green
}

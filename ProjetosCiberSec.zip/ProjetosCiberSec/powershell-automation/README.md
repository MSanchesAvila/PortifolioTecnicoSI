# ⚡ powershell-automation

PowerShell scripts for Windows security auditing, Active Directory enumeration, and security baseline enforcement. Built for blue team operations and security assessments in authorized environments.

> ⚠️ **Disclaimer:** Run only in environments you own or have explicit written permission to audit.

---

## Scripts

| Script | Category | Description |
|--------|----------|-------------|
| `Get-ADUserAudit.ps1` | Active Directory | Audit AD user accounts: stale, privileged, password policy |
| `Invoke-SecurityBaseline.ps1` | Hardening | Check Windows security baseline (CIS Benchmark-aligned) |
| `Get-LocalAdmins.ps1` | Enumeration | Enumerate local admins across remote machines |

---

## Requirements

- PowerShell 5.1+ (Windows) or PowerShell 7+ (cross-platform)
- `Get-ADUserAudit.ps1`: RSAT (Remote Server Administration Tools) + `ActiveDirectory` module
- `Get-LocalAdmins.ps1`: WinRM enabled on target machines

### Enable ActiveDirectory module
```powershell
# On Windows Server
Install-WindowsFeature RSAT-AD-PowerShell

# On Windows 10/11
Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0
```

---

## Usage

### AD User Audit
```powershell
# Full audit — export to CSV
.\Get-ADUserAudit.ps1 -ExportCSV .\ad_audit.csv

# Show only privileged accounts
.\Get-ADUserAudit.ps1 -PrivilegedOnly

# Check specific OU
.\Get-ADUserAudit.ps1 -SearchBase "OU=Users,DC=corp,DC=local"
```

### Security Baseline Check
```powershell
# Full baseline check
.\Invoke-SecurityBaseline.ps1

# Export HTML report
.\Invoke-SecurityBaseline.ps1 -ExportHTML .\baseline_report.html

# Check specific category
.\Invoke-SecurityBaseline.ps1 -Category "PasswordPolicy"
```

### Local Admins Enumeration
```powershell
# Single machine
.\Get-LocalAdmins.ps1 -ComputerName "WORKSTATION01"

# From list of computers
.\Get-LocalAdmins.ps1 -ComputerList .\computers.txt -ExportCSV .\local_admins.csv
```

---

## Author

**Matheus Sanches** — [@securescopeai](https://github.com/securescopeai)  
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?logo=linkedin)](https://linkedin.com)

---

## License

MIT License

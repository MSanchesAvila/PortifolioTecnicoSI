<#
.SYNOPSIS
    Audits Active Directory user accounts for security issues.

.DESCRIPTION
    Get-ADUserAudit.ps1 enumerates AD users and checks for:
    - Stale accounts (no login in X days)
    - Accounts with password never expires flag
    - Privileged group members (Domain Admins, Schema Admins, etc.)
    - Accounts with password not required
    - Disabled accounts still in privileged groups
    - Accounts with old passwords

.PARAMETER SearchBase
    OU Distinguished Name to limit scope (default: entire domain)

.PARAMETER StaleThresholdDays
    Days since last logon to classify account as stale (default: 90)

.PARAMETER PrivilegedOnly
    Only show privileged accounts

.PARAMETER ExportCSV
    Path to export results as CSV

.EXAMPLE
    .\Get-ADUserAudit.ps1 -ExportCSV .\audit.csv
    .\Get-ADUserAudit.ps1 -PrivilegedOnly
    .\Get-ADUserAudit.ps1 -SearchBase "OU=Users,DC=corp,DC=local" -StaleThresholdDays 60

.NOTES
    Requires: ActiveDirectory PowerShell module (RSAT)
    Author: Matheus Sanches | securescopeai.com
#>

[CmdletBinding()]
param(
    [string]$SearchBase,
    [int]$StaleThresholdDays = 90,
    [switch]$PrivilegedOnly,
    [string]$ExportCSV
)

#Requires -Modules ActiveDirectory

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Helper functions ────────────────────────────────────────────────────────────

function Write-Banner {
    Write-Host "`n============================================" -ForegroundColor Cyan
    Write-Host "  AD User Security Audit" -ForegroundColor Cyan
    Write-Host "  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
    Write-Host "============================================`n" -ForegroundColor Cyan
}

function Get-PrivilegedGroups {
    $privilegedGroups = @(
        "Domain Admins", "Schema Admins", "Enterprise Admins",
        "Group Policy Creator Owners", "Administrators",
        "Account Operators", "Backup Operators", "Print Operators",
        "Server Operators", "Network Configuration Operators"
    )
    $existing = @()
    foreach ($grp in $privilegedGroups) {
        try {
            $null = Get-ADGroup -Identity $grp -ErrorAction SilentlyContinue
            $existing += $grp
        } catch { }
    }
    return $existing
}

function Get-GroupMembersFlat {
    param([string]$GroupName)
    try {
        $members = Get-ADGroupMember -Identity $GroupName -Recursive -ErrorAction SilentlyContinue
        return $members | Where-Object { $_.objectClass -eq "user" } | Select-Object -ExpandProperty SamAccountName
    } catch {
        return @()
    }
}

# ── Main audit ─────────────────────────────────────────────────────────────────

Write-Banner

# Check module
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
    Write-Error "ActiveDirectory module not found. Install RSAT first."
    exit 1
}

Write-Host "[*] Fetching privileged groups..." -ForegroundColor Yellow
$privGroups = Get-PrivilegedGroups
$privMembers = @{}
foreach ($grp in $privGroups) {
    $members = Get-GroupMembersFlat -GroupName $grp
    foreach ($m in $members) {
        if (-not $privMembers.ContainsKey($m)) { $privMembers[$m] = @() }
        $privMembers[$m] += $grp
    }
}
Write-Host "[*] Found $($privMembers.Count) privileged account(s) across $($privGroups.Count) groups" -ForegroundColor Gray

# Get all users
Write-Host "[*] Querying AD users..." -ForegroundColor Yellow
$params = @{
    Filter     = "*"
    Properties = @(
        "LastLogonDate", "PasswordLastSet", "PasswordNeverExpires",
        "PasswordNotRequired", "Enabled", "LockedOut", "MemberOf",
        "Description", "WhenCreated", "BadLogonCount", "SamAccountName"
    )
}
if ($SearchBase) { $params["SearchBase"] = $SearchBase }

$allUsers = Get-ADUser @params
Write-Host "[*] Processing $($allUsers.Count) user(s)...`n" -ForegroundColor Gray

$staleDate     = (Get-Date).AddDays(-$StaleThresholdDays)
$oldPassDate   = (Get-Date).AddDays(-180)
$results       = @()

foreach ($user in $allUsers) {
    $sam = $user.SamAccountName
    $isPrivileged = $privMembers.ContainsKey($sam)

    if ($PrivilegedOnly -and -not $isPrivileged) { continue }

    $findings = @()

    # Stale account
    if (-not $user.LastLogonDate -or $user.LastLogonDate -lt $staleDate) {
        $findings += "STALE_ACCOUNT"
    }

    # Password never expires
    if ($user.PasswordNeverExpires) { $findings += "PWD_NEVER_EXPIRES" }

    # Password not required
    if ($user.PasswordNotRequired) { $findings += "PWD_NOT_REQUIRED" }

    # Old password (>180 days)
    if ($user.PasswordLastSet -and $user.PasswordLastSet -lt $oldPassDate) {
        $findings += "OLD_PASSWORD"
    }

    # Locked out
    if ($user.LockedOut) { $findings += "LOCKED_OUT" }

    # Disabled but privileged
    if (-not $user.Enabled -and $isPrivileged) { $findings += "DISABLED_BUT_PRIVILEGED" }

    # High bad logon count (possible brute force)
    if ($user.BadLogonCount -gt 10) { $findings += "HIGH_BADLOGON_COUNT" }

    $riskLevel = "Low"
    if ($isPrivileged -and $findings.Count -gt 0) { $riskLevel = "Critical" }
    elseif ($isPrivileged) { $riskLevel = "Medium" }
    elseif ($findings.Count -ge 2) { $riskLevel = "High" }
    elseif ($findings.Count -eq 1) { $riskLevel = "Medium" }

    $results += [PSCustomObject]@{
        SamAccountName      = $sam
        DisplayName         = $user.Name
        Enabled             = $user.Enabled
        Privileged          = $isPrivileged
        PrivilegedGroups    = ($privMembers[$sam] -join "; ")
        LastLogonDate       = $user.LastLogonDate
        PasswordLastSet     = $user.PasswordLastSet
        PasswordNeverExpires= $user.PasswordNeverExpires
        PasswordNotRequired = $user.PasswordNotRequired
        LockedOut           = $user.LockedOut
        BadLogonCount       = $user.BadLogonCount
        Findings            = ($findings -join "; ")
        RiskLevel           = $riskLevel
        WhenCreated         = $user.WhenCreated
    }
}

# ── Print summary ───────────────────────────────────────────────────────────────

$critical = $results | Where-Object { $_.RiskLevel -eq "Critical" }
$high      = $results | Where-Object { $_.RiskLevel -eq "High" }

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  AUDIT SUMMARY" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Total accounts audited : $($results.Count)"
Write-Host "  Privileged accounts    : $($results | Where-Object Privileged)"
Write-Host "  Critical risk          : $($critical.Count)" -ForegroundColor $(if ($critical.Count -gt 0) { "Red" } else { "Green" })
Write-Host "  High risk              : $($high.Count)" -ForegroundColor $(if ($high.Count -gt 0) { "Yellow" } else { "Green" })

if ($critical) {
    Write-Host "`n[!] CRITICAL — Privileged accounts with issues:" -ForegroundColor Red
    $critical | Format-Table SamAccountName, PrivilegedGroups, Findings -AutoSize
}

if ($high) {
    Write-Host "`n[!] HIGH RISK accounts:" -ForegroundColor Yellow
    $high | Select-Object -First 10 | Format-Table SamAccountName, Findings -AutoSize
}

# ── Export ──────────────────────────────────────────────────────────────────────

if ($ExportCSV) {
    $results | Export-Csv -Path $ExportCSV -NoTypeInformation -Encoding UTF8
    Write-Host "`n[*] Results exported to: $ExportCSV" -ForegroundColor Green
}

Write-Host "`n[*] Audit completed." -ForegroundColor Cyan

# ⚡ powershell-automation

> 🇧🇷 Leia em Português | [🇺🇸 Read in English](README.md)

Scripts PowerShell para auditoria de segurança Windows, enumeração de Active Directory e aplicação de baseline de segurança. Desenvolvidos para operações de blue team e avaliações de segurança em ambientes autorizados.

> ⚠️ **Aviso Legal:** Execute apenas em ambientes que você possui ou tem permissão escrita explícita para auditar.

---

## 📂 Scripts

| Script | Categoria | Descrição |
|--------|-----------|-----------|
| `Get-ADUserAudit.ps1` | Active Directory | Audita contas AD: inativas, privilegiadas, senhas fracas |
| `Invoke-SecurityBaseline.ps1` | Hardening | Verifica baseline CIS para Windows com relatório HTML |
| `Get-LocalAdmins.ps1` | Enumeração | Enumera administradores locais em múltiplas máquinas |

---

## ⚙️ Requisitos

- **PowerShell 5.1+** (Windows) ou **PowerShell 7+** (multiplataforma)
- `Get-ADUserAudit.ps1`: módulo `ActiveDirectory` (RSAT)
- `Get-LocalAdmins.ps1`: WinRM habilitado nas máquinas alvo
- `Invoke-SecurityBaseline.ps1`: executar como **Administrador**

### Instalar o módulo ActiveDirectory

```powershell
# Windows Server
Install-WindowsFeature RSAT-AD-PowerShell

# Windows 10/11
Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0
```

### Habilitar execução de scripts (se necessário)

```powershell
# Apenas para a sessão atual
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

---

## 🚀 Como Usar

---

### 👤 Auditoria de Usuários AD — `Get-ADUserAudit.ps1`

Varre todas as contas do Active Directory e identifica falhas de segurança. As contas **privilegiadas** com qualquer problema são marcadas como **Critical**.

**O que é verificado:**

| Verificação | Critério | Risco |
|-------------|----------|-------|
| Conta inativa | Sem logon há mais de 90 dias (configurável) | Médio |
| Senha nunca expira | Flag `PasswordNeverExpires` ativo | Alto |
| Senha não obrigatória | Flag `PasswordNotRequired` ativo | Alto |
| Senha antiga | Sem troca há mais de 180 dias | Médio |
| Conta bloqueada | `LockedOut = True` | Baixo |
| Conta desabilitada com privilégio | Ainda membro de grupo privilegiado | Crítico |
| Alto badlogon count | Mais de 10 tentativas falhas | Médio |

**Grupos privilegiados monitorados:** Domain Admins, Schema Admins, Enterprise Admins, Group Policy Creator Owners, Administrators, Account Operators, Backup Operators, Print Operators, Server Operators.

```powershell
# Auditoria completa com exportação CSV
.\Get-ADUserAudit.ps1 -ExportCSV .\auditoria_ad.csv

# Apenas contas privilegiadas
.\Get-ADUserAudit.ps1 -PrivilegedOnly

# OU específica, threshold de 60 dias
.\Get-ADUserAudit.ps1 -SearchBase "OU=Usuarios,DC=empresa,DC=local" -StaleThresholdDays 60
```

**Exemplo de saída:**
```
============================================
  AD User Security Audit
  2025-07-23 14:32:01
============================================

[!] CRITICAL — Privileged accounts with issues:
Account         PrivilegedGroups      Findings
-------         ----------------      --------
svc.backup      Domain Admins         PWD_NEVER_EXPIRES; OLD_PASSWORD
adm.teste       Administrators        STALE_ACCOUNT; DISABLED_BUT_PRIVILEGED

[!] HIGH RISK accounts:
Account         Findings
-------         --------
joao.silva      PWD_NEVER_EXPIRES; OLD_PASSWORD
```

---

### 🛡️ Baseline de Segurança — `Invoke-SecurityBaseline.ps1`

Verifica a configuração da máquina local contra controles do **CIS Microsoft Windows Benchmark**. Cada controle recebe PASS ou FAIL com nível de severidade.

**Categorias verificadas:**

**Política de Senhas**
- Comprimento mínimo ≥ 14 caracteres
- Validade máxima ≤ 90 dias
- Histórico de senhas ≥ 24
- Bloqueio de conta ≤ 5 tentativas

**Política de Auditoria**
- Auditoria de logon (sucesso e falha)
- Auditoria de gerenciamento de contas
- Auditoria de acesso a objetos
- Auditoria de mudança de política

**Segurança de Rede**
- SMBv1 desabilitado
- NTLMv2 forçado (LmCompatibilityLevel ≥ 5)
- Windows Firewall ativo em todos os perfis
- Remote Registry desabilitado

**Serviços Arriscados**
- Telnet, FTP, SNMP, Remote Access desabilitados

**Hardening de Registro**
- UAC habilitado e configurado corretamente
- Enumeração anônima restrita
- Windows Update não desabilitado
- Canal seguro do Netlogon assinado

```powershell
# Verificação completa
.\Invoke-SecurityBaseline.ps1

# Apenas política de senhas
.\Invoke-SecurityBaseline.ps1 -Category PasswordPolicy

# Exportar relatório HTML (dark mode, pronto para apresentar)
.\Invoke-SecurityBaseline.ps1 -ExportHTML .\relatorio_baseline.html

# Exportar CSV para análise em planilha
.\Invoke-SecurityBaseline.ps1 -ExportCSV .\baseline.csv
```

**Exemplo de saída:**
```
[ Password Policy ]
  [PASS] [High  ] Minimum password length >= 14
  [FAIL] [High  ] Account lockout threshold <= 5 attempts
         Expected: <= 5 (not 0) | Actual: 0
  [PASS] [Medium] Password history >= 24

[ Network Security ]
  [FAIL] [High  ] SMBv1 disabled
         Expected: Disabled | Actual: ENABLED
  [PASS] [High  ] Windows Firewall enabled (all profiles)
  [PASS] [High  ] NTLMv2 enforced

============================================
  BASELINE RESULTS
  Passed: 18 | Failed: 5 | Score: 78.3%
============================================
```

---

### 👥 Admins Locais — `Get-LocalAdmins.ps1`

Enumera todos os membros do grupo **Administrators** local em uma ou várias máquinas remotas via WinRM. Ideal para encontrar contas de domínio com admin local indevido ou contas de serviço mal configuradas.

**Sinalizações automáticas:**

| Flag | Critério |
|------|----------|
| `DOMAIN_ACCOUNT` | Conta de domínio com admin local |
| `SERVICE_ACCOUNT_PATTERN` | Nome contém: `svc`, `service`, `svc_`, `_svc` |
| `TEMP_ACCOUNT_PATTERN` | Nome contém: `test`, `temp`, `tmp`, `demo` |

```powershell
# Máquina única
.\Get-LocalAdmins.ps1 -ComputerName "WORKSTATION01"

# Lista de máquinas a partir de arquivo
.\Get-LocalAdmins.ps1 -ComputerList .\computadores.txt -ExportCSV .\admins_locais.csv

# Com credenciais alternativas
.\Get-LocalAdmins.ps1 -ComputerList .\servidores.txt -Credential (Get-Credential)
```

**Exemplo de arquivo `computadores.txt`:**
```
WORKSTATION01
WORKSTATION02
SERVER-DEV01
SERVER-PROD01
```

**Exemplo de saída:**
```
[*] Enumerating local admins on 4 machine(s)...

  [>] WORKSTATION01 → 3 admin(s)
  [>] WORKSTATION02 → 5 admin(s)   ← suspeito: mais de 3
  [>] SERVER-DEV01  → 2 admin(s)
  [>] SERVER-PROD01 → 2 admin(s)

⚠️  SUSPICIOUS ACCOUNTS (2):
Computer       Account           Source   Flags
--------       -------           ------   -----
WORKSTATION02  EMPRESA\svc.sql   Domain   DOMAIN_ACCOUNT; SERVICE_ACCOUNT_PATTERN
WORKSTATION02  EMPRESA\temp.adm  Domain   DOMAIN_ACCOUNT; TEMP_ACCOUNT_PATTERN
```

---

## 📁 Estrutura do Projeto

```
powershell-automation/
├── Get-ADUserAudit.ps1           # Auditoria de usuários AD
├── Invoke-SecurityBaseline.ps1   # Verificação de baseline CIS
├── Get-LocalAdmins.ps1           # Enumeração de admins locais
├── README.md                     # Documentação em inglês
└── README.pt-BR.md               # Este arquivo
```

---

## 🔐 Casos de Uso Reais

- **Auditoria de AD:** Rodar `Get-ADUserAudit.ps1` mensalmente para detectar contas esquecidas com acesso privilegiado
- **Hardening:** Usar `Invoke-SecurityBaseline.ps1` antes e depois de aplicar GPOs para medir evolução
- **Resposta a Incidentes:** `Get-LocalAdmins.ps1` para verificar se um atacante adicionou contas em múltiplas máquinas
- **Compliance:** Evidências para auditorias de ISO 27001, SOC 2 e frameworks internos

---

## ⚠️ Boas Práticas

- Armazene os CSVs/relatórios gerados em local seguro — contêm dados sensíveis de configuração
- Em produção, use uma conta de serviço com permissões mínimas necessárias (Read-only domain admin para o audit)
- Agende `Get-ADUserAudit.ps1` via Task Scheduler para revisões automáticas periódicas
- O relatório HTML do baseline pode ser compartilhado com gestores sem acesso ao servidor

---

## 👨‍💻 Autor

**Matheus Sanches**  
Especialista em Cibersegurança | [SecureScope AI](https://securescopeai.com)  
📧 matheus.sanches@securescopeai.com

---

## 📄 Licença

MIT License — livre para usar e adaptar com atribuição.

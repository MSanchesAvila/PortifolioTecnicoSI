# 🐍 python-security

A collection of offensive and defensive security tools written in Python. Designed for educational purposes, CTF challenges, and security assessments in authorized environments.

> ⚠️ **Disclaimer:** These tools are for educational and authorized use only. Unauthorized use against systems you do not own or have explicit permission to test is illegal.

---

## Tools

| Script | Category | Description |
|--------|----------|-------------|
| `port_scanner.py` | Reconnaissance | Multi-threaded TCP port scanner with banner grabbing |
| `hash_cracker.py` | Cryptanalysis | Hash identifier + dictionary/brute-force attack |
| `log_analyzer.py` | Blue Team | Log parser for detecting suspicious patterns (SSH, HTTP, auth) |

---

## Requirements

```bash
pip install -r requirements.txt
```

---

## Usage

### Port Scanner
```bash
# Scan common ports
python port_scanner.py 192.168.1.1

# Custom port range with output
python port_scanner.py scanme.nmap.org -p 1-1000 -o report.json

# Fast scan with more threads
python port_scanner.py 10.0.0.1 -p 80,443,8080,8443 -T 100
```

### Hash Cracker
```bash
# Auto-detect hash type and crack with wordlist
python hash_cracker.py 5f4dcc3b5aa765d61d8327deb882cf99 -w /usr/share/wordlists/rockyou.txt

# Brute force MD5 up to 4 chars
python hash_cracker.py <hash> --brute --max-len 4 --charset alpha
```

### Log Analyzer
```bash
# Analyze SSH auth log
python log_analyzer.py /var/log/auth.log --type ssh

# Analyze Apache/Nginx access log
python log_analyzer.py /var/log/apache2/access.log --type http --report report.html
```

---

## Author

**Matheus Sanches** — [@securescopeai](https://github.com/securescopeai)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?logo=linkedin)](https://linkedin.com)
[![SecureScope AI](https://img.shields.io/badge/SecureScope-AI-red)](https://securescopeai.com)

---

## License

MIT License — see [LICENSE](LICENSE)

#!/usr/bin/env python3
"""
web_scanner.py — Web Application Security Scanner
================================================
Repositório : python-security
Autor       : Matheus Sanches
Licença     : MIT

Verifica:
  • Headers HTTP de segurança (CSP, HSTS, X-Frame-Options…)
  • Flags de segurança em cookies (Secure, HttpOnly, SameSite)
  • Configuração SSL/TLS (versão, expiração, cipher fraco)
  • Arquivos/diretórios sensíveis expostos (.env, .git/, backup…)
  • Fingerprinting de tecnologias (Server, X-Powered-By, frameworks)
  • Open redirects básicos
  • [--full] Formulários: payloads SQLi e XSS básicos

Uso:
  python web_scanner.py https://alvo.com
  python web_scanner.py https://alvo.com --full
  python web_scanner.py https://alvo.com -o relatorio.json
  python web_scanner.py https://alvo.com --timeout 10 -q

AVISO LEGAL:
  Use somente em sistemas que você possui ou tem autorização escrita
  para testar. Uso não autorizado pode violar leis de crimes cibernéticos.
"""
from __future__ import annotations

import argparse
import html
import json
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────
#  CONSTANTES
# ──────────────────────────────────────────────────────────

VERSION = "1.0.0"

# Headers que DEVERIAM estar presentes
SECURITY_HEADERS: Dict[str, Dict[str, Any]] = {
    "Strict-Transport-Security": {
        "severity": "HIGH",
        "desc": "HSTS ausente — sem proteção contra downgrade HTTPS→HTTP",
        "ref": "OWASP A05:2021",
    },
    "Content-Security-Policy": {
        "severity": "HIGH",
        "desc": "CSP ausente — sem proteção contra injeção de scripts (XSS)",
        "ref": "OWASP A03:2021",
    },
    "X-Frame-Options": {
        "severity": "MEDIUM",
        "desc": "X-Frame-Options ausente — vulnerável a clickjacking",
        "ref": "CWE-1021",
    },
    "X-Content-Type-Options": {
        "severity": "MEDIUM",
        "desc": "X-Content-Type-Options ausente — MIME sniffing habilitado",
        "ref": "CWE-430",
    },
    "Referrer-Policy": {
        "severity": "LOW",
        "desc": "Referrer-Policy ausente — URLs internas podem vazar",
        "ref": "RFC 7616",
    },
    "Permissions-Policy": {
        "severity": "LOW",
        "desc": "Permissions-Policy ausente — acesso à câmera/mic não restrito por política",
        "ref": "W3C Feature Policy",
    },
    "X-XSS-Protection": {
        "severity": "LOW",
        "desc": "X-XSS-Protection ausente (legado, mas ainda presente em scanners)",
        "ref": "OWASP",
    },
}

# Headers que NÃO deveriam estar presentes (revelam informações)
LEAKY_HEADERS = [
    "Server",
    "X-Powered-By",
    "X-AspNet-Version",
    "X-AspNetMvc-Version",
    "X-Generator",
    "X-Drupal-Cache",
    "X-Joomla-Powered",
    "X-WordPress-Cache",
]

# Arquivos/caminhos sensíveis para verificar
SENSITIVE_PATHS: List[Dict[str, str]] = [
    # Controle de versão
    {"path": "/.git/HEAD",              "severity": "CRITICAL", "desc": "Repositório Git exposto — código-fonte pode ser baixado"},
    {"path": "/.git/config",            "severity": "CRITICAL", "desc": "Configuração Git exposta"},
    {"path": "/.svn/entries",           "severity": "CRITICAL", "desc": "Repositório SVN exposto"},
    {"path": "/.hg/store/fncache",      "severity": "CRITICAL", "desc": "Repositório Mercurial exposto"},
    # Arquivos de configuração/ambiente
    {"path": "/.env",                   "severity": "CRITICAL", "desc": "Arquivo .env exposto — pode conter credenciais e chaves API"},
    {"path": "/.env.local",             "severity": "CRITICAL", "desc": "Arquivo .env.local exposto"},
    {"path": "/.env.production",        "severity": "CRITICAL", "desc": "Arquivo .env.production exposto"},
    {"path": "/.env.backup",            "severity": "CRITICAL", "desc": "Backup de .env exposto"},
    {"path": "/config.php",             "severity": "CRITICAL", "desc": "Arquivo de configuração PHP exposto"},
    {"path": "/wp-config.php.bak",      "severity": "CRITICAL", "desc": "Backup do wp-config.php exposto"},
    {"path": "/config.yml",             "severity": "HIGH",     "desc": "Arquivo YAML de configuração exposto"},
    {"path": "/config.yaml",            "severity": "HIGH",     "desc": "Arquivo YAML de configuração exposto"},
    {"path": "/settings.py",            "severity": "HIGH",     "desc": "Configuração Django exposta"},
    {"path": "/database.yml",           "severity": "HIGH",     "desc": "Credenciais de banco Rails expostas"},
    # Backups e dumps
    {"path": "/backup.zip",             "severity": "CRITICAL", "desc": "Arquivo de backup exposto"},
    {"path": "/backup.tar.gz",          "severity": "CRITICAL", "desc": "Arquivo de backup exposto"},
    {"path": "/backup.sql",             "severity": "CRITICAL", "desc": "Dump de banco de dados exposto"},
    {"path": "/dump.sql",               "severity": "CRITICAL", "desc": "Dump de banco de dados exposto"},
    {"path": "/db.sql",                 "severity": "CRITICAL", "desc": "Dump de banco de dados exposto"},
    {"path": "/site.zip",               "severity": "HIGH",     "desc": "Backup do site exposto"},
    {"path": "/www.zip",                "severity": "HIGH",     "desc": "Backup do site exposto"},
    # Painéis administrativos comuns
    {"path": "/admin",                  "severity": "MEDIUM",   "desc": "Painel admin acessível sem redirect"},
    {"path": "/admin/login",            "severity": "MEDIUM",   "desc": "Login admin exposto"},
    {"path": "/wp-admin/",              "severity": "MEDIUM",   "desc": "WordPress admin exposto"},
    {"path": "/phpmyadmin/",            "severity": "HIGH",     "desc": "phpMyAdmin exposto publicamente"},
    {"path": "/adminer.php",            "severity": "HIGH",     "desc": "Adminer DB manager exposto"},
    {"path": "/.well-known/security.txt","severity": "INFO",    "desc": "security.txt encontrado (bom sinal — política de divulgação)"},
    # Debug e informação
    {"path": "/phpinfo.php",            "severity": "HIGH",     "desc": "phpinfo() exposto — revela configurações do servidor"},
    {"path": "/info.php",               "severity": "HIGH",     "desc": "phpinfo() exposto"},
    {"path": "/test.php",               "severity": "MEDIUM",   "desc": "Arquivo de teste PHP exposto"},
    {"path": "/server-status",          "severity": "MEDIUM",   "desc": "Apache server-status exposto"},
    {"path": "/server-info",            "severity": "MEDIUM",   "desc": "Apache server-info exposto"},
    # Logs
    {"path": "/error.log",              "severity": "HIGH",     "desc": "Log de erros exposto"},
    {"path": "/access.log",             "severity": "HIGH",     "desc": "Log de acesso exposto"},
    {"path": "/debug.log",              "severity": "HIGH",     "desc": "Log de debug exposto"},
    # Robots e sitemaps
    {"path": "/robots.txt",             "severity": "INFO",     "desc": "robots.txt encontrado — verifique caminhos ocultos"},
    {"path": "/sitemap.xml",            "severity": "INFO",     "desc": "Sitemap encontrado"},
    # Composer / npm
    {"path": "/composer.json",          "severity": "LOW",      "desc": "composer.json exposto — revela dependências e versões"},
    {"path": "/package.json",           "severity": "LOW",      "desc": "package.json exposto — revela dependências"},
    {"path": "/composer.lock",          "severity": "LOW",      "desc": "composer.lock exposto — versões exatas das dependências"},
]

# Payloads SQLi básicos (modo --full)
SQLI_PAYLOADS = [
    "'",
    "\"",
    "' OR '1'='1",
    "' OR '1'='1'--",
    "\" OR \"1\"=\"1",
    "1' ORDER BY 1--",
    "1 UNION SELECT NULL--",
    "'; DROP TABLE users;--",
]

# Indicadores de erro SQL em respostas
SQL_ERRORS = [
    "you have an error in your sql syntax",
    "warning: mysql",
    "unclosed quotation mark",
    "quoted string not properly terminated",
    "pg_query()",
    "postgresql",
    "ora-",
    "oracle error",
    "microsoft ole db provider",
    "odbc microsoft access",
    "sql server",
    "sqlite_",
    "syntax error",
    "mysql_fetch",
]

# Payloads XSS básicos (modo --full)
XSS_PAYLOADS = [
    "<script>alert('XSS')</script>",
    "<img src=x onerror=alert('XSS')>",
    "\"><script>alert('XSS')</script>",
    "javascript:alert('XSS')",
    "<svg onload=alert('XSS')>",
]

# Indicadores de XSS refletido
XSS_REFLECTED = [
    "<script>alert('XSS')</script>",
    "<img src=x onerror=alert",
    "<svg onload=alert",
]

# Ciphers considerados fracos
WEAK_CIPHERS = ["RC4", "DES", "3DES", "EXPORT", "NULL", "ANON", "MD5"]

# Severity ordering para sort
SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4, "PASS": 5}


# ──────────────────────────────────────────────────────────
#  CORES (terminal)
# ──────────────────────────────────────────────────────────

class C:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    YELLOW = "\033[93m"
    GREEN  = "\033[92m"
    CYAN   = "\033[96m"
    BLUE   = "\033[94m"
    GRAY   = "\033[90m"
    WHITE  = "\033[97m"

    @staticmethod
    def sev(s: str) -> str:
        m = {
            "CRITICAL": C.RED + C.BOLD,
            "HIGH":     C.RED,
            "MEDIUM":   C.YELLOW,
            "LOW":      C.BLUE,
            "INFO":     C.CYAN,
            "PASS":     C.GREEN,
        }
        return m.get(s.upper(), C.WHITE)

def colored(text: str, color: str) -> str:
    """Retorna texto colorido se stdout é um terminal."""
    if sys.stdout.isatty():
        return f"{color}{text}{C.RESET}"
    return text

def sev_label(sev: str) -> str:
    pad = max(0, 8 - len(sev))
    return colored(f"[{sev}]{' ' * pad}", C.sev(sev))


# ──────────────────────────────────────────────────────────
#  RESULTADO DE ACHADO
# ──────────────────────────────────────────────────────────

class Finding:
    def __init__(self, category: str, severity: str, title: str,
                 detail: str = "", ref: str = "") -> None:
        self.category = category
        self.severity = severity.upper()
        self.title    = title
        self.detail   = detail
        self.ref      = ref
        self.ts       = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, str]:
        return {
            "category": self.category,
            "severity": self.severity,
            "title":    self.title,
            "detail":   self.detail,
            "ref":      self.ref,
        }

    def print_line(self, quiet: bool = False) -> None:
        if quiet and self.severity in ("INFO", "PASS"):
            return
        label = sev_label(self.severity)
        title = colored(self.title, C.WHITE if self.severity != "PASS" else C.GREEN)
        print(f"  {label} {title}")
        if self.detail and not quiet:
            print(f"  {'':>10}  {colored(self.detail, C.GRAY)}")
        if self.ref and not quiet:
            print(f"  {'':>10}  {colored('Ref: ' + self.ref, C.GRAY)}")


# ──────────────────────────────────────────────────────────
#  HTTP HELPER
# ──────────────────────────────────────────────────────────

def make_request(
    url: str,
    timeout: float = 8.0,
    method: str = "GET",
    data: Optional[bytes] = None,
    follow_redirects: bool = True,
    extra_headers: Optional[Dict[str, str]] = None,
) -> Tuple[Optional[int], Optional[Dict[str, str]], Optional[str], Optional[str]]:
    """
    Faz uma requisição HTTP e retorna (status, headers_dict, body, final_url).
    Retorna (None, None, None, None) em caso de erro.
    """
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        "Connection": "close",
    }
    if extra_headers:
        headers.update(extra_headers)

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(
            req,
            timeout=timeout,
            context=ctx,
        ) as resp:
            body = resp.read(65536).decode("utf-8", errors="replace")
            resp_headers = {k.lower(): v for k, v in resp.getheaders()}
            return resp.status, resp_headers, body, resp.url
    except urllib.error.HTTPError as e:
        try:
            body = e.read(16384).decode("utf-8", errors="replace")
        except Exception:
            body = ""
        resp_headers = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        return e.code, resp_headers, body, url
    except Exception:
        return None, None, None, None


# ──────────────────────────────────────────────────────────
#  MÓDULOS DE VERIFICAÇÃO
# ──────────────────────────────────────────────────────────

def check_security_headers(
    headers: Dict[str, str],
    url: str,
) -> List[Finding]:
    findings: List[Finding] = []
    headers_lower = {k.lower(): v for k, v in headers.items()}

    for header, meta in SECURITY_HEADERS.items():
        key = header.lower()
        if key in headers_lower:
            val = headers_lower[key]
            # Verificações extras para headers presentes mas mal configurados
            if key == "strict-transport-security":
                if "max-age" not in val.lower():
                    findings.append(Finding(
                        "Headers", "MEDIUM",
                        f"HSTS sem max-age",
                        f"Valor atual: {val}",
                        "RFC 6797",
                    ))
                else:
                    # Extrai max-age
                    m = re.search(r"max-age=(\d+)", val, re.IGNORECASE)
                    if m and int(m.group(1)) < 15768000:
                        findings.append(Finding(
                            "Headers", "LOW",
                            "HSTS max-age < 6 meses",
                            f"Atual: {m.group(1)}s. Recomendado: ≥ 31536000 (1 ano)",
                            "RFC 6797",
                        ))
                    else:
                        findings.append(Finding("Headers", "PASS",
                            f"✓ {header}: presente e bem configurado", val))
            elif key == "x-frame-options":
                if val.upper() not in ("DENY", "SAMEORIGIN"):
                    findings.append(Finding(
                        "Headers", "LOW",
                        f"X-Frame-Options com valor incomum",
                        f"Valor: {val}. Use DENY ou SAMEORIGIN",
                    ))
                else:
                    findings.append(Finding("Headers", "PASS",
                        f"✓ {header}: {val}"))
            else:
                findings.append(Finding("Headers", "PASS",
                    f"✓ {header}: presente", val[:80]))
        else:
            findings.append(Finding(
                "Headers",
                meta["severity"],
                f"{header} ausente",
                meta["desc"],
                meta["ref"],
            ))

    # Verifica headers que revelam informações
    for leaky in LEAKY_HEADERS:
        key = leaky.lower()
        if key in headers_lower:
            val = headers_lower[key]
            findings.append(Finding(
                "Fingerprinting",
                "LOW",
                f"Header informativo exposto: {leaky}",
                f"Valor: {val} — remove ou ofusca este header no servidor",
            ))

    return findings


def check_cookies(headers: Dict[str, str], is_https: bool) -> List[Finding]:
    findings: List[Finding] = []
    set_cookies = [v for k, v in headers.items() if k.lower() == "set-cookie"]

    if not set_cookies:
        return [Finding("Cookies", "INFO", "Nenhum cookie definido na resposta inicial")]

    for raw in set_cookies:
        # Extrai nome do cookie
        parts = [p.strip() for p in raw.split(";")]
        name = parts[0].split("=")[0].strip() if parts else "?"

        flags = [p.lower() for p in parts[1:]]
        flag_str = "; ".join(parts[1:])

        # HttpOnly
        if "httponly" not in flags:
            findings.append(Finding(
                "Cookies", "MEDIUM",
                f"Cookie '{name}' sem flag HttpOnly",
                "JavaScript pode ler este cookie — vetor de roubo via XSS",
                "OWASP A05",
            ))
        else:
            findings.append(Finding("Cookies", "PASS", f"✓ Cookie '{name}': HttpOnly presente"))

        # Secure (só relevante em HTTPS)
        if is_https and "secure" not in flags:
            findings.append(Finding(
                "Cookies", "MEDIUM",
                f"Cookie '{name}' sem flag Secure",
                "Cookie pode ser enviado em conexões HTTP não cifradas",
            ))
        elif is_https:
            findings.append(Finding("Cookies", "PASS", f"✓ Cookie '{name}': Secure presente"))

        # SameSite
        has_samesite = any("samesite" in f for f in flags)
        if not has_samesite:
            findings.append(Finding(
                "Cookies", "LOW",
                f"Cookie '{name}' sem SameSite",
                "Sem SameSite=Lax/Strict o cookie é enviado em requests cross-site (CSRF)",
                "CWE-352",
            ))
        else:
            ss_val = next((f for f in flags if "samesite" in f), "")
            if "samesite=none" in ss_val and "secure" not in flags:
                findings.append(Finding(
                    "Cookies", "MEDIUM",
                    f"Cookie '{name}' SameSite=None sem Secure",
                    "SameSite=None exige a flag Secure — browsers modernos rejeitam",
                ))
            else:
                findings.append(Finding("Cookies", "PASS",
                    f"✓ Cookie '{name}': SameSite={ss_val.split('=')[-1] if '=' in ss_val else '?'}"))

    return findings


def check_ssl(hostname: str, port: int = 443) -> List[Finding]:
    findings: List[Finding] = []

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cipher = ssock.cipher()
                proto  = ssock.version()
                cert   = ssock.getpeercert()

        # Protocolo
        if proto in ("SSLv2", "SSLv3", "TLSv1", "TLSv1.1"):
            findings.append(Finding(
                "SSL/TLS", "HIGH",
                f"Protocolo fraco em uso: {proto}",
                "TLS 1.0 e 1.1 estão deprecados (RFC 8996). Use TLS 1.2+",
                "RFC 8996",
            ))
        elif proto in ("TLSv1.2", "TLSv1.3"):
            findings.append(Finding("SSL/TLS", "PASS", f"✓ Protocolo: {proto}"))
        else:
            findings.append(Finding("SSL/TLS", "INFO", f"Protocolo: {proto}"))

        # Cipher
        if cipher:
            cipher_name = cipher[0]
            if any(w in cipher_name.upper() for w in WEAK_CIPHERS):
                findings.append(Finding(
                    "SSL/TLS", "HIGH",
                    f"Cipher fraco: {cipher_name}",
                    "Este cipher possui vulnerabilidades conhecidas",
                ))
            else:
                findings.append(Finding("SSL/TLS", "PASS", f"✓ Cipher: {cipher_name}"))

        # Certificado — validade
        if cert:
            expires_str = cert.get("notAfter", "")
            if expires_str:
                try:
                    expires = datetime.strptime(expires_str, "%b %d %H:%M:%S %Y %Z")
                    expires = expires.replace(tzinfo=timezone.utc)
                    now     = datetime.now(timezone.utc)
                    days    = (expires - now).days
                    if days < 0:
                        findings.append(Finding(
                            "SSL/TLS", "CRITICAL",
                            f"Certificado EXPIRADO há {abs(days)} dias",
                            f"Expirou em: {expires_str}",
                        ))
                    elif days < 14:
                        findings.append(Finding(
                            "SSL/TLS", "HIGH",
                            f"Certificado expira em {days} dias",
                            f"Data: {expires_str}",
                        ))
                    elif days < 30:
                        findings.append(Finding(
                            "SSL/TLS", "MEDIUM",
                            f"Certificado expira em {days} dias",
                            f"Data: {expires_str}",
                        ))
                    else:
                        findings.append(Finding(
                            "SSL/TLS", "PASS",
                            f"✓ Certificado válido por {days} dias",
                            f"Expira em: {expires_str}",
                        ))
                except ValueError:
                    findings.append(Finding("SSL/TLS", "INFO",
                        f"Não foi possível parsear data de expiração: {expires_str}"))

            # CN/SANs
            subject = dict(x[0] for x in cert.get("subject", []))
            cn = subject.get("commonName", "?")
            findings.append(Finding("SSL/TLS", "INFO", f"Certificado CN: {cn}"))

    except ssl.SSLError as e:
        findings.append(Finding("SSL/TLS", "HIGH",
            "Erro SSL ao conectar",
            str(e),
        ))
    except (ConnectionRefusedError, socket.timeout, OSError):
        findings.append(Finding("SSL/TLS", "INFO",
            "HTTPS não disponível na porta 443 ou timeout"))

    return findings


def check_sensitive_paths(
    base_url: str,
    timeout: float,
    quiet: bool,
    max_workers: int = 20,
) -> List[Finding]:
    findings: List[Finding] = []
    base = base_url.rstrip("/")

    def probe(entry: Dict[str, str]) -> Optional[Finding]:
        url = base + entry["path"]
        status, headers, body, _ = make_request(url, timeout=timeout)
        if status is None:
            return None

        # Considera encontrado se 200, 301, 302, 401, 403 (não 404)
        if status == 404:
            return None

        # INFO paths (robots, sitemap, security.txt) — sempre reporta
        sev = entry["severity"]

        if status in (200, 206):
            detail = f"HTTP {status} — acessível diretamente"
        elif status in (301, 302, 307, 308):
            detail = f"HTTP {status} redirect — caminho existe"
        elif status == 401:
            detail = f"HTTP 401 — existe mas requer autenticação (confirma presença)"
            sev = min(sev, "MEDIUM") if sev not in ("CRITICAL", "HIGH") else sev
        elif status == 403:
            detail = f"HTTP 403 — existe mas acesso negado"
            sev = "LOW" if sev not in ("CRITICAL", "HIGH") else sev
        else:
            detail = f"HTTP {status}"

        return Finding(
            "Exposição",
            sev,
            f"{entry['path']} acessível",
            f"{entry['desc']} | {detail}",
        )

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(probe, entry): entry for entry in SENSITIVE_PATHS}
        for fut in as_completed(futures):
            result = fut.result()
            if result:
                findings.append(result)

    return sorted(findings, key=lambda f: SEV_ORDER.get(f.severity, 99))


def check_open_redirect(base_url: str, timeout: float) -> List[Finding]:
    findings: List[Finding] = []
    payloads = [
        "//evil.com",
        "https://evil.com",
        "//evil.com%2F%2F",
        "///evil.com",
    ]
    params = ["redirect", "url", "next", "return", "goto", "dest", "destination",
              "redirect_uri", "redirect_url", "return_url", "continue", "redir"]

    parsed = urllib.parse.urlparse(base_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    found = False
    for param in params:
        for payload in payloads:
            test_url = f"{base}/?{param}={urllib.parse.quote(payload)}"
            status, headers, _, final = make_request(test_url, timeout=timeout, follow_redirects=False)
            if status in (301, 302, 303, 307, 308) and headers:
                location = headers.get("location", "")
                if "evil.com" in location:
                    findings.append(Finding(
                        "Open Redirect",
                        "HIGH",
                        f"Open Redirect via parâmetro '{param}'",
                        f"Payload: {payload} → Location: {location}",
                        "CWE-601",
                    ))
                    found = True
                    break
        if found:
            break

    if not found:
        findings.append(Finding("Open Redirect", "PASS",
            "✓ Sem open redirect detectado nos parâmetros comuns"))

    return findings


def check_methods(base_url: str, timeout: float) -> List[Finding]:
    findings: List[Finding] = []
    risky = ["PUT", "DELETE", "TRACE", "CONNECT", "DEBUG", "PROPFIND"]

    status, headers, _, _ = make_request(base_url, timeout=timeout, method="OPTIONS")
    if headers:
        allow = headers.get("allow", headers.get("public", ""))
        if allow:
            allowed = [m.strip().upper() for m in allow.split(",")]
            bad = [m for m in allowed if m in risky]
            if bad:
                findings.append(Finding(
                    "Métodos HTTP",
                    "MEDIUM",
                    f"Métodos perigosos habilitados: {', '.join(bad)}",
                    f"Allow: {allow}",
                    "OWASP A05",
                ))
            else:
                findings.append(Finding("Métodos HTTP", "PASS",
                    f"✓ Métodos permitidos OK: {allow}"))
        else:
            findings.append(Finding("Métodos HTTP", "INFO",
                "OPTIONS não retornou header Allow"))

    # TRACE especificamente
    status_t, _, body_t, _ = make_request(base_url, timeout=timeout, method="TRACE")
    if status_t == 200 and body_t and "TRACE" in body_t.upper():
        findings.append(Finding(
            "Métodos HTTP",
            "MEDIUM",
            "TRACE habilitado (risco de Cross-Site Tracing — XST)",
            "Desabilite o método TRACE no servidor web",
            "CWE-16",
        ))

    return findings


# ──────────────────────────────────────────────────────────
#  MODO FULL — FORMULÁRIOS
# ──────────────────────────────────────────────────────────

def extract_forms(body: str, base_url: str) -> List[Dict[str, Any]]:
    """Extrai formulários e campos do HTML."""
    forms: List[Dict[str, Any]] = []
    parsed = urllib.parse.urlparse(base_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    for form_match in re.finditer(
        r"<form[^>]*>(.*?)</form>",
        body,
        re.IGNORECASE | re.DOTALL,
    ):
        form_html = form_match.group(0)
        attrs = form_match.group(0)

        action_m = re.search(r'action=["\']?([^"\'>\s]+)', attrs, re.IGNORECASE)
        method_m = re.search(r'method=["\']?([^"\'>\s]+)', attrs, re.IGNORECASE)

        action = action_m.group(1) if action_m else base_url
        method = (method_m.group(1) if method_m else "GET").upper()

        if not action.startswith("http"):
            action = urllib.parse.urljoin(base_url, action)

        inputs: List[Dict[str, str]] = []
        for inp in re.finditer(
            r'<input[^>]*>',
            form_html,
            re.IGNORECASE,
        ):
            inp_html = inp.group(0)
            name_m  = re.search(r'name=["\']?([^"\'>\s]+)', inp_html, re.IGNORECASE)
            type_m  = re.search(r'type=["\']?([^"\'>\s]+)', inp_html, re.IGNORECASE)
            val_m   = re.search(r'value=["\']?([^"\'>\s]*)', inp_html, re.IGNORECASE)

            inp_type = (type_m.group(1) if type_m else "text").lower()
            if inp_type in ("submit", "button", "image", "reset", "file", "hidden", "checkbox", "radio"):
                continue

            inputs.append({
                "name":  name_m.group(1) if name_m else "",
                "type":  inp_type,
                "value": val_m.group(1) if val_m else "test",
            })

        if inputs:
            forms.append({"action": action, "method": method, "inputs": inputs})

    return forms


def test_sqli(forms: List[Dict[str, Any]], timeout: float) -> List[Finding]:
    findings: List[Finding] = []
    tested = set()

    for form in forms:
        action = form["action"]
        method = form["method"]
        inputs = form["inputs"]

        for payload in SQLI_PAYLOADS:
            data_dict = {inp["name"]: payload for inp in inputs if inp["name"]}
            if not data_dict:
                continue

            key = f"{action}:{payload[:20]}"
            if key in tested:
                continue
            tested.add(key)

            if method == "POST":
                encoded = urllib.parse.urlencode(data_dict).encode()
                status, hdrs, body, _ = make_request(
                    action, timeout=timeout, method="POST",
                    data=encoded,
                    extra_headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
            else:
                url = action + "?" + urllib.parse.urlencode(data_dict)
                status, hdrs, body, _ = make_request(url, timeout=timeout)

            if body:
                body_lower = body.lower()
                for err in SQL_ERRORS:
                    if err in body_lower:
                        parsed = urllib.parse.urlparse(action)
                        path = parsed.path or "/"
                        findings.append(Finding(
                            "SQLi",
                            "HIGH",
                            f"Possível SQL Injection em {path}",
                            f"Erro detectado na resposta com payload: {payload[:50]!r}\n"
                            f"          Indicador: '{err}'",
                            "OWASP A03:2021 / CWE-89",
                        ))
                        break

    if not findings:
        findings.append(Finding("SQLi", "PASS",
            "✓ Nenhuma resposta de erro SQL detectada nos formulários testados"))

    return findings


def test_xss(forms: List[Dict[str, Any]], timeout: float) -> List[Finding]:
    findings: List[Finding] = []
    tested: set = set()

    for form in forms:
        action = form["action"]
        method = form["method"]
        inputs = form["inputs"]

        for payload in XSS_PAYLOADS:
            data_dict = {inp["name"]: payload for inp in inputs if inp["name"]}
            if not data_dict:
                continue

            key = f"{action}:xss:{payload[:20]}"
            if key in tested:
                continue
            tested.add(key)

            if method == "POST":
                encoded = urllib.parse.urlencode(data_dict).encode()
                status, hdrs, body, _ = make_request(
                    action, timeout=timeout, method="POST",
                    data=encoded,
                    extra_headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
            else:
                url = action + "?" + urllib.parse.urlencode(data_dict)
                status, hdrs, body, _ = make_request(url, timeout=timeout)

            if body:
                for indicator in XSS_REFLECTED:
                    if indicator.lower() in body.lower():
                        parsed_u = urllib.parse.urlparse(action)
                        path = parsed_u.path or "/"
                        findings.append(Finding(
                            "XSS",
                            "HIGH",
                            f"XSS Refletido em {path}",
                            f"Payload refletido sem sanitização: {payload[:60]!r}",
                            "OWASP A03:2021 / CWE-79",
                        ))
                        break

    if not findings:
        findings.append(Finding("XSS", "PASS",
            "✓ Nenhum XSS refletido detectado nos formulários testados"))

    return findings


# ──────────────────────────────────────────────────────────
#  SCANNER PRINCIPAL
# ──────────────────────────────────────────────────────────

class WebScanner:
    def __init__(
        self,
        url: str,
        timeout: float = 8.0,
        full: bool = False,
        quiet: bool = False,
        output: Optional[str] = None,
    ) -> None:
        # Normaliza URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self.url     = url
        self.timeout = timeout
        self.full    = full
        self.quiet   = quiet
        self.output  = output
        self.parsed  = urllib.parse.urlparse(url)
        self.host    = self.parsed.hostname or ""
        self.is_https = self.parsed.scheme == "https"
        self.findings: List[Finding] = []
        self.start_ts = datetime.now(timezone.utc)

    def _log(self, msg: str, color: str = C.CYAN) -> None:
        if not self.quiet:
            print(colored(msg, color))

    def _section(self, title: str) -> None:
        if not self.quiet:
            bar = "─" * (50 - len(title) - 3)
            print(f"\n{colored('┌── ' + title + ' ' + bar, C.CYAN)}")

    def _add(self, findings: List[Finding]) -> None:
        self.findings.extend(findings)
        for f in findings:
            f.print_line(self.quiet)

    def run(self) -> int:
        """Executa o scan. Retorna 0 se sem achados críticos/high, 1 se houver."""
        self._print_banner()

        # 1. Requisição principal
        self._section("Requisição inicial")
        self._log(f"  → {self.url}", C.GRAY)
        status, headers, body, final_url = make_request(self.url, self.timeout)

        if status is None:
            print(colored(f"\n[ERRO] Não foi possível conectar a {self.url}", C.RED))
            print(colored("       Verifique se o alvo está acessível e o URL está correto.", C.GRAY))
            return 2

        headers = headers or {}
        body = body or ""
        self._log(f"  HTTP {status} | {len(body)} bytes | {final_url}", C.GRAY)

        if final_url != self.url:
            self._log(f"  Redirecionado para: {final_url}", C.GRAY)

        # 2. Headers de segurança
        self._section("Headers de Segurança")
        self._add(check_security_headers(headers, self.url))

        # 3. Cookies
        self._section("Cookies")
        self._add(check_cookies(headers, self.is_https))

        # 4. SSL/TLS
        if self.is_https:
            self._section("SSL / TLS")
            self._add(check_ssl(self.host))

        # 5. Arquivos sensíveis
        self._section("Arquivos e Caminhos Expostos")
        self._log(f"  Verificando {len(SENSITIVE_PATHS)} caminhos…", C.GRAY)
        self._add(check_sensitive_paths(self.url, self.timeout, self.quiet))

        # 6. Métodos HTTP
        self._section("Métodos HTTP")
        self._add(check_methods(self.url, self.timeout))

        # 7. Open redirect
        self._section("Open Redirect")
        self._add(check_open_redirect(self.url, self.timeout))

        # 8. Modo FULL — formulários
        if self.full:
            self._section("Formulários — SQLi e XSS  [--full]")
            forms = extract_forms(body, self.url)
            if forms:
                self._log(f"  {len(forms)} formulário(s) encontrado(s)", C.GRAY)
                self._add(test_sqli(forms, self.timeout))
                self._add(test_xss(forms, self.timeout))
            else:
                self._log("  Nenhum formulário encontrado na página inicial", C.GRAY)

        self._print_summary()
        self._export()

        critical_high = sum(
            1 for f in self.findings
            if f.severity in ("CRITICAL", "HIGH")
        )
        return 1 if critical_high else 0

    def _print_banner(self) -> None:
        print(colored(f"""
╔══════════════════════════════════════════════════════╗
║          Web Application Security Scanner            ║
║          python-security v{VERSION:<6}  by Matheus S.  ║
╚══════════════════════════════════════════════════════╝
  Alvo    : {self.url}
  Modo    : {"FULL (headers + paths + forms)" if self.full else "padrão (headers + paths)"}
  Timeout : {self.timeout}s
  Início  : {self.start_ts.strftime('%Y-%m-%d %H:%M:%S UTC')}
""", C.CYAN))

    def _print_summary(self) -> None:
        elapsed = (datetime.now(timezone.utc) - self.start_ts).total_seconds()

        counts: Dict[str, int] = {}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1

        print(colored(f"""
╔══════════════════════════════════════════════════════╗
║                   RESUMO DO SCAN                     ║
╠══════════════════════════════════════════════════════╣""", C.CYAN))

        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "PASS"):
            n = counts.get(sev, 0)
            if n:
                color = C.sev(sev)
                print(colored(f"║  {sev:<10} {n:>3} achado(s)" + " " * 30 + "║", color))

        total   = len(self.findings)
        risky   = sum(counts.get(s, 0) for s in ("CRITICAL", "HIGH", "MEDIUM"))
        score   = max(0, 100 - (counts.get("CRITICAL", 0) * 25) -
                               (counts.get("HIGH", 0) * 15)     -
                               (counts.get("MEDIUM", 0) * 5)    -
                               (counts.get("LOW", 0) * 2))

        grade = "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D" if score >= 40 else "F"
        grade_color = (C.GREEN if grade in ("A",) else
                       C.YELLOW if grade in ("B", "C") else C.RED)

        print(colored(f"""╠══════════════════════════════════════════════════════╣
║  Total achados : {total:<3}  |  Risco ativo : {risky:<3}               ║
║  Score estimado: {score:>3}/100  |  Nota : {grade}                      ║
║  Duração       : {elapsed:.1f}s                                  ║
╚══════════════════════════════════════════════════════╝""", C.CYAN))

        if self.output:
            print(colored(f"\n  Relatório JSON → {self.output}", C.GRAY))

    def _export(self) -> None:
        if not self.output:
            return

        report = {
            "tool":      "web_scanner.py",
            "version":   VERSION,
            "target":    self.url,
            "timestamp": self.start_ts.isoformat(),
            "mode":      "full" if self.full else "standard",
            "summary": {
                sev: sum(1 for f in self.findings if f.severity == sev)
                for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "PASS")
            },
            "findings": [f.to_dict() for f in self.findings
                         if f.severity != "PASS"],
        }

        try:
            with open(self.output, "w", encoding="utf-8") as fp:
                json.dump(report, fp, ensure_ascii=False, indent=2)
        except OSError as e:
            print(colored(f"[ERRO] Não foi possível salvar {self.output}: {e}", C.RED))


# ──────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="web_scanner.py",
        description="Scanner de segurança de aplicações web — uso educacional e em ambientes autorizados",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
exemplos:
  python web_scanner.py https://meusite.com
  python web_scanner.py https://meusite.com --full
  python web_scanner.py https://meusite.com -o relatorio.json
  python web_scanner.py https://meusite.com --timeout 15 -q

⚠️  Use apenas em sistemas que você possui ou tem autorização escrita para testar.
""",
    )
    p.add_argument("url",       help="URL alvo (ex: https://alvo.com)")
    p.add_argument("--full",    action="store_true",
                   help="Modo completo: inclui testes de SQLi e XSS em formulários")
    p.add_argument("--timeout", type=float, default=8.0, metavar="SEG",
                   help="Timeout por requisição em segundos (padrão: 8)")
    p.add_argument("-o", "--output", metavar="ARQUIVO",
                   help="Exportar relatório em JSON")
    p.add_argument("-q", "--quiet", action="store_true",
                   help="Modo silencioso: exibe apenas achados relevantes")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    scanner = WebScanner(
        url=args.url,
        timeout=args.timeout,
        full=args.full,
        quiet=args.quiet,
        output=args.output,
    )
    return scanner.run()


if __name__ == "__main__":
    sys.exit(main())

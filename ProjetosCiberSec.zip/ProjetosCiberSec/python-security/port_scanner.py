#!/usr/bin/env python3
"""
port_scanner.py — Multi-threaded TCP port scanner with banner grabbing
Part of: python-security
Author: Matheus Sanches | securescopeai.com
"""

from __future__ import annotations  # compatibilidade Python 3.7+

import socket
import concurrent.futures
import argparse
import json
import sys
import time
from datetime import datetime

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
    6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB",
    9200: "Elasticsearch", 11211: "Memcached", 2181: "Zookeeper",
}

HIGH_RISK_PORTS = {23, 21, 445, 3389, 5900, 6379, 27017, 9200, 11211}


def resolve_host(target: str) -> str:
    try:
        return socket.gethostbyname(target)
    except socket.gaierror:
        print(f"[ERROR] Could not resolve: {target}")
        sys.exit(1)


def grab_banner(ip: str, port: int, timeout: float) -> str:
    probes = [b"HEAD / HTTP/1.0\r\n\r\n", b"\r\n", b"HELP\r\n"]
    for probe in probes:
        try:
            with socket.create_connection((ip, port), timeout=timeout) as s:
                s.send(probe)
                raw = s.recv(512).decode("utf-8", errors="ignore").strip()
                if raw:
                    return raw.split("\n")[0][:100]
        except Exception:
            continue
    return ""


def scan_port(ip: str, port: int, timeout: float) -> dict | None:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            service = COMMON_PORTS.get(port, "unknown")
            banner = grab_banner(ip, port, timeout)
            risk = "HIGH" if port in HIGH_RISK_PORTS else "MEDIUM" if port < 1024 else "LOW"
            return {
                "port": port,
                "state": "open",
                "service": service,
                "banner": banner,
                "risk": risk,
            }
    except (socket.timeout, ConnectionRefusedError, OSError):
        return None


def parse_ports(port_arg: str) -> list[int]:
    ports = set()
    for part in port_arg.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = part.split("-", 1)
            ports.update(range(int(lo), int(hi) + 1))
        else:
            ports.add(int(part))
    return sorted(ports)


def print_result(r: dict):
    risk_color = {"HIGH": "\033[91m", "MEDIUM": "\033[93m", "LOW": "\033[92m"}
    reset = "\033[0m"
    color = risk_color.get(r["risk"], "")
    banner_str = f"  → {r['banner']}" if r["banner"] else ""
    print(f"  {color}[{r['risk']:<6}]{reset}  {r['port']:>5}/tcp  {r['service']:<18} {banner_str}")


def print_report(target: str, ip: str, results: list[dict], elapsed: float):
    print("\n" + "═" * 65)
    print(f"  TARGET : {target} ({ip})")
    print(f"  DATE   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  TIME   : {elapsed:.2f}s")
    print("═" * 65)

    if not results:
        print("  No open ports found.")
    else:
        high = [r for r in results if r["risk"] == "HIGH"]
        if high:
            print(f"\n  ⚠️  HIGH RISK ports: {', '.join(str(r['port']) for r in high)}")
        for r in results:
            print_result(r)

    print(f"\n  Total open: {len(results)} port(s)")
    print("═" * 65 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Multi-threaded TCP port scanner with banner grabbing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python port_scanner.py 192.168.1.1
  python port_scanner.py scanme.nmap.org -p 1-1000 -o report.json
  python port_scanner.py 10.0.0.1 -p 80,443,8080 -T 100 -t 0.5
        """,
    )
    parser.add_argument("target", help="Hostname or IP to scan")
    parser.add_argument(
        "-p", "--ports",
        default=",".join(str(p) for p in COMMON_PORTS),
        help="Ports: 80,443 | 1-1024 | default: common ports",
    )
    parser.add_argument("-t", "--timeout", type=float, default=1.0, help="Timeout per port (default: 1.0s)")
    parser.add_argument("-T", "--threads", type=int, default=50, help="Thread count (default: 50)")
    parser.add_argument("-o", "--output", metavar="FILE", help="Save JSON report to file")
    parser.add_argument("-q", "--quiet", action="store_true", help="Only show open ports summary")
    args = parser.parse_args()

    ip = resolve_host(args.target)
    ports = parse_ports(args.ports)

    if not args.quiet:
        print(f"\n[*] Scanning {args.target} ({ip}) — {len(ports)} ports | {args.threads} threads")
        print(f"[*] Started at {datetime.now().strftime('%H:%M:%S')}\n")

    t0 = time.time()
    open_ports = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as pool:
        futures = {pool.submit(scan_port, ip, p, args.timeout): p for p in ports}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                open_ports.append(result)
                if not args.quiet:
                    print(f"  [+] {result['port']}/tcp open ({result['service']})")

    elapsed = time.time() - t0
    open_ports.sort(key=lambda x: x["port"])
    print_report(args.target, ip, open_ports, elapsed)

    if args.output:
        report = {
            "target": args.target,
            "ip": ip,
            "scanned_at": datetime.now().isoformat(),
            "elapsed_seconds": round(elapsed, 2),
            "open_ports": open_ports,
        }
        with open(args.output, "w") as f:
            json.dump(report, f, indent=2)
        print(f"[*] JSON report saved: {args.output}\n")


if __name__ == "__main__":
    main()

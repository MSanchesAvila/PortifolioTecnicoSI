#!/usr/bin/env python3
"""
hash_cracker.py — Hash identifier + dictionary/brute-force attack
Part of: python-security
Author: Matheus Sanches | securescopeai.com
"""

from __future__ import annotations  # compatibilidade Python 3.7+

import hashlib
import argparse
import itertools
import string
import sys
import time
from pathlib import Path


# ── Hash identification ────────────────────────────────────────────────────────

HASH_SIGNATURES = {
    32:  ["md5"],
    40:  ["sha1"],
    56:  ["sha224"],
    64:  ["sha256"],
    96:  ["sha384"],
    128: ["sha512"],
}

SUPPORTED_ALGORITHMS = ["md5", "sha1", "sha224", "sha256", "sha384", "sha512"]


def identify_hash(hash_str: str) -> list[str]:
    """Return list of possible algorithms based on hash length."""
    length = len(hash_str)
    candidates = HASH_SIGNATURES.get(length, [])
    # Basic hex check
    try:
        int(hash_str, 16)
    except ValueError:
        return []
    return candidates


def compute_hash(text: str, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    h.update(text.encode("utf-8"))
    return h.hexdigest()


# ── Dictionary attack ──────────────────────────────────────────────────────────

def dictionary_attack(target_hash: str, algorithms: list[str], wordlist_path: str) -> tuple[str, str] | None:
    path = Path(wordlist_path)
    if not path.exists():
        print(f"[ERROR] Wordlist not found: {wordlist_path}")
        sys.exit(1)

    total = 0
    t0 = time.time()
    print(f"[*] Dictionary attack | wordlist: {wordlist_path} | algorithms: {', '.join(algorithms)}")

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                word = line.rstrip("\n")
                total += 1
                for algo in algorithms:
                    if compute_hash(word, algo) == target_hash:
                        elapsed = time.time() - t0
                        print(f"\n[+] CRACKED in {elapsed:.2f}s after {total:,} attempts")
                        return word, algo
                if total % 100_000 == 0:
                    speed = total / (time.time() - t0)
                    print(f"  [{total:>10,}] tried — {speed:,.0f} H/s", end="\r")
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user")

    elapsed = time.time() - t0
    print(f"\n[-] Not found. Tried {total:,} words in {elapsed:.2f}s")
    return None


# ── Brute-force attack ─────────────────────────────────────────────────────────

CHARSETS = {
    "digits":      string.digits,
    "alpha":       string.ascii_lowercase,
    "ALPHA":       string.ascii_uppercase,
    "alnum":       string.ascii_lowercase + string.digits,
    "full":        string.printable.strip(),
}


def brute_force_attack(
    target_hash: str, algorithms: list[str],
    min_len: int, max_len: int, charset_name: str
) -> tuple[str, str] | None:

    charset = CHARSETS.get(charset_name, string.ascii_lowercase + string.digits)
    total = 0
    t0 = time.time()

    print(f"[*] Brute-force | len {min_len}-{max_len} | charset: {charset_name} ({len(charset)} chars)")

    for length in range(min_len, max_len + 1):
        print(f"[*] Trying length {length}...")
        for combo in itertools.product(charset, repeat=length):
            candidate = "".join(combo)
            total += 1
            for algo in algorithms:
                if compute_hash(candidate, algo) == target_hash:
                    elapsed = time.time() - t0
                    print(f"\n[+] CRACKED: '{candidate}' ({algo}) in {elapsed:.2f}s after {total:,} attempts")
                    return candidate, algo
            if total % 500_000 == 0:
                speed = total / (time.time() - t0)
                print(f"  [{total:>12,}] {candidate!r} — {speed:,.0f} H/s", end="\r")

    elapsed = time.time() - t0
    print(f"\n[-] Not cracked. {total:,} combinations in {elapsed:.2f}s")
    return None


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Hash identifier and cracker (dictionary + brute-force)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Auto-detect and crack with wordlist
  python hash_cracker.py 5f4dcc3b5aa765d61d8327deb882cf99 -w rockyou.txt

  # Force MD5, dictionary attack
  python hash_cracker.py <hash> -a md5 -w /usr/share/wordlists/rockyou.txt

  # Brute force SHA1, digits only, up to 6 chars
  python hash_cracker.py <hash> -a sha1 --brute --charset digits --max-len 6
        """,
    )
    parser.add_argument("hash", help="Hash string to crack")
    parser.add_argument("-a", "--algorithm", choices=SUPPORTED_ALGORITHMS, help="Force specific algorithm")
    parser.add_argument("-w", "--wordlist", metavar="FILE", help="Path to wordlist file")
    parser.add_argument("--brute", action="store_true", help="Use brute-force mode")
    parser.add_argument("--min-len", type=int, default=1, help="Min length for brute-force (default: 1)")
    parser.add_argument("--max-len", type=int, default=6, help="Max length for brute-force (default: 6)")
    parser.add_argument("--charset", choices=list(CHARSETS.keys()), default="alnum",
                        help="Charset for brute-force (default: alnum)")
    args = parser.parse_args()

    target = args.hash.lower().strip()
    print(f"\n[*] Target hash : {target}")
    print(f"[*] Length      : {len(target)}")

    # Identify hash type
    if args.algorithm:
        algorithms = [args.algorithm]
    else:
        algorithms = identify_hash(target)
        if not algorithms:
            print("[ERROR] Could not identify hash type. Use -a to specify.")
            sys.exit(1)
        print(f"[*] Possible types: {', '.join(algorithms)}")

    result = None

    if args.wordlist:
        result = dictionary_attack(target, algorithms, args.wordlist)
    elif args.brute:
        result = brute_force_attack(target, algorithms, args.min_len, args.max_len, args.charset)
    else:
        print("[ERROR] Specify --wordlist or --brute mode.")
        parser.print_help()
        sys.exit(1)

    if result:
        plaintext, algo = result
        print("\n" + "=" * 50)
        print(f"  HASH      : {target}")
        print(f"  ALGORITHM : {algo}")
        print(f"  PLAINTEXT : {plaintext}")
        print("=" * 50 + "\n")
    else:
        print("\n[!] Hash could not be cracked with current settings.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()

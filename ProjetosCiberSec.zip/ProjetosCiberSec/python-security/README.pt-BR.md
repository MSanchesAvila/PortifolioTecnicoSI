# 🐍 python-security

> 🇧🇷 Leia em Português | [🇺🇸 Read in English](README.md)

Coleção de ferramentas de segurança ofensivas e defensivas escritas em Python. Desenvolvidas para fins educacionais, desafios CTF e avaliações de segurança em ambientes autorizados.

> ⚠️ **Aviso Legal:** Estas ferramentas são para uso educacional e em ambientes autorizados. O uso não autorizado contra sistemas que você não possui ou não tem permissão explícita para testar é ilegal e passível de penalidades criminais.

---

## 📂 Ferramentas

| Script | Categoria | Descrição |
|--------|-----------|-----------|
| `port_scanner.py` | Reconhecimento | Scanner TCP multi-thread com captura de banner |
| `hash_cracker.py` | Criptoanálise | Identificador de hash + ataque de dicionário e força bruta |
| `log_analyzer.py` | Blue Team | Analisador de logs para detecção de padrões suspeitos |

---

## ⚙️ Requisitos

- **Python 3.7+** (todos os scripts usam apenas biblioteca padrão)
- Sem dependências externas obrigatórias

```bash
# Instale opcionais para recursos extras
pip install -r requirements.txt
```

---

## 🚀 Como Usar

### 🔍 Port Scanner — `port_scanner.py`

Varre portas TCP de um alvo, tenta capturar o banner do serviço e classifica o risco de cada porta aberta (HIGH / MEDIUM / LOW).

**Portas de alto risco pré-definidas:** RDP (3389), SMB (445), Telnet (23), Redis (6379), VNC (5900), MongoDB (27017), entre outras.

```bash
# Scan nas portas comuns (padrão)
python port_scanner.py 192.168.1.1

# Range de portas com exportação JSON
python port_scanner.py scanme.nmap.org -p 1-1000 -o relatorio.json

# Portas específicas, 100 threads, timeout curto
python port_scanner.py 10.0.0.1 -p 80,443,8080,8443 -T 100 -t 0.5

# Modo silencioso (só exibe resumo)
python port_scanner.py 192.168.1.1 -q
```

**Parâmetros:**

| Parâmetro | Padrão | Descrição |
|-----------|--------|-----------|
| `target` | — | IP ou hostname alvo |
| `-p, --ports` | portas comuns | Ex: `80,443` ou `1-1024` |
| `-t, --timeout` | `1.0s` | Tempo limite por porta |
| `-T, --threads` | `50` | Número de threads paralelas |
| `-o, --output` | — | Salva relatório em JSON |
| `-q, --quiet` | False | Modo silencioso |

**Exemplo de saída:**
```
  [HIGH  ]    445/tcp  SMB                → Microsoft Windows SMB
  [HIGH  ]   3389/tcp  RDP
  [MEDIUM]     80/tcp  HTTP               → Apache/2.4.41
  [LOW   ]   8080/tcp  HTTP-Alt
```

---

### 🔐 Hash Cracker — `hash_cracker.py`

Identifica automaticamente o tipo de hash pelo comprimento e ataca via dicionário ou força bruta.

**Algoritmos suportados:** MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512

```bash
# Identificar e atacar com wordlist (recomendado)
python hash_cracker.py 5f4dcc3b5aa765d61d8327deb882cf99 -w rockyou.txt

# Forçar algoritmo MD5 + wordlist
python hash_cracker.py 5f4dcc3b5aa765d61d8327deb882cf99 -a md5 -w wordlist.txt

# Força bruta: SHA-1, somente dígitos, até 6 caracteres
python hash_cracker.py <hash> -a sha1 --brute --charset digits --max-len 6

# Força bruta alfanumérica, de 3 a 4 caracteres
python hash_cracker.py <hash> --brute --charset alnum --min-len 3 --max-len 4
```

**Charsets para força bruta:**

| Nome | Conteúdo |
|------|----------|
| `digits` | 0–9 |
| `alpha` | a–z |
| `ALPHA` | A–Z |
| `alnum` | a–z + 0–9 |
| `full` | Todos os caracteres imprimíveis |

**Exemplo de saída:**
```
[*] Target hash : 5f4dcc3b5aa765d61d8327deb882cf99
[*] Possible types: md5
[*] Dictionary attack | wordlist: rockyou.txt
[+] CRACKED in 0.43s after 3,561 attempts

==================================================
  HASH      : 5f4dcc3b5aa765d61d8327deb882cf99
  ALGORITHM : md5
  PLAINTEXT : password
==================================================
```

---

### 📋 Log Analyzer — `log_analyzer.py`

Analisa logs de segurança e detecta padrões maliciosos em dois modos.

**Modo SSH** — analisa `/var/log/auth.log`:
- Detecção de brute-force por IP (threshold configurável)
- Usuários inválidos tentados por endereço
- Logins bem-sucedidos (possível acesso legítimo ou pós-comprometimento)
- Alta contagem de badlogons

**Modo HTTP** — analisa logs Apache/Nginx:
- Injeção SQL (UNION SELECT, DROP TABLE, `'--`, OR 1=1)
- XSS (`<script>`, `onerror=`, `alert(`)
- Path Traversal (`../`, `%2e%2e`)
- IPs de scanners conhecidos (Nikto, SQLMap, Burp Suite, Nmap)

```bash
# Analisar log SSH
python log_analyzer.py /var/log/auth.log --type ssh

# Threshold personalizado: flagar IPs com 3+ falhas
python log_analyzer.py /var/log/auth.log --type ssh --threshold 3

# Analisar log HTTP do Nginx
python log_analyzer.py /var/log/nginx/access.log --type http

# Exportar relatório JSON
python log_analyzer.py auth.log --type ssh -o relatorio.json
```

**Exemplo de saída (SSH):**
```
  Failed attempts  : 1.847
  Unique IPs       : 23
  Successful logins: 2

  ⚠️  BRUTE FORCE SUSPECTS (3 IPs):
    185.220.101.45     1421 attempts | users: root, admin, ubuntu, pi
    45.33.32.156        312 attempts | users: root, test
    192.168.1.105        82 attempts | users: matheus, administrator
```

---

## 📁 Estrutura do Projeto

```
python-security/
├── port_scanner.py       # Scanner TCP multi-thread
├── hash_cracker.py       # Identificador + quebrador de hash
├── log_analyzer.py       # Analisador de logs SSH e HTTP
├── requirements.txt      # Dependências opcionais
├── README.md             # Documentação em inglês
└── README.pt-BR.md       # Este arquivo
```

---

## 🛡️ Casos de Uso Reais

- **CTF / Wargames:** Use `port_scanner.py` para reconhecimento inicial e `hash_cracker.py` em desafios de criptografia
- **Pentest autorizado:** Mapeamento de superfície de ataque com o scanner
- **Blue Team / SOC:** `log_analyzer.py` para triagem rápida de logs em resposta a incidentes
- **Treinamento:** Excelente base para entender como ferramentas como Nmap, Hashcat e SIEM funcionam por dentro

---

## ⚠️ Ética e Uso Responsável

- Use somente em sistemas que você **possui** ou tem **autorização escrita** para testar
- Em ambientes corporativos, obtenha sempre aprovação do time de segurança (Rules of Engagement)
- Testes não autorizados podem violar a Lei nº 12.737/2012 (Lei Carolina Dieckmann) e o Marco Civil da Internet

---

## 👨‍💻 Autor

**Matheus Sanches**  
Especialista em Cibersegurança | [SecureScope AI](https://securescopeai.com)  
📧 matheus.sanches@securescopeai.com

---

## 📄 Licença

MIT License — livre para usar, modificar e distribuir com atribuição.

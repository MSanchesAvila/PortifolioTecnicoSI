#!/usr/bin/env python3
"""
log_analyzer.py — Log parser for detecting suspicious security patterns
Supports: SSH auth logs, Apache/Nginx HTTP logs, Windows-style auth logs
Part of: python-security
Author: Matheus Sanches | securescopeai.com
"""

import re
import sys
import json
import argparse
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime


# ── Patterns ──────────────────────────────────────────────────────────────────

SSH_PATTERNS = {
    "failed_login":    re.compile(r"Failed password for (?:invalid user )?(\S+) from ([\d.]+)"),
    "invalid_user":    re.compile(r"Invalid user (\S+) from ([\d.]+)"),
    "accepted_login":  re.compile(r"Accepted (?:password|publickey) for (\S+) from ([\d.]+)"),
    "brute_force_hint":re.compile(r"error: maximum authentication attempts exceeded for (\S+) from ([\d.]+)"),
    "disconnect":      re.compile(r"Disconnected from (?:invalid user )?(?:\S+ )?([\d.]+)"),
}

HTTP_PATTERNS = {
    "access":         re.compile(r'([\d.]+) .+ "(\w+) ([^\s"]+)[^"]*" (\d{3}) (\d+)'),
    "sqli_hint":      re.compile(r"(?i)(union\s+select|drop\s+table|insert\s+into|'--|\bor\s+1=1)"),
    "xss_hint":       re.compile(r"(?i)(<script|javascript:|onerror=|onload=|alert\()"),
    "path_traversal": re.compile(r"(\.\./|%2e%2e%2f|%252e%252e)", re.IGNORECASE),
    "scanner_ua":     re.compile(r"(?i)(nikto|sqlmap|nmap|masscan|burpsuite|metasploit|python-requests/2\.)"),
}


# ── SSH Log Analyzer ───────────────────────────────────────────────────────────

class SSHLogAnalyzer:
    def __init__(self, threshold: int = 5):
        self.threshold = threshold
        self.failed = defaultdict(int)       # IP -> count
        self.failed_users = defaultdict(set) # IP -> {users tried}
        self.accepted = []
        self.alerts = []

    def process_line(self, line: str):
        if m := SSH_PATTERNS["failed_login"].search(line):
            user, ip = m.group(1), m.group(2)
            self.failed[ip] += 1
            self.failed_users[ip].add(user)

        if m := SSH_PATTERNS["invalid_user"].search(line):
            user, ip = m.group(1), m.group(2)
            self.failed[ip] += 1
            self.failed_users[ip].add(user)

        if m := SSH_PATTERNS["accepted_login"].search(line):
            self.accepted.append({"user": m.group(1), "ip": m.group(2)})

        if m := SSH_PATTERNS["brute_force_hint"].search(line):
            self.alerts.append({"type": "brute_force_detected", "user": m.group(1), "ip": m.group(2)})

    def summarize(self) -> dict:
        brute_ips = {ip: cnt for ip, cnt in self.failed.items() if cnt >= self.threshold}
        return {
            "total_failed_attempts": sum(self.failed.values()),
            "unique_ips_failed": len(self.failed),
            "successful_logins": len(self.accepted),
            "brute_force_suspects": [
                {"ip": ip, "attempts": cnt, "users_tried": list(self.failed_users[ip])}
                for ip, cnt in sorted(brute_ips.items(), key=lambda x: -x[1])
            ],
            "successful_logins_detail": self.accepted,
            "extra_alerts": self.alerts,
        }


# ── HTTP Log Analyzer ──────────────────────────────────────────────────────────

class HTTPLogAnalyzer:
    def __init__(self):
        self.requests = []
        self.attacks = []
        self.ip_counter = Counter()
        self.status_counter = Counter()
        self.scanner_ips = set()

    def process_line(self, line: str):
        m = HTTP_PATTERNS["access"].search(line)
        if not m:
            return
        ip, method, path, status, size = m.groups()
        self.ip_counter[ip] += 1
        self.status_counter[status] += 1

        # Check for attack signatures in the full line
        for attack_type, pattern in [
            ("sql_injection", HTTP_PATTERNS["sqli_hint"]),
            ("xss",           HTTP_PATTERNS["xss_hint"]),
            ("path_traversal",HTTP_PATTERNS["path_traversal"]),
        ]:
            if pattern.search(line):
                self.attacks.append({
                    "type": attack_type,
                    "ip": ip,
                    "method": method,
                    "path": path[:200],
                    "status": status,
                })

        if HTTP_PATTERNS["scanner_ua"].search(line):
            self.scanner_ips.add(ip)

    def summarize(self) -> dict:
        return {
            "total_requests": sum(self.ip_counter.values()),
            "unique_ips": len(self.ip_counter),
            "status_distribution": dict(self.status_counter.most_common()),
            "top_ips": [{"ip": ip, "requests": n} for ip, n in self.ip_counter.most_common(10)],
            "attack_signatures_found": len(self.attacks),
            "attacks": self.attacks[:50],  # cap at 50
            "scanner_ips": list(self.scanner_ips),
        }


# ── Report output ──────────────────────────────────────────────────────────────

def print_ssh_report(data: dict):
    print("\n" + "═" * 60)
    print("  SSH LOG ANALYSIS REPORT")
    print("═" * 60)
    print(f"  Failed attempts  : {data['total_failed_attempts']}")
    print(f"  Unique IPs       : {data['unique_ips_failed']}")
    print(f"  Successful logins: {data['successful_logins']}")

    suspects = data["brute_force_suspects"]
    if suspects:
        print(f"\n  ⚠️  BRUTE FORCE SUSPECTS ({len(suspects)} IPs):")
        for s in suspects[:10]:
            print(f"    {s['ip']:<18} {s['attempts']:>5} attempts | users: {', '.join(list(s['users_tried'])[:5])}")
    else:
        print("\n  ✅ No brute-force activity detected.")

    if data["successful_logins_detail"]:
        print("\n  ✅ SUCCESSFUL LOGINS:")
        for login in data["successful_logins_detail"][:10]:
            print(f"    {login['ip']:<18} user: {login['user']}")

    print("═" * 60 + "\n")


def print_http_report(data: dict):
    print("\n" + "═" * 60)
    print("  HTTP LOG ANALYSIS REPORT")
    print("═" * 60)
    print(f"  Total requests   : {data['total_requests']}")
    print(f"  Unique IPs       : {data['unique_ips']}")
    print(f"  Attack signatures: {data['attack_signatures_found']}")

    print("\n  Status Codes:")
    for code, count in sorted(data["status_distribution"].items()):
        bar = "█" * min(count // 10, 40)
        print(f"    {code}: {count:>6} {bar}")

    if data["scanner_ips"]:
        print(f"\n  ⚠️  SCANNER IPs: {', '.join(data['scanner_ips'])}")

    if data["attacks"]:
        print(f"\n  ⚠️  ATTACK SIGNATURES ({len(data['attacks'])} events):")
        by_type = Counter(a["type"] for a in data["attacks"])
        for attack_type, count in by_type.most_common():
            print(f"    {attack_type:<20} {count} event(s)")

    print("\n  Top 5 IPs by request volume:")
    for entry in data["top_ips"][:5]:
        print(f"    {entry['ip']:<18} {entry['requests']:>6} requests")

    print("═" * 60 + "\n")


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Security log analyzer for SSH and HTTP logs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python log_analyzer.py /var/log/auth.log --type ssh
  python log_analyzer.py /var/log/nginx/access.log --type http
  python log_analyzer.py auth.log --type ssh --threshold 3 -o report.json
        """,
    )
    parser.add_argument("logfile", help="Path to log file")
    parser.add_argument("--type", choices=["ssh", "http"], required=True, help="Log format type")
    parser.add_argument("--threshold", type=int, default=5, help="Failed attempts before flagging (SSH, default: 5)")
    parser.add_argument("-o", "--output", metavar="FILE", help="Save JSON report to file")
    args = parser.parse_args()

    log_path = Path(args.logfile)
    if not log_path.exists():
        print(f"[ERROR] File not found: {log_path}")
        sys.exit(1)

    print(f"[*] Analyzing {log_path} ({log_path.stat().st_size / 1024:.1f} KB)...")
    start = datetime.now()

    if args.type == "ssh":
        analyzer = SSHLogAnalyzer(threshold=args.threshold)
        with open(log_path, "r", errors="ignore") as f:
            for line in f:
                analyzer.process_line(line)
        data = analyzer.summarize()
        print_ssh_report(data)

    else:  # http
        analyzer = HTTPLogAnalyzer()
        with open(log_path, "r", errors="ignore") as f:
            for line in f:
                analyzer.process_line(line)
        data = analyzer.summarize()
        print_http_report(data)

    elapsed = (datetime.now() - start).total_seconds()
    print(f"[*] Analysis completed in {elapsed:.2f}s")

    if args.output:
        with open(args.output, "w") as f:
            json.dump({"type": args.type, "analyzed_at": start.isoformat(), **data}, f, indent=2)
        print(f"[*] Report saved: {args.output}")


if __name__ == "__main__":
    main()

# Royal Cases — POS & Inventory Management System

A full point-of-sale (POS), inventory, customer, and financial management
system, built for a real phone case and accessories store in active
operation. Running in production: FastAPI + PostgreSQL (Supabase) +
Google Cloud Run.

> 🔗 [Ler em português](./README.md)

## About this repository

This is the code behind a system I actually use in my own store. I'm
publishing it as a case study in **how I direct and review AI-assisted
development on a real production project** — not as an exercise, but as
a system with real money, inventory, and customer data running behind it.

**How it was built:** the application code was written with Claude
(Anthropic) as a development pair, over a long, iterative session. **My
part** was specifying every feature based on the store's actual
operation, reviewing and testing every delivery, and handling all
production infrastructure and security configuration myself — Google
Cloud IAM, enabling Row Level Security on Postgres, region/latency
decisions, and all deployment operations and incident fixes in
production (including finding and reporting at least 2 real bugs that
only surfaced after going live). I think it's important to be upfront
about this: the skill this project demonstrates is **specifying,
reviewing, testing, and operating** a system with AI in the loop — which
is, increasingly, the actual day-to-day of working in tech.

## What the system does

- **Full POS**: barcode scanning (camera or USB reader), search by name,
  cart, multiple payment methods with card-fee calculation, region-based
  shipping with an editable value, loyalty point redemption, receipts
  (print, PDF by email, or WhatsApp link)
- **Inventory**: full product registration (variants/grid, factory GTIN,
  condition new/used/refurbished, weight and dimensions, promotional
  pricing), manual stock adjustment with mandatory reason, batch barcode
  label generation and printing (Pimaco A4251 sheet, calculated and
  configurable grid)
- **Customers**: lightweight CRM with purchase history, favorite product,
  recency-based status (active/at-risk/inactive), loyalty program
- **Financials**: daily cash closing, trend chart, per-installment card
  fee configuration, margin dashboard and best-selling products
- **User management**: role-based profiles (manager/clerk) with granular
  permissions, email password recovery, documented emergency recovery
  procedure

## Security highlights

This is the part I most want to showcase. Some concrete examples of what
was found and fixed throughout the project:

- **Stored XSS**: product/customer names were inserted into `innerHTML`
  without escaping across 5 different JS files — since the session token
  lives in `localStorage`, this would have allowed session hijacking.
  Fixed with a centralized escaping function applied at every DOM
  insertion point.
- **User enumeration prevention**: the "forgot password" endpoint
  returns the same generic response whether or not the submitted email
  exists in the system — prevents account discovery via email probing.
- **Row Level Security (Postgres/Supabase)**: identified that Supabase's
  automatic public API left tables accessible via the anonymous key,
  with no RLS enabled. Enabled RLS on all tables (deny-by-default for
  the public API, with zero impact on the backend's direct connection,
  which uses the table-owning role).
- **Login rate limiting**: temporary per-IP lockout after repeated wrong
  password attempts.
- **Never trust the client for financial values**: card fees, shipping,
  and loyalty discounts are always looked up/calculated server-side from
  our own configuration — the request only selects *which* option, never
  the value itself.
- **No hardcoded default password**: if the initial admin password
  environment variable isn't set, the system generates a strong random
  password on its own, instead of falling back to a fixed value in the
  source code.
- **Zero-downtime production schema migration**: any new column added to
  a model is detected and applied automatically to already-existing
  databases, with a safety net that catches and fixes columns missed in
  the manual migration list (I found this exact bug in production myself
  and documented the fix).
- **Negative stock bug**: found and fixed a case where the same product
  split across two separate cart lines could oversell past available
  stock — verified with an automated test reproducing the bug before and
  the fix after.

## Tech stack

- **Backend**: Python, FastAPI, SQLAlchemy, Pydantic
- **Database**: PostgreSQL (Supabase) in production, SQLite for local
  development
- **Frontend**: vanilla HTML/CSS/JavaScript (no framework — a deliberate
  choice to keep the system lightweight)
- **Auth**: JWT + bcrypt
- **Infrastructure**: Docker, Google Cloud Run
- **File generation**: Pillow (barcode labels), ReportLab (PDF receipts
  and labels)
- **Testing**: automated test suite (pytest + FastAPI TestClient)
  covering financial business rules, permissions, and security

## Running locally

```bash
git clone <this-repository>
cd royal_cases
pip install -r requirements.txt --break-system-packages
cp .env.example .env  # fill in your own values
uvicorn app.main:app --reload
```

Without a `DATABASE_URL` set, the system falls back to local SQLite
automatically — no Postgres needed to explore the code.

## License

MIT — see [LICENSE](./LICENSE).

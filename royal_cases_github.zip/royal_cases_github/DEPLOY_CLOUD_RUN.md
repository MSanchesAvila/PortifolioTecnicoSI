# Deploy no Google Cloud Run + Supabase

Guia pra colocar o Royal Cases rodando na nuvem, gratuito, sem depender da
rede da loja.

---

## Passo 1 — Pegar a string de conexão do Supabase

O Supabase mudou onde mostra isso recentemente - hoje fica atrás de um botão
"Connect", não mais direto em Project Settings.

1. Entre no seu projeto em [supabase.com](https://supabase.com)
2. Clique no botão **"Connect"** (fica no topo do painel do projeto, ao lado
   do nome do branch/ambiente)
3. Na janela que abrir, escolha a aba **"Transaction pooler"** (não "Direct
   connection" - explico o porquê abaixo)
4. Copie a URI e substitua `[YOUR-PASSWORD]` pela senha do banco (a que você
   definiu quando criou o projeto - se não lembrar, dá pra resetar em
   Database Settings > Reset database password)

**Por que "Transaction pooler" e não "Direct connection":** o Cloud Run cria
e desliga instâncias com frequência - cada uma abriria uma conexão nova com
o banco se usássemos a conexão direta, e o plano gratuito do Postgres tem um
limite baixo de conexões simultâneas. O pooler (Supavisor) reaproveita
conexões de um pool compartilhado, evitando esgotar esse limite. É a opção
recomendada pela própria documentação do Supabase pra ambientes serverless.

A string vai ficar parecida com (repare na porta `6543`, diferente da porta
`5432` da conexão direta):
```
postgresql://postgres.xxxxxxxx:SUASENHA@aws-0-sa-east-1.pooler.supabase.com:6543/postgres
```

Guarde essa string - é o valor da variável `DATABASE_URL`.

---

## Passo 2 — Instalar o gcloud CLI (se ainda não tiver)

Baixe em: https://cloud.google.com/sdk/docs/install

Depois de instalado, autentique e escolha o projeto:
```
gcloud auth login
gcloud config set project SEU-PROJETO-ID
```

---

## Passo 3 — Deploy

Dentro da pasta do projeto (`royal_cases`), rode:

```
gcloud run deploy royal-cases ^
  --source . ^
  --region southamerica-east1 ^
  --allow-unauthenticated ^
  --set-env-vars DATABASE_URL="postgresql://postgres.xxxxxxxx:SUASENHA@aws-0-sa-east-1.pooler.supabase.com:6543/postgres" ^
  --set-env-vars ROYAL_CASES_SECRET_KEY="SUA-CHAVE-GERADA" ^
  --set-env-vars ROYAL_CASES_ADMIN_SENHA="uma-senha-forte-aqui"
```

(No Windows, use `^` pra quebrar linha no `cmd`; no PowerShell use `` ` `` no lugar)

**O que cada parte faz:**
- `--source .` → o gcloud constrói a imagem Docker automaticamente a partir do `Dockerfile`
- `--region southamerica-east1` → região de São Paulo, menor latência pra loja
- `--allow-unauthenticated` → necessário pra qualquer pessoa (você, os atendentes) acessar sem precisar de login do Google - a segurança de acesso já é feita pelo NOSSO sistema de login, não pelo Google
- `--set-env-vars` → as variáveis de ambiente (equivalentes ao seu `.env`)

Se quiser adicionar as credenciais de WhatsApp/e-mail também, repita `--set-env-vars` pra cada uma:
```
  --set-env-vars ZAPI_INSTANCE_ID="..." ^
  --set-env-vars ZAPI_TOKEN="..." ^
  --set-env-vars ZAPI_CLIENT_TOKEN="..." ^
  --set-env-vars SMTP_USER="..." ^
  --set-env-vars SMTP_SENHA_APP="..."
```

Ao final, o comando imprime uma URL parecida com:
```
https://royal-cases-xxxxxxx-rj.a.run.app
```

Essa é a URL do seu sistema, acessível de qualquer lugar com internet.

---

## Passo 4 — Testar

1. Acesse a URL que apareceu
2. Login: `admin` / a senha que você definiu em `ROYAL_CASES_ADMIN_SENHA`
3. Confirme que consegue cadastrar produto, registrar venda, etc.

---

## Atualizando o sistema depois de mudanças

Sempre que eu (ou você) alterar o código, é só rodar o mesmo comando do
Passo 3 de novo (sem precisar repetir as variáveis de ambiente - o Cloud Run
lembra as que já foram configuradas, a menos que você use `--set-env-vars`
de novo pra mudar alguma):

```
gcloud run deploy royal-cases --source . --region southamerica-east1
```

---

## Backup

Como combinado, o backup automático em arquivo não roda mais sozinho no
Cloud Run. Acesse periodicamente (gestor logado):

```
GET https://sua-url.a.run.app/api/sistema/exportar-backup
```

Isso baixa um `.json` com produtos, clientes, vendas e taxas. Guarde esse
arquivo no Google Drive periodicamente (toda semana, por exemplo).

---

## Custos - o que fica de olho

- **Cloud Run**: gratuito até 2 milhões de requisições/mês - seu volume de
  loja fica bem abaixo disso
- **Supabase**: gratuito até 500MB de banco - deve durar anos com seu volume
- Configure um **alerta de orçamento** no Google Cloud (Billing → Budgets &
  Alerts) pra R$1 ou R$5, só pra ser avisado por e-mail se algo sair do
  esperado - não custa nada configurar e evita surpresa

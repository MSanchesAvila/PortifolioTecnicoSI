# Royal Cases — Sistema de PDV e Gestão de Estoque

Sistema completo de ponto de venda (PDV), controle de estoque, clientes e
financeiro, construído para uma loja de capas e acessórios para celular em
operação real. Rodando em produção: FastAPI + PostgreSQL (Supabase) +
Google Cloud Run.

> 🔗 [Read this in English](./README.en.md)

## Sobre este repositório

Este é o código de um sistema que uso de verdade na minha loja. Estou
publicando como estudo de caso de **como eu direciono e reviso
desenvolvimento assistido por IA em um projeto de produção real** — não
como exercício, mas como um sistema com dinheiro, estoque e dados de
cliente de verdade rodando por trás.

**Como foi construído:** o código da aplicação foi escrito com o Claude
(Anthropic) como par de desenvolvimento, numa sessão longa e iterativa.
**Minha parte** foi a especificação de cada funcionalidade a partir da
operação real da loja, revisão e teste de cada entrega, e toda a
configuração de infraestrutura e segurança em produção — IAM do Google
Cloud, ativação de Row Level Security no Postgres, decisões de
região/latência, e toda a operação de deploy e correção de incidentes em
produção (incluindo achar e reportar pelo menos 2 bugs reais que só
apareceram depois de publicado). Acho importante ser direto sobre isso: a
competência que esse projeto demonstra é a de **especificar, revisar,
testar e operar** um sistema com IA no loop — que é, cada vez mais, o
dia a dia real de quem trabalha com tecnologia.

## O que o sistema faz

- **PDV completo**: leitura de código de barras (câmera ou leitor USB),
  busca por nome, carrinho, múltiplas formas de pagamento com cálculo de
  taxa de maquininha, frete por região com valor editável, resgate de
  pontos de fidelidade, comprovante (impresso, PDF por e-mail, ou link do
  WhatsApp)
- **Estoque**: cadastro completo de produto (variação/grade, GTIN de
  fábrica, condição novo/usado/seminovo, peso e dimensões, preço
  promocional), ajuste manual de estoque com motivo obrigatório,
  geração e impressão de etiqueta com código de barras em lote (folha
  Pimaco A4251, grade calculada e configurável)
- **Clientes**: CRM leve com histórico de compras, produto favorito,
  status por recência (ativo/em risco/inativo), programa de pontos
- **Financeiro**: fechamento de caixa diário, gráfico de tendência,
  configuração de taxa de cartão por parcela, dashboard de margem e
  produtos mais lucrativos
- **Gestão de usuários**: perfis (gestor/atendente) com permissões
  granulares, recuperação de senha por e-mail, procedimento de
  recuperação de emergência documentado

## Destaques de segurança

Esta é a parte que mais me interessa mostrar. Alguns exemplos concretos
do que foi identificado e corrigido ao longo do projeto:

- **XSS armazenado**: nomes de produto/cliente eram inseridos em `innerHTML`
  sem escape em 5 arquivos JS diferentes — como o token de sessão fica no
  `localStorage`, isso permitiria roubo de sessão. Corrigido com uma
  função de escape centralizada, aplicada em todos os pontos de inserção
  de dado no DOM.
- **Prevenção de enumeração de usuário**: o endpoint de "esqueci minha
  senha" devolve a mesma resposta genérica, exista ou não o e-mail
  informado no sistema — evita que alguém descubra quais contas existem
  testando e-mails.
- **Row Level Security (Postgres/Supabase)**: identifiquei que a API
  pública automática do Supabase deixava as tabelas acessíveis via chave
  anônima, sem RLS. Ativei RLS em todas as tabelas (nega por padrão para
  a API pública, sem afetar a conexão direta do backend, que usa o
  usuário dono das tabelas).
- **Rate limiting no login**: bloqueio temporário por IP após tentativas
  repetidas de senha errada.
- **Nunca confiar no cliente pra valor financeiro**: taxa de cartão,
  frete e desconto de fidelidade são sempre buscados/calculados no
  servidor a partir de configuração própria — o request só escolhe
  *qual* opção, nunca o valor em si.
- **Sem senha padrão hardcoded**: se a variável de ambiente da senha
  inicial do administrador não for definida, o sistema gera uma senha
  aleatória forte sozinho, em vez de usar um valor fixo no código-fonte.
- **Migração de banco em produção sem downtime**: qualquer coluna nova
  adicionada ao modelo é detectada e aplicada automaticamente em bancos
  já existentes, com uma rede de segurança que detecta e corrige colunas
  esquecidas na lista manual (identifiquei esse próprio bug em produção
  e documentei a correção).
- **Bug de estoque negativo**: encontrei e corrigi um caso onde o mesmo
  produto em duas linhas separadas do carrinho conseguia vender além do
  estoque disponível — validado com teste automatizado reproduzindo o
  bug antes e depois da correção.

## Stack técnica

- **Backend**: Python, FastAPI, SQLAlchemy, Pydantic
- **Banco de dados**: PostgreSQL (Supabase) em produção, SQLite em
  desenvolvimento local
- **Frontend**: HTML/CSS/JavaScript puro (sem framework — decisão
  deliberada pra manter o sistema leve)
- **Autenticação**: JWT + bcrypt
- **Infraestrutura**: Docker, Google Cloud Run
- **Geração de arquivo**: Pillow (etiquetas com código de barras),
  ReportLab (comprovantes e etiquetas em PDF)
- **Testes**: suíte de testes automatizados (pytest + FastAPI TestClient)
  cobrindo regras de negócio financeiras, permissões, e segurança

## Rodando localmente

```bash
git clone <este-repositorio>
cd royal_cases
pip install -r requirements.txt --break-system-packages
cp .env.example .env  # preencha com seus próprios valores
uvicorn app.main:app --reload
```

Sem `DATABASE_URL` definido, o sistema usa SQLite local automaticamente —
não precisa de Postgres pra explorar o código.

## Licença

MIT — veja [LICENSE](./LICENSE).

# PRD — Sistema de Gestão de Estoque e Vendas | Royal Cases

**Versão:** 1.0 (rascunho de trabalho)
**Data:** Julho/2026
**Autor:** Matheus Sanches
**Status:** Em construção conjunta (Matheus + Claude)

---

## 1. Contexto e Objetivo

### 1.1 O negócio
Royal Cases é uma loja de capas para celular/tablet, películas, cabos, carregadores e acessórios de proteção e personalização de aparelhos. Atendimento acontece em três canais:
- Presencial (loja física)
- WhatsApp (hoje atendido por um atendente físico — a Bia, agente de IA, é um projeto à parte, ainda não ativo em produção)
- Instagram Direct e site (royalcases.com.br)

Catálogo atual inclui, entre outros: Case Aurora, Case Yasmin, Case Evo Clear, Case Bracket Premium, Case Stitch Casal, películas Hidro Gel (fosca e lisa), ventosas, cabos, Royal Box Mistério, Royal Box Gold — hoje com **200+ SKUs** ativos.

### 1.2 A dor
O controle de estoque é hoje **100% manual**, sem automação. Isso gera:
- Falta de visibilidade real da quantidade disponível por produto
- Risco de vender o mesmo item em dois canais sem perceber que zerou
- Processo lento de cadastro e conferência
- Ausência de comprovante formal para o cliente
- **Falta de controle de faturamento e lucro**: hoje não há visão consolidada de quanto entra (faturamento) nem de quanto sobra depois do custo (lucro real) por produto, período ou canal

### 1.3 Objetivo do projeto
Construir uma ferramenta interna, **gratuita, simples de operar e segura**, que resolva especificamente:
1. Cadastro de produtos
2. Controle de estoque em tempo real
3. Registro de vendas (presencial, com trilha para os demais canais no futuro)
4. Geração e leitura de código de barras
5. Cadastro de clientes (presencial e online)
6. Emissão de comprovante de compra (impresso e digital)
7. Controle de faturamento e lucro (por produto, período e, futuramente, por canal)

**Fora de escopo nesta fase (fica para fases futuras):** emissão de nota fiscal eletrônica (NFC-e/SAT), integração automática com a Bia (WhatsApp) e com o site, múltiplas lojas/pontos de venda.

---

## 2. Personas

| Persona | Papel | Necessidade principal |
|---|---|---|
| Matheus | Dono / gestor | Visibilidade de estoque, controle geral, relatórios simples |
| Atendente de caixa | Operador do PDV | Fechar venda rápido, ler código de barras, emitir comprovante sem fricção |
| Cliente | Comprador presencial ou online | Ser cadastrado rapidamente, receber comprovante (impresso ou digital) |

---

## 3. Fluxos de Uso

### 3.1 Cadastro de produto novo
1. Atendente/gestor insere: nome, categoria, **preço de custo**, preço de venda, quantidade inicial, fornecedor (opcional)
2. Sistema gera automaticamente um código de barras (Code128 ou EAN) único
3. Sistema disponibiliza a etiqueta para impressão
4. Sistema calcula automaticamente a margem de lucro do produto (preço de venda − preço de custo)

### 3.5 Consulta de faturamento e lucro
1. Gestor acessa painel com faturamento total (soma das vendas) e lucro real (faturamento − custo dos produtos vendidos) em um período (dia, semana, mês)
2. Gestor pode filtrar por produto ou categoria pra ver quais itens dão mais margem
3. Sistema destaca produtos com margem baixa ou negativa (alerta de precificação)

### 3.2 Venda presencial
1. Atendente escaneia o código de barras do produto (leitor USB ou câmera do celular)
2. Sistema identifica o produto e mostra preço/estoque disponível
3. Repete para múltiplos itens (carrinho)
4. Atendente identifica o cliente (busca por CPF/telefone ou cadastra novo na hora)
5. Sistema calcula total, confirma pagamento (dinheiro/cartão/pix — só registro, sem integração de pagamento nesta fase)
6. Sistema baixa o estoque automaticamente
7. Sistema imprime comprovante na impressora térmica (via python-escpos) e/ou envia por WhatsApp/e-mail

### 3.3 Cadastro de cliente
1. Presencial: atendente cadastra nome, telefone, e-mail (opcional), CPF (opcional) no momento da venda
2. Online (fase futura): dados capturados quando a Bia ou o site fecham um pedido

### 3.4 Consulta e ajuste de estoque
1. Gestor acessa painel simples com lista de produtos, quantidade atual, alertas de estoque baixo
2. Gestor pode fazer ajuste manual (perda, devolução, contagem física)

---

## 4. Requisitos Funcionais

| ID | Requisito |
|---|---|
| RF01 | Cadastrar produto com nome, categoria, preço de custo, preço de venda, quantidade, fornecedor |
| RF02 | Gerar código de barras único por produto (Code128/EAN) |
| RF03 | Imprimir etiqueta com código de barras |
| RF04 | Ler código de barras via leitor USB e via câmera do celular (navegador) |
| RF05 | Registrar venda com um ou mais produtos (carrinho) |
| RF06 | Baixar estoque automaticamente a cada venda confirmada |
| RF07 | Cadastrar cliente (nome, telefone, e-mail, CPF opcional) |
| RF08 | Vincular venda a um cliente cadastrado |
| RF09 | Emitir comprovante de compra impresso (impressora térmica) |
| RF10 | Enviar comprovante digital (PDF) por WhatsApp ou e-mail |
| RF11 | Painel de consulta de estoque com alerta de estoque baixo |
| RF12 | Ajuste manual de estoque (perda, devolução, contagem) |
| RF13 | Histórico de vendas por produto, por período, por cliente |
| RF14 | Calcular e exibir margem de lucro por produto (preço de venda − preço de custo) |
| RF15 | Painel de faturamento e lucro consolidado por período (dia, semana, mês) |
| RF16 | Alertar produtos com margem de lucro baixa ou negativa |

## 5. Requisitos Não-Funcionais

| ID | Requisito |
|---|---|
| RNF01 | Sistema deve rodar 100% com ferramentas gratuitas |
| RNF02 | Banco de dados local (SQLite), acessível apenas pela rede interna da loja — sem exposição à internet |
| RNF03 | Backup automático diário do banco para nuvem (Google Drive) |
| RNF04 | Acesso ao sistema protegido por usuário e senha individual |
| RNF05 | Dados de clientes tratados conforme princípios da LGPD: coleta mínima necessária, finalidade clara, sem compartilhamento com terceiros |
| RNF06 | Nenhum dado de cartão de crédito é armazenado no sistema |
| RNF07 | Interface utilizável por qualquer navegador (PC e celular) na rede local |
| RNF08 | Arquitetura preparada para migração futura de SQLite → PostgreSQL em nuvem sem reescrita do sistema |
| RNF09 | Controle de acesso por perfil: preço de custo, margem e painel de faturamento/lucro visíveis apenas ao perfil "gestor"; atendente de caixa vê só o necessário para operar a venda |

---

## 6. Arquitetura Técnica

| Camada | Escolha | Justificativa |
|---|---|---|
| Banco de dados | SQLite (arquivo local) | Gratuito, sem servidor externo, suficiente para 200+ SKUs e 2-3 usuários simultâneos via API |
| Backend | Python + FastAPI | Leve, rápido de construir, fácil de aprender junto |
| Frontend | HTML + Jinja2 (renderizado pelo próprio Python) + JavaScript puro + CSS | Evita complexidade de frameworks (React/Vue) desnecessária para o escopo |
| Leitura de código de barras | Leitor USB (emula teclado) + biblioteca JS de leitura via câmera (navegador) | Sem necessidade de app nativo |
| Geração de código de barras | Biblioteca Python (ex: `python-barcode`) | Gratuita, gera Code128/EAN |
| Impressão de comprovante | `python-escpos` → impressora térmica USB | Impressão automática no fechamento da venda, formatação nativa para bobina |
| Envio digital de comprovante | Geração de PDF (`reportlab` ou similar) + envio via Z-API (WhatsApp, já integrado ao ecossistema) ou SMTP (e-mail) | Reaproveita infraestrutura já existente |
| Hospedagem | Computador da própria loja (rede local, IP fixo) | Sem custo de servidor, sem exposição externa |
| Segurança | Rede fechada (sem porta aberta à internet), autenticação por usuário, backup automático, práticas de minimização de dado (LGPD) | Nível de segurança adequado ao porte do projeto, sem overhead de firewall dedicado |

**Diagrama lógico simplificado:**

```
[Leitor USB / Câmera celular]
            │
            ▼
[Navegador (PC caixa / celular)] ──HTTP local──> [FastAPI + SQLite no PC da loja]
                                                        │
                                                        ├──> Impressora térmica (USB)
                                                        └──> WhatsApp/E-mail (comprovante digital)
```

---

## 7. Roadmap em Fases

### Fase 1 — MVP (foco atual)
- Cadastro de produtos (com preço de custo e venda) e clientes
- Geração e leitura de código de barras
- Registro de venda com baixa automática de estoque
- Comprovante impresso (térmica) e digital (WhatsApp/e-mail)
- Painel simples de consulta de estoque
- Painel de faturamento e lucro (por produto e por período)
- Controle de acesso por perfil (gestor vs. atendente)

### Fase 2 — Integração de canais
- Migração de SQLite → PostgreSQL em nuvem
- Integração com a Bia (WhatsApp): consulta de estoque em tempo real antes de fechar pedido
- Integração com o site: estoque como fonte única de verdade

### Fase 3 — Formalização fiscal (opcional, se necessário)
- Avaliação de emissão de NFC-e/SAT
- Certificado digital e homologação SEFAZ

### Fase 4 — Segurança avançada (se o volume/risco justificar)
- Políticas formais alinhadas a NIST
- Auditoria de acesso, logs estruturados, testes de penetração básicos

---

---

## 9. Topologia de Dispositivos e Migração

| Dispositivo | Papel | Instalação necessária |
|---|---|---|
| Notebook (fase de desenvolvimento) | Roda o sistema completo (FastAPI + SQLite) durante a construção | Sim — ambiente de desenvolvimento |
| Computador da loja (produção) | Roda o sistema completo definitivamente | Sim — cópia do projeto + instalação única das dependências |
| Celular(es) | Cliente para leitura de código de barras via câmera (navegador) | Não — apenas acessa o endereço local do servidor pela rede Wi-Fi. Pode ser configurado como PWA (ícone na tela inicial, aparência de app) sem custo adicional |

**Requisito de rede confirmado:** loja possui Wi-Fi estável com sinal forte em toda a área de uso — condição necessária para que os celulares consigam registrar leitura de código de barras em tempo real com o servidor.

**Migração notebook → computador da loja:** ao final do desenvolvimento, o projeto (código + banco de dados) é copiado do notebook para o computador da loja, onde as dependências são instaladas uma única vez e o servidor passa a rodar permanentemente ali.

---

## 10. Armazenamento

- Sistema completo (código + dependências): ~300-500 MB
- Banco de dados (SQLite) com 200+ produtos, clientes e histórico de vendas: dezenas de MB, mesmo após anos de uso
- Comprovantes em PDF (se arquivados permanentemente): pode chegar a poucos GB ao longo de vários anos
- **Recomendação:** sistema roda a partir do HD/SSD interno do computador da loja (não de pendrive, por risco de desgaste e corrupção de dados em escrita constante). Pendrive de 8GB reservado como camada extra de backup físico, complementar ao backup automático em nuvem

---

## 11. Próximos Passos

1. Validar este PRD linha por linha com Matheus
2. Definir estrutura de tabelas do banco (produtos, clientes, vendas, itens_venda)
3. Montar o esqueleto do projeto FastAPI
4. Construir tela de cadastro de produto + geração de código de barras (primeiro módulo)
5. Construir fluxo de venda (segundo módulo)
6. Testar leitura de código de barras (USB e câmera)
7. Integrar impressão térmica
8. Testar em ambiente real da loja

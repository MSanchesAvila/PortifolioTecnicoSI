"""
Router de operações de sistema (backup manual).
"""
import json
import io
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.dependencies import exigir_gestor
from app.backup_utils import fazer_backup, exportar_dados_json
from app.models import Produto, Cliente, ConfiguracaoTaxa, FormaPagamento

router = APIRouter(prefix="/api/sistema", tags=["Sistema"])


@router.post("/backup-agora")
def backup_manual(_gestor=Depends(exigir_gestor)):
    """
    Backup em arquivo local (copia o .db) - só funciona quando o sistema
    roda com disco persistente (ex: seu notebook/PC da loja). No Cloud Run
    isso não tem efeito útil (não há disco persistente) - use o endpoint
    /exportar-backup nesse caso.
    """
    caminho = fazer_backup()
    if not caminho:
        raise HTTPException(status_code=500, detail="Não foi possível criar o backup - veja os logs do servidor")
    return {"status": "backup criado", "arquivo": caminho}


@router.get("/exportar-backup")
def exportar_backup(db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """
    Baixa um arquivo JSON com produtos, clientes, vendas e configuração de
    taxas - funciona independente de onde o sistema está rodando (local ou
    Cloud Run + Supabase). Recomendado baixar periodicamente e guardar num
    Google Drive, já que o Supabase gratuito não inclui backup automático.
    """
    dados = exportar_dados_json(db)
    conteudo = json.dumps(dados, ensure_ascii=False, indent=2).encode("utf-8")
    nome_arquivo = f"royal_cases_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

    return StreamingResponse(
        io.BytesIO(conteudo),
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename={nome_arquivo}"},
    )


@router.post("/importar-backup")
async def importar_backup(arquivo: UploadFile = File(...), db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """
    Restaura produtos, clientes e configuração de taxas a partir de um
    arquivo exportado por /exportar-backup.

    IMPORTANTE - o que NÃO é restaurado: vendas e itens de venda. Isso é
    proposital - o histórico financeiro fica por conta da própria
    resiliência do Supabase; restaurar vendas de um arquivo exigiria
    "remapear" IDs de produto/cliente que podem não bater mais depois de um
    desastre, o que é arriscado de fazer automaticamente. Esse endpoint é
    pensado pra reconstruir rápido o CATÁLOGO (produto/cliente/taxa) - a
    parte mais dolorosa de perder e recadastrar na mão.

    É seguro rodar mais de uma vez: usa "upsert" (atualiza se já existir,
    cria se não existir) baseado em código de barras / CPF / forma de
    pagamento - não duplica.
    """
    try:
        conteudo = json.loads(await arquivo.read())
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Arquivo não é um JSON válido")

    resultado = {"produtos_criados": 0, "produtos_atualizados": 0, "clientes_criados": 0, "clientes_atualizados": 0, "taxas_atualizadas": 0}

    for item in conteudo.get("produtos", []):
        existente = db.scalar(select(Produto).where(Produto.codigo_barras == item["codigo_barras"]))
        campos = {k: v for k, v in item.items() if k not in ("id", "criado_em")}

        # O backup exporta o VÍNCULO com o fornecedor, mas não os fornecedores em si -
        # se esse fornecedor não existir nesse banco, zera o vínculo em vez de quebrar
        # a restauração inteira por causa de uma referência que não existe mais.
        from app.models import Fornecedor
        if campos.get("fornecedor_id") and not db.get(Fornecedor, campos["fornecedor_id"]):
            campos["fornecedor_id"] = None

        if existente:
            for campo, valor in campos.items():
                setattr(existente, campo, valor)
            resultado["produtos_atualizados"] += 1
        else:
            db.add(Produto(**campos))
            resultado["produtos_criados"] += 1

    for item in conteudo.get("clientes", []):
        existente = None
        if item.get("cpf"):
            existente = db.scalar(select(Cliente).where(Cliente.cpf == item["cpf"]))
        campos = {k: v for k, v in item.items() if k not in ("id", "criado_em")}
        if existente:
            for campo, valor in campos.items():
                setattr(existente, campo, valor)
            resultado["clientes_atualizados"] += 1
        else:
            db.add(Cliente(**campos))
            resultado["clientes_criados"] += 1

    for item in conteudo.get("configuracoes_taxa", []):
        forma = FormaPagamento(item["forma_pagamento"])
        existente = db.scalar(
            select(ConfiguracaoTaxa).where(
                ConfiguracaoTaxa.forma_pagamento == forma,
                ConfiguracaoTaxa.numero_parcelas == item["numero_parcelas"],
            )
        )
        if existente:
            existente.taxa_percentual = item["taxa_percentual"]
        else:
            db.add(ConfiguracaoTaxa(forma_pagamento=forma, numero_parcelas=item["numero_parcelas"], taxa_percentual=item["taxa_percentual"]))
        resultado["taxas_atualizadas"] += 1

    db.commit()
    return {"status": "backup restaurado", **resultado}

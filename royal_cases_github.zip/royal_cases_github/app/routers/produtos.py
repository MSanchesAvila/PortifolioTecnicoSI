"""
Router de Produtos.
Cadastro exige a permissao "produtos.cadastrar" (gestor sempre tem).
Ver custo/margem exige "produtos.ver_custo" (gestor sempre tem).
"""
import logging
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import Produto, Usuario, CondicaoProduto
from app.schemas import ProdutoCriar, ProdutoRespostaGestor, ProdutoRespostaAtendente, ProdutoEditar, AjusteEstoque
from app.barcode_utils import gerar_codigo_unico, gerar_imagem_codigo_barras
from app.dependencies import usuario_logado, exigir_permissao

logger = logging.getLogger("royal_cases.produtos")
router = APIRouter(prefix="/api/produtos", tags=["Produtos"])


def _buscar_usuario_db(usuario: dict, db: Session, cache: dict) -> Usuario | None:
    """
    Busca o usuário no banco só UMA VEZ por requisição. Prioriza o objeto
    que o próprio usuario_logado já buscou (anexado em "_usuario_db") -
    só cai pra consulta nova se por algum motivo não estiver lá.
    """
    if "usuario_db" not in cache:
        cache["usuario_db"] = usuario.get("_usuario_db") or db.get(Usuario, int(usuario["sub"]))
    return cache["usuario_db"]


def _pode_ver_custo(usuario: dict, db: Session, cache: dict = None) -> bool:
    """Gestor sempre ve; atendente so se tiver a permissao especifica."""
    if usuario["perfil"] == "gestor":
        return True
    usuario_db = _buscar_usuario_db(usuario, db, cache if cache is not None else {})
    return bool(usuario_db and usuario_db.tem_permissao("produtos.ver_custo"))


def _tem_permissao_cadastro(usuario: dict, db: Session, cache: dict = None) -> bool:
    """Gestor sempre tem; atendente so se tiver a permissao especifica."""
    if usuario["perfil"] == "gestor":
        return True
    usuario_db = _buscar_usuario_db(usuario, db, cache if cache is not None else {})
    return bool(usuario_db and usuario_db.tem_permissao("produtos.cadastrar"))


@router.post("", response_model=ProdutoRespostaGestor, dependencies=[Depends(exigir_permissao("produtos.cadastrar"))])
def criar_produto(dados: ProdutoCriar, db: Session = Depends(get_db)):
    """Cadastra um produto novo e gera o codigo de barras automaticamente (RF01 + RF02)."""
    codigo = gerar_codigo_unico()
    while db.scalar(select(Produto).where(Produto.codigo_barras == codigo)):
        codigo = gerar_codigo_unico()

    try:
        condicao = CondicaoProduto(dados.condicao)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Condição inválida: {dados.condicao} (use 'novo', 'usado' ou 'seminovo')")

    produto = Produto(
        nome=dados.nome,
        categoria=dados.categoria,
        subcategoria=dados.subcategoria,
        codigo_barras=codigo,
        gtin_ean=dados.gtin_ean,
        condicao=condicao,
        preco_custo=dados.preco_custo,
        preco_venda=dados.preco_venda,
        preco_promocional=dados.preco_promocional,
        quantidade_estoque=dados.quantidade_estoque,
        estoque_minimo=dados.estoque_minimo,
        peso_gramas=dados.peso_gramas,
        altura_cm=dados.altura_cm,
        largura_cm=dados.largura_cm,
        comprimento_cm=dados.comprimento_cm,
        fornecedor=dados.fornecedor,
        fornecedor_id=dados.fornecedor_id,
        grupo_variacao=dados.grupo_variacao,
        variacao=dados.variacao,
    )
    db.add(produto)
    db.commit()
    db.refresh(produto)
    return produto


@router.get("")
def listar_produtos(
    incluir_inativos: bool = False,
    db: Session = Depends(get_db),
    usuario: dict = Depends(usuario_logado),
):
    """
    Lista produtos. Por padrão só ativos; com incluir_inativos=true também
    traz os desativados - mas só pra quem tem permissão de cadastrar
    (atendente sem essa permissão não vê produto descontinuado, mesmo
    chamando a API direto, não só pela tela).
    """
    cache_usuario = {}
    pode_ver_inativos = incluir_inativos and (
        usuario["perfil"] == "gestor" or _pode_ver_custo(usuario, db, cache_usuario) or _tem_permissao_cadastro(usuario, db, cache_usuario)
    )
    query = select(Produto)
    if not pode_ver_inativos:
        query = query.where(Produto.ativo == True)
    produtos = db.scalars(query).all()
    if _pode_ver_custo(usuario, db, cache_usuario):
        return [ProdutoRespostaGestor.model_validate(p) for p in produtos]
    return [ProdutoRespostaAtendente.model_validate(p) for p in produtos]


@router.get("/codigo/{codigo_barras}")
def buscar_por_codigo_barras(
    codigo_barras: str, db: Session = Depends(get_db), usuario: dict = Depends(usuario_logado)
):
    """Busca produto pelo codigo de barras (usado pelo leitor USB/camera na venda)."""
    produto = db.scalar(select(Produto).where(Produto.codigo_barras == codigo_barras))
    if not produto:
        raise HTTPException(status_code=404, detail="Produto nao encontrado para este codigo de barras")
    if _pode_ver_custo(usuario, db):
        return ProdutoRespostaGestor.model_validate(produto)
    return ProdutoRespostaAtendente.model_validate(produto)


@router.get("/{produto_id}/etiqueta")
def baixar_etiqueta(produto_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Gera e retorna a imagem da etiqueta (codigo de barras) pra impressao."""
    produto = db.get(Produto, produto_id)
    if not produto:
        raise HTTPException(status_code=404, detail="Produto nao encontrado")

    buffer = gerar_imagem_codigo_barras(produto.codigo_barras, nome=produto.nome, preco_venda=produto.preco_venda)
    return StreamingResponse(
        buffer,
        media_type="image/png",
        headers={"Content-Disposition": f"inline; filename=etiqueta_{produto.codigo_barras}.png"},
    )


@router.put("/{produto_id}", response_model=ProdutoRespostaGestor, dependencies=[Depends(exigir_permissao("produtos.cadastrar"))])
def editar_produto(produto_id: int, dados: ProdutoEditar, db: Session = Depends(get_db)):
    """
    Edita dados de um produto já cadastrado (corrigir nome, preço, etc).
    NÃO edita estoque diretamente - isso passa pelo endpoint de ajuste,
    que exige um motivo e mantém rastreável o porquê da mudança.
    """
    produto = db.get(Produto, produto_id)
    if not produto:
        raise HTTPException(status_code=404, detail="Produto não encontrado")

    dados_informados = dados.model_dump(exclude_unset=True)

    if "condicao" in dados_informados:
        try:
            dados_informados["condicao"] = CondicaoProduto(dados_informados["condicao"])
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Condição inválida: {dados_informados['condicao']}")

    for campo, valor in dados_informados.items():
        setattr(produto, campo, valor)

    db.commit()
    db.refresh(produto)
    return produto


@router.post("/{produto_id}/ajustar-estoque", response_model=ProdutoRespostaGestor, dependencies=[Depends(exigir_permissao("produtos.cadastrar"))])
def ajustar_estoque(produto_id: int, dados: AjusteEstoque, db: Session = Depends(get_db)):
    """
    Ajusta o estoque manualmente (reposição do fornecedor, perda, contagem
    física divergente, etc) - sempre pedindo o motivo, pra manter rastreável
    por que o número mudou fora do fluxo normal de venda.
    """
    produto = db.get(Produto, produto_id)
    if not produto:
        raise HTTPException(status_code=404, detail="Produto não encontrado")

    novo_estoque = produto.quantidade_estoque + dados.quantidade_delta
    if novo_estoque < 0:
        raise HTTPException(
            status_code=400,
            detail=f"Ajuste deixaria o estoque negativo (atual: {produto.quantidade_estoque}, ajuste: {dados.quantidade_delta})"
        )

    produto.quantidade_estoque = novo_estoque
    db.commit()
    db.refresh(produto)
    logger.info(
        f"Ajuste de estoque: produto_id={produto_id} delta={dados.quantidade_delta} "
        f"motivo='{dados.motivo}' novo_estoque={novo_estoque}"
    )
    return produto

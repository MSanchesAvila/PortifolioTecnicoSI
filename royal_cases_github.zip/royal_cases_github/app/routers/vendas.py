"""
Router de Vendas - o nucleo do sistema.
Junta produto + cliente + baixa de estoque + calculo de lucro numa
unica operacao atomica: ou tudo e salvo, ou nada e salvo.

Todas as rotas exigem login. O usuario que registra a venda vem
SEMPRE do token (nunca de um campo enviado no corpo da requisicao).
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse, PlainTextResponse, HTMLResponse
from sqlalchemy.orm import Session
from sqlalchemy import select
from pydantic import BaseModel
from datetime import datetime

from app.database import get_db
from app.models import Venda, ItemVenda, Produto, Cliente, CanalVenda, FormaPagamento, ConfiguracaoTaxa, TaxaAssumidaPor, RegiaoEntrega
from app.schemas import VendaCriar, VendaRespostaGestor, VendaRespostaAtendente
from app.comprovante_utils import gerar_bytes_termica, gerar_pdf_comprovante, gerar_html_comprovante
from app.envio_utils import enviar_comprovante_whatsapp, enviar_comprovante_email
from app.dependencies import usuario_logado, exigir_gestor

router = APIRouter(prefix="/api/vendas", tags=["Vendas"])


class EnvioComprovanteRequest(BaseModel):
    canal: str  # "whatsapp" ou "email"
    destino: str  # telefone (whatsapp) ou endereco de e-mail


def _resposta_por_perfil(venda: Venda, perfil: str, alertas: list[str] = None):
    if perfil == "gestor":
        resp = VendaRespostaGestor.model_validate(venda)
    else:
        resp = VendaRespostaAtendente.model_validate(venda)
    if alertas is not None:
        resp.alertas_estoque_baixo = alertas
    return resp


@router.post("")
def registrar_venda(dados: VendaCriar, db: Session = Depends(get_db), usuario: dict = Depends(usuario_logado)):
    """
    Registra uma venda completa (RF05, RF06, RF14).

    Passo a passo:
    1. Valida que TODOS os produtos existem e tem estoque suficiente
       (antes de gravar qualquer coisa - e aqui que a "atomicidade" acontece)
    2. Cria a venda e os itens, com precos CONGELADOS no momento da venda
    3. Baixa o estoque de cada produto
    4. Calcula os totais (valor, custo, lucro)
    5. Verifica se algum produto ficou abaixo do estoque minimo (RF16)
    """
    if not dados.itens:
        raise HTTPException(status_code=400, detail="A venda precisa ter pelo menos um item")

    try:
        canal = CanalVenda(dados.canal)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Canal invalido: {dados.canal}")
    try:
        forma_pagamento = FormaPagamento(dados.forma_pagamento)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Forma de pagamento invalida: {dados.forma_pagamento}")

    cliente_obj = None
    if dados.cliente_id:
        cliente_obj = db.get(Cliente, dados.cliente_id)
        if not cliente_obj:
            raise HTTPException(status_code=404, detail="Cliente informado nao existe")

    # ---- Fidelidade: só dá pra resgatar pontos se tiver cliente selecionado e saldo suficiente ----
    if dados.pontos_utilizados > 0:
        if not cliente_obj:
            raise HTTPException(status_code=400, detail="Selecione um cliente pra resgatar pontos de fidelidade")
        if dados.pontos_utilizados > cliente_obj.pontos_fidelidade:
            raise HTTPException(
                status_code=400,
                detail=f"Cliente só tem {cliente_obj.pontos_fidelidade} pontos, não pode resgatar {dados.pontos_utilizados}"
            )

    try:
        taxa_assumida_por = TaxaAssumidaPor(dados.taxa_assumida_por)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Valor invalido para taxa_assumida_por: {dados.taxa_assumida_por}")

    if forma_pagamento != FormaPagamento.CARTAO_CREDITO and dados.numero_parcelas != 1:
        raise HTTPException(status_code=400, detail="Parcelamento só se aplica a cartão de crédito")

    # ---- Frete: busca a REGIÃO configurada pelo gestor - nunca confia num valor vindo do cliente ----
    # EXCEÇÃO proposital: o atendente PODE digitar um valor de frete diferente
    # do padrão da região (ex: motoboy cobrou um valor diferente hoje) - isso
    # é permitido porque frete é uma estimativa humana, não uma regra fixa
    # como a taxa da maquininha. O teto de R$100 (validado no schema) existe
    # só pra pegar erro de digitação, não pra travar um valor real.
    regiao_entrega = None
    frete_assumido_por = None
    valor_frete_final = 0.0
    if dados.regiao_entrega_id:
        regiao_entrega = db.get(RegiaoEntrega, dados.regiao_entrega_id)
        if not regiao_entrega or not regiao_entrega.ativo:
            raise HTTPException(status_code=404, detail="Região de entrega não encontrada ou desativada")
        if not dados.frete_assumido_por:
            raise HTTPException(status_code=400, detail="Informe quem assume o frete (cliente ou loja)")
        try:
            frete_assumido_por = TaxaAssumidaPor(dados.frete_assumido_por)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Valor inválido para frete_assumido_por: {dados.frete_assumido_por}")
        valor_frete_final = dados.valor_frete_manual if dados.valor_frete_manual is not None else regiao_entrega.valor_frete

    # ---- Busca a TAXA configurada pelo gestor - nunca confia num valor vindo do cliente da requisição ----
    config_taxa = db.scalar(
        select(ConfiguracaoTaxa).where(
            ConfiguracaoTaxa.forma_pagamento == forma_pagamento,
            ConfiguracaoTaxa.numero_parcelas == dados.numero_parcelas,
        )
    )
    taxa_percentual = config_taxa.taxa_percentual if config_taxa else 0.0

    # ---- PASSO 1: validar tudo ANTES de gravar qualquer coisa ----
    # IMPORTANTE: se o mesmo produto aparecer em mais de uma linha (ex: dois
    # itens separados com produto_id igual), a validação precisa somar as
    # quantidades ANTES de comparar com o estoque - senão cada linha passa
    # na checagem individualmente e o estoque final pode ficar negativo.
    quantidade_total_por_produto = {}
    for item in dados.itens:
        quantidade_total_por_produto[item.produto_id] = (
            quantidade_total_por_produto.get(item.produto_id, 0) + item.quantidade
        )

    produtos_carregados = {}
    for produto_id, quantidade_total in quantidade_total_por_produto.items():
        produto = db.get(Produto, produto_id)
        if not produto or not produto.ativo:
            raise HTTPException(status_code=404, detail=f"Produto id={produto_id} nao encontrado")
        if produto.quantidade_estoque < quantidade_total:
            raise HTTPException(
                status_code=400,
                detail=f"Estoque insuficiente para '{produto.nome}': "
                       f"disponivel {produto.quantidade_estoque}, pedido {quantidade_total}"
            )
        produtos_carregados[produto_id] = produto

    # ---- PASSO 2: gravacao - usuario_id vem do TOKEN, nunca do corpo da requisicao ----
    venda = Venda(
        cliente_id=dados.cliente_id,
        usuario_id=int(usuario["sub"]),
        canal=canal,
        forma_pagamento=forma_pagamento,
        numero_parcelas=dados.numero_parcelas,
        taxa_assumida_por=taxa_assumida_por,
        taxa_percentual_aplicada=taxa_percentual,
        regiao_entrega_id=regiao_entrega.id if regiao_entrega else None,
        frete_assumido_por=frete_assumido_por,
        valor_frete_aplicado=valor_frete_final,
        valor_total=0,
        custo_total=0,
    )
    db.add(venda)
    db.flush()

    alertas_estoque_baixo = []
    valor_total = 0.0
    custo_total = 0.0

    for item in dados.itens:
        produto = produtos_carregados[item.produto_id]

        item_venda = ItemVenda(
            venda_id=venda.id,
            produto_id=produto.id,
            quantidade=item.quantidade,
            preco_unitario_venda=produto.preco_venda,
            preco_unitario_custo=produto.preco_custo,
        )
        db.add(item_venda)

        valor_total += produto.preco_venda * item.quantidade
        custo_total += produto.preco_custo * item.quantidade
        produto.quantidade_estoque -= item.quantidade

        if produto.quantidade_estoque <= produto.estoque_minimo:
            alertas_estoque_baixo.append(
                f"{produto.nome} (restam {produto.quantidade_estoque}, minimo {produto.estoque_minimo})"
            )

    venda.valor_total = round(valor_total, 2)
    venda.custo_total = round(custo_total, 2)

    # ---- Cálculo da taxa: sempre em cima do valor_total, congelado neste momento ----
    taxa_valor = round(venda.valor_total * (taxa_percentual / 100), 2)
    venda.taxa_valor = taxa_valor

    if taxa_assumida_por == TaxaAssumidaPor.CLIENTE:
        # Cliente paga a mais pra cobrir a taxa; a loja recebe o valor cheio dos produtos
        venda.valor_cobrado_cliente = round(venda.valor_total + taxa_valor, 2)
        venda.valor_recebido_loja = venda.valor_total
    else:
        # Loja absorve a taxa; cliente paga só o valor dos produtos, mas a loja recebe menos
        venda.valor_cobrado_cliente = venda.valor_total
        venda.valor_recebido_loja = round(venda.valor_total - taxa_valor, 2)

    # ---- Frete: soma/desconta DEPOIS da taxa, sobre cima do que já foi calculado ----
    if regiao_entrega:
        if frete_assumido_por == TaxaAssumidaPor.CLIENTE:
            # Cliente paga o frete a mais; não afeta o que a loja recebe pelos produtos
            venda.valor_cobrado_cliente = round(venda.valor_cobrado_cliente + venda.valor_frete_aplicado, 2)
        else:
            # Frete grátis pro cliente; a loja absorve esse custo (reduz o quanto ela recebe de verdade)
            venda.valor_recebido_loja = round(venda.valor_recebido_loja - venda.valor_frete_aplicado, 2)

    # ---- Fidelidade: resgate de pontos (desconto) e ganho de pontos novos ----
    # Busca a config direto (sem passar por outro import circular) - mesmo
    # principio de nunca confiar em valor vindo da tela, só na escolha da
    # QUANTIDADE de pontos a resgatar.
    from app.models import ConfiguracaoFidelidade
    config_fidelidade = db.query(ConfiguracaoFidelidade).first()

    if dados.pontos_utilizados > 0 and config_fidelidade and config_fidelidade.ativo:
        desconto = round(dados.pontos_utilizados * config_fidelidade.valor_resgate_por_ponto, 2)
        # Nunca deixa o desconto passar do valor total (não faz sentido "pagar" negativo)
        desconto = min(desconto, venda.valor_cobrado_cliente)
        venda.pontos_utilizados = dados.pontos_utilizados
        venda.desconto_pontos = desconto
        venda.valor_cobrado_cliente = round(venda.valor_cobrado_cliente - desconto, 2)
        venda.valor_recebido_loja = round(venda.valor_recebido_loja - desconto, 2)
        cliente_obj.pontos_fidelidade -= dados.pontos_utilizados

    # Pontos ganhos nessa compra (sobre o valor JÁ com desconto de pontos aplicado,
    # pra não "girar" pontos infinitamente resgatando e reganhando na mesma venda)
    if cliente_obj and config_fidelidade and config_fidelidade.ativo:
        pontos_ganhos = int(venda.valor_cobrado_cliente * config_fidelidade.pontos_por_real)
        venda.pontos_ganhos = pontos_ganhos
        cliente_obj.pontos_fidelidade += pontos_ganhos

    db.commit()
    db.refresh(venda)

    return _resposta_por_perfil(venda, usuario["perfil"], alertas_estoque_baixo)


@router.delete("/{venda_id}")
def excluir_venda(venda_id: int, db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """
    Exclui uma venda do sistema e DEVOLVE o estoque dos produtos envolvidos -
    senão o estoque ficaria "faltando" pra sempre. Restrito ao gestor, já que
    é uma ação que mexe em histórico financeiro e de estoque.
    """
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda não encontrada")

    for item in venda.itens:
        produto = db.get(Produto, item.produto_id)
        if produto:
            produto.quantidade_estoque += item.quantidade

    db.delete(venda)  # cascade já remove os itens_venda associados
    db.commit()
    return {"status": "venda excluída", "estoque_devolvido": True}


@router.get("")
def listar_vendas(
    data_inicio: datetime | None = None,
    data_fim: datetime | None = None,
    forma_pagamento: str | None = None,
    db: Session = Depends(get_db),
    usuario: dict = Depends(usuario_logado),
):
    """Lista vendas (RF13), com filtro opcional por período e forma de pagamento."""
    query = select(Venda).order_by(Venda.data_hora.desc())
    if data_inicio:
        query = query.where(Venda.data_hora >= data_inicio)
    if data_fim:
        query = query.where(Venda.data_hora <= data_fim)
    if forma_pagamento:
        query = query.where(Venda.forma_pagamento == FormaPagamento(forma_pagamento))
    vendas = db.scalars(query).all()
    return [_resposta_por_perfil(v, usuario["perfil"]) for v in vendas]


@router.get("/{venda_id}")
def detalhar_venda(venda_id: int, db: Session = Depends(get_db), usuario: dict = Depends(usuario_logado)):
    """Detalha uma venda especifica (usado, por exemplo, pra reimprimir comprovante)."""
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda nao encontrada")
    return _resposta_por_perfil(venda, usuario["perfil"])


def _montar_itens_detalhados(venda: Venda) -> list[dict]:
    """Monta a lista de itens com o nome do produto, pronta pro comprovante."""
    return [
        {"nome": item.produto.nome, "quantidade": item.quantidade, "preco_unitario_venda": item.preco_unitario_venda}
        for item in venda.itens
    ]


@router.get("/{venda_id}/comprovante/pdf")
def comprovante_pdf(venda_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Gera o comprovante em PDF, pronto pra enviar por WhatsApp/e-mail (RF10)."""
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda nao encontrada")

    cliente_nome = venda.cliente.nome if venda.cliente else None
    itens = _montar_itens_detalhados(venda)
    buffer = gerar_pdf_comprovante(venda, cliente_nome, itens)

    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"inline; filename=comprovante_venda_{venda.id}.pdf"},
    )


@router.get("/{venda_id}/comprovante/html", response_class=HTMLResponse)
def comprovante_html(venda_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """
    Comprovante em HTML, pronto pra abrir numa aba e imprimir com o driver
    da impressora do Windows (window.print()). É o caminho usado quando o
    sistema roda na nuvem, sem acesso direto à porta USB da impressora.
    """
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda nao encontrada")

    cliente_nome = venda.cliente.nome if venda.cliente else None
    itens = _montar_itens_detalhados(venda)
    return gerar_html_comprovante(venda, cliente_nome, itens)


@router.get("/{venda_id}/comprovante/termica/preview", response_class=PlainTextResponse)
def comprovante_termica_preview(venda_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Mostra em texto simples como o comprovante vai sair na impressora termica."""
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda nao encontrada")

    cliente_nome = venda.cliente.nome if venda.cliente else None
    itens = _montar_itens_detalhados(venda)
    dados_brutos = gerar_bytes_termica(venda, cliente_nome, itens)
    return dados_brutos.decode("cp437", errors="ignore")


@router.post("/{venda_id}/comprovante/enviar")
def enviar_comprovante(
    venda_id: int,
    dados: EnvioComprovanteRequest,
    db: Session = Depends(get_db),
    _usuario: dict = Depends(usuario_logado),
):
    """Envia o comprovante digital pro cliente (RF10). Requer credenciais configuradas (ver app/config.py)."""
    venda = db.get(Venda, venda_id)
    if not venda:
        raise HTTPException(status_code=404, detail="Venda nao encontrada")

    cliente_nome = venda.cliente.nome if venda.cliente else None
    itens = _montar_itens_detalhados(venda)
    pdf_buffer = gerar_pdf_comprovante(venda, cliente_nome, itens)
    nome_arquivo = f"comprovante_venda_{venda.id}.pdf"

    try:
        if dados.canal == "whatsapp":
            enviar_comprovante_whatsapp(dados.destino, pdf_buffer.read(), nome_arquivo, venda.id)
        elif dados.canal == "email":
            enviar_comprovante_email(dados.destino, pdf_buffer.read(), nome_arquivo, venda.id)
        else:
            raise HTTPException(status_code=400, detail="Canal deve ser 'whatsapp' ou 'email'")
    except RuntimeError as erro:
        raise HTTPException(status_code=503, detail=str(erro))

    venda.comprovante_enviado = True
    db.commit()
    return {"status": "enviado", "canal": dados.canal, "destino": dados.destino}

"""
Router de Comandas - "pausar" uma venda em andamento e retomar depois.
Não mexe em estoque - isso só acontece quando a venda é de fato finalizada
(endpoint normal de /api/vendas), igual sempre foi.
"""
import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import Comanda, Produto, Cliente
from app.schemas import ComandaCriar, ComandaResposta, ComandaDetalhe, ItemComandaDetalhe
from app.dependencies import usuario_logado

router = APIRouter(prefix="/api/comandas", tags=["Comandas"])


@router.post("", response_model=ComandaResposta)
def pausar_venda(dados: ComandaCriar, db: Session = Depends(get_db), usuario: dict = Depends(usuario_logado)):
    """Salva o carrinho atual como uma comanda pausada, pra retomar depois."""
    if not dados.itens:
        raise HTTPException(status_code=400, detail="Não dá pra pausar um carrinho vazio")

    if dados.cliente_id and not db.get(Cliente, dados.cliente_id):
        raise HTTPException(status_code=404, detail="Cliente informado não existe")

    comanda = Comanda(
        identificador=dados.identificador,
        cliente_id=dados.cliente_id,
        usuario_id=int(usuario["sub"]),
        itens_json=json.dumps([i.model_dump() for i in dados.itens]),
    )
    db.add(comanda)
    db.commit()
    db.refresh(comanda)

    return ComandaResposta(
        id=comanda.id,
        identificador=comanda.identificador,
        cliente_id=comanda.cliente_id,
        cliente_nome=comanda.cliente.nome if comanda.cliente else None,
        usuario_nome=comanda.usuario.nome,
        quantidade_itens=len(dados.itens),
        criada_em=comanda.criada_em,
    )


@router.get("", response_model=list[ComandaResposta])
def listar_comandas(db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Lista as comandas em aberto - qualquer atendente pode ver e retomar qualquer uma (é uma loja só, um caixa)."""
    comandas = db.scalars(select(Comanda).order_by(Comanda.criada_em.desc())).all()
    return [
        ComandaResposta(
            id=c.id,
            identificador=c.identificador,
            cliente_id=c.cliente_id,
            cliente_nome=c.cliente.nome if c.cliente else None,
            usuario_nome=c.usuario.nome,
            quantidade_itens=len(json.loads(c.itens_json)),
            criada_em=c.criada_em,
        )
        for c in comandas
    ]


@router.get("/{comanda_id}", response_model=ComandaDetalhe)
def detalhar_comanda(comanda_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """
    Detalha uma comanda pra retomar no carrinho. Busca o preço/estoque ATUAL
    do produto (não um preço congelado) - se o preço mudou desde que a
    comanda foi pausada, o carrinho retomado já reflete o valor certo.
    """
    comanda = db.get(Comanda, comanda_id)
    if not comanda:
        raise HTTPException(status_code=404, detail="Comanda não encontrada")

    itens_salvos = json.loads(comanda.itens_json)
    itens_detalhados = []
    for item in itens_salvos:
        produto = db.get(Produto, item["produto_id"])
        if not produto or not produto.ativo:
            continue  # produto foi excluído/desativado nesse meio tempo - ignora, não quebra a comanda inteira
        itens_detalhados.append(ItemComandaDetalhe(
            produto_id=produto.id,
            nome=produto.nome,
            preco_venda=produto.preco_venda,
            quantidade=item["quantidade"],
            quantidade_estoque=produto.quantidade_estoque,
        ))

    return ComandaDetalhe(
        id=comanda.id,
        identificador=comanda.identificador,
        cliente_id=comanda.cliente_id,
        cliente_nome=comanda.cliente.nome if comanda.cliente else None,
        itens=itens_detalhados,
    )


@router.delete("/{comanda_id}")
def excluir_comanda(comanda_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Remove uma comanda - usado tanto ao retomar (ela 'vira' carrinho ativo) quanto ao cancelar de vez."""
    comanda = db.get(Comanda, comanda_id)
    if not comanda:
        raise HTTPException(status_code=404, detail="Comanda não encontrada")
    db.delete(comanda)
    db.commit()
    return {"status": "comanda removida"}

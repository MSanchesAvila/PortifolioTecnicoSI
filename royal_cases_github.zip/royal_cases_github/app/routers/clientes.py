"""
Router de Clientes.
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, or_, func

from app.database import get_db
from app.models import Cliente, Venda, ItemVenda, Produto
from app.schemas import ClienteCriar, ClienteResposta, ClienteEditar
from app.dependencies import usuario_logado

router = APIRouter(prefix="/api/clientes", tags=["Clientes"])


@router.post("", response_model=ClienteResposta)
def criar_cliente(dados: ClienteCriar, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Cadastra um cliente novo (RF07)."""
    # Evita duplicar cliente pelo mesmo CPF, se informado
    if dados.cpf:
        existente = db.scalar(select(Cliente).where(Cliente.cpf == dados.cpf))
        if existente:
            raise HTTPException(status_code=400, detail="Já existe um cliente cadastrado com este CPF")

    cliente = Cliente(nome=dados.nome, telefone=dados.telefone, email=dados.email, cpf=dados.cpf)
    db.add(cliente)
    db.commit()
    db.refresh(cliente)
    return cliente


@router.get("", response_model=list[ClienteResposta])
def listar_clientes(db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Lista todos os clientes cadastrados."""
    return db.scalars(select(Cliente).order_by(Cliente.nome)).all()


@router.get("/buscar", response_model=list[ClienteResposta])
def buscar_cliente(q: str = Query(..., description="Nome, telefone ou CPF"), db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """
    Busca rápida de cliente - usada no caixa no momento da venda.
    O atendente digita telefone (ou nome, ou CPF) e o sistema traz quem bate.
    """
    termo = f"%{q}%"
    resultados = db.scalars(
        select(Cliente).where(
            or_(
                Cliente.nome.ilike(termo),
                Cliente.telefone.ilike(termo),
                Cliente.cpf.ilike(termo),
            )
        )
    ).all()
    return resultados


@router.put("/{cliente_id}", response_model=ClienteResposta)
def editar_cliente(
    cliente_id: int, dados: ClienteEditar, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)
):
    """Edita dados de um cliente já cadastrado (corrigir telefone digitado errado, etc)."""
    cliente = db.get(Cliente, cliente_id)
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")

    dados_informados = dados.model_dump(exclude_unset=True)

    if "cpf" in dados_informados and dados_informados["cpf"]:
        existente = db.scalar(select(Cliente).where(Cliente.cpf == dados_informados["cpf"], Cliente.id != cliente_id))
        if existente:
            raise HTTPException(status_code=400, detail="Já existe outro cliente cadastrado com este CPF")

    for campo, valor in dados_informados.items():
        setattr(cliente, campo, valor)

    db.commit()
    db.refresh(cliente)
    return cliente


@router.get("/{cliente_id}/resumo")
def resumo_cliente(cliente_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """
    Resumo estilo CRM: última compra, dias sem comprar, status e produtos
    favoritos (os mais comprados por esse cliente). Mesmo modelo da planilha
    que a loja usava antes (Ativo ≤30 dias, Em Risco 31-60, Inativo >60).
    """
    cliente = db.get(Cliente, cliente_id)
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente não encontrado")

    vendas_cliente = db.scalars(
        select(Venda).where(Venda.cliente_id == cliente_id).order_by(Venda.data_hora.desc())
    ).all()

    if not vendas_cliente:
        return {
            "cliente_id": cliente_id,
            "nome": cliente.nome,
            "total_compras": 0,
            "valor_total_gasto": 0.0,
            "ultima_compra": None,
            "dias_sem_comprar": None,
            "status": "sem_compras",
            "produtos_favoritos": [],
            "pontos_fidelidade": cliente.pontos_fidelidade,
        }

    ultima_venda = vendas_cliente[0]
    dias_sem_comprar = (datetime.utcnow() - ultima_venda.data_hora).days

    if dias_sem_comprar <= 30:
        status = "ativo"
    elif dias_sem_comprar <= 60:
        status = "em_risco"
    else:
        status = "inativo"

    valor_total_gasto = sum(v.valor_cobrado_cliente for v in vendas_cliente)

    # Produtos favoritos: ranking por quantidade total comprada (não só nº de vendas)
    favoritos = db.execute(
        select(
            Produto.id, Produto.nome,
            func.sum(ItemVenda.quantidade).label("quantidade_total"),
            func.count(func.distinct(ItemVenda.venda_id)).label("vezes_comprado"),
        )
        .join(ItemVenda, ItemVenda.produto_id == Produto.id)
        .join(Venda, Venda.id == ItemVenda.venda_id)
        .where(Venda.cliente_id == cliente_id)
        .group_by(Produto.id, Produto.nome)
        .order_by(func.sum(ItemVenda.quantidade).desc())
        .limit(5)
    ).all()

    return {
        "cliente_id": cliente_id,
        "nome": cliente.nome,
        "total_compras": len(vendas_cliente),
        "valor_total_gasto": round(valor_total_gasto, 2),
        "ultima_compra": {
            "data": ultima_venda.data_hora.isoformat(),
            "valor": ultima_venda.valor_cobrado_cliente,
        },
        "dias_sem_comprar": dias_sem_comprar,
        "status": status,
        "pontos_fidelidade": cliente.pontos_fidelidade,
        "produtos_favoritos": [
            {"produto_id": f.id, "nome": f.nome, "quantidade_total": f.quantidade_total, "vezes_comprado": f.vezes_comprado}
            for f in favoritos
        ],
    }

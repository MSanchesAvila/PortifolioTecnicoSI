"""
Router de Fidelidade - configuração do programa de pontos.
Mesmo padrão da taxa/frete: ver = qualquer logado (o PDV precisa saber a
taxa de conversão pra calcular o desconto), editar = só gestor.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import ConfiguracaoFidelidade
from app.schemas import ConfiguracaoFidelidadeEditar, ConfiguracaoFidelidadeResposta
from app.dependencies import usuario_logado, exigir_gestor

router = APIRouter(prefix="/api/fidelidade", tags=["Fidelidade"])


def _obter_ou_criar_configuracao(db: Session) -> ConfiguracaoFidelidade:
    """Sempre há exatamente 1 linha de configuração - cria com valores padrão na primeira vez que for acessada."""
    config = db.query(ConfiguracaoFidelidade).first()
    if not config:
        config = ConfiguracaoFidelidade(pontos_por_real=1.0, valor_resgate_por_ponto=0.05, ativo=True)
        db.add(config)
        db.commit()
        db.refresh(config)
    return config


@router.get("/configuracao", response_model=ConfiguracaoFidelidadeResposta)
def obter_configuracao(db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Devolve a configuração atual (qualquer logado - o PDV precisa disso pra calcular o resgate)."""
    return _obter_ou_criar_configuracao(db)


@router.put("/configuracao", response_model=ConfiguracaoFidelidadeResposta)
def atualizar_configuracao(dados: ConfiguracaoFidelidadeEditar, db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """Atualiza a taxa de conversão de pontos - só gestor, afeta o cálculo de todas as vendas futuras."""
    config = _obter_ou_criar_configuracao(db)
    config.pontos_por_real = dados.pontos_por_real
    config.valor_resgate_por_ponto = dados.valor_resgate_por_ponto
    config.ativo = dados.ativo
    db.commit()
    db.refresh(config)
    return config

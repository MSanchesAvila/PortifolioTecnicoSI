"""
Router de Regiões de Entrega - cadastro de frete por região.
Mesmo padrão da configuração de taxa de pagamento: ver = qualquer logado
(precisa calcular no PDV), editar = só gestor (afeta o valor cobrado em
toda venda futura com entrega).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import RegiaoEntrega
from app.schemas import RegiaoEntregaCriar, RegiaoEntregaResposta
from app.dependencies import usuario_logado, exigir_gestor

router = APIRouter(prefix="/api/regioes-entrega", tags=["Regiões de Entrega"])


@router.post("", response_model=RegiaoEntregaResposta)
def criar_regiao(dados: RegiaoEntregaCriar, db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """Cadastra uma região de entrega nova, com o valor do frete."""
    regiao = RegiaoEntrega(nome=dados.nome, valor_frete=dados.valor_frete)
    db.add(regiao)
    db.commit()
    db.refresh(regiao)
    return regiao


@router.get("", response_model=list[RegiaoEntregaResposta])
def listar_regioes(
    incluir_inativas: bool = False, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)
):
    """Lista regiões de entrega ativas (qualquer logado - precisa escolher no PDV)."""
    query = select(RegiaoEntrega)
    if not incluir_inativas:
        query = query.where(RegiaoEntrega.ativo == True)
    return db.scalars(query.order_by(RegiaoEntrega.nome)).all()


@router.put("/{regiao_id}", response_model=RegiaoEntregaResposta)
def editar_regiao(regiao_id: int, dados: RegiaoEntregaCriar, db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """Edita nome/valor de uma região existente."""
    regiao = db.get(RegiaoEntrega, regiao_id)
    if not regiao:
        raise HTTPException(status_code=404, detail="Região não encontrada")
    regiao.nome = dados.nome
    regiao.valor_frete = dados.valor_frete
    db.commit()
    db.refresh(regiao)
    return regiao


@router.patch("/{regiao_id}/alternar-ativo", response_model=RegiaoEntregaResposta)
def alternar_ativo_regiao(regiao_id: int, db: Session = Depends(get_db), _gestor=Depends(exigir_gestor)):
    """Ativa/desativa uma região (não exclui - preserva o histórico de vendas que já usaram ela)."""
    regiao = db.get(RegiaoEntrega, regiao_id)
    if not regiao:
        raise HTTPException(status_code=404, detail="Região não encontrada")
    regiao.ativo = not regiao.ativo
    db.commit()
    db.refresh(regiao)
    return regiao

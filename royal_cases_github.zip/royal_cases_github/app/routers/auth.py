"""
Router de Autenticacao.

Nota de seguranca importante: "usuarios.gerenciar" (permissao configuravel)
libera CRIAR/LISTAR/ATIVAR-DESATIVAR atendentes. Mas DEFINIR quais
permissoes cada um tem, e criar outro GESTOR, continuam exclusivos de
quem ja e gestor - senao um atendente com essa permissao poderia se
autopromover ou dar poderes a si mesmo.
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import select
from datetime import datetime, timedelta

from app.database import get_db
from app.models import Usuario, PerfilUsuario, RedefinicaoSenha
from app.schemas import (
    LoginRequest, TokenResposta, UsuarioCriar, UsuarioResposta, PermissoesAtualizar,
    SenhaAtualizar, EsqueciSenhaRequest, RedefinirSenhaRequest, MeuPerfilEditar,
)
from app.auth_utils import (
    hash_senha, verificar_senha, criar_token,
    gerar_token_redefinicao, hash_token_redefinicao, EXPIRA_REDEFINICAO_MINUTOS,
)
from app.dependencies import exigir_gestor, usuario_logado, exigir_permissao
from app.permissoes import PERMISSOES_DISPONIVEIS
from app.rate_limit import registrar_tentativa_falha, limite_excedido, limpar_tentativas
from app.envio_utils import enviar_email_redefinicao_senha
from app.config import BASE_URL

router = APIRouter(prefix="/api/auth", tags=["Autenticação"])


@router.post("/login", response_model=TokenResposta)
def login(dados: LoginRequest, request: Request, db: Session = Depends(get_db)):
    """
    Autentica o usuário e devolve o token (crachá digital).
    Bloqueia temporariamente após muitas tentativas erradas seguidas
    (proteção contra alguém tentando adivinhar a senha por força bruta).
    """
    ip_cliente = request.client.host if request.client else "desconhecido"

    if limite_excedido(ip_cliente):
        raise HTTPException(
            status_code=429,
            detail="Muitas tentativas de login. Aguarde alguns minutos e tente novamente.",
        )

    usuario = db.scalar(select(Usuario).where(Usuario.login == dados.login))

    if not usuario or not usuario.ativo or not verificar_senha(dados.senha, usuario.senha_hash):
        registrar_tentativa_falha(ip_cliente)
        raise HTTPException(status_code=401, detail="Login ou senha inválidos")

    limpar_tentativas(ip_cliente)
    token = criar_token(usuario.id, usuario.login, usuario.perfil.value)
    return TokenResposta(access_token=token, perfil=usuario.perfil.value, nome=usuario.nome)


@router.get("/permissoes-disponiveis")
def permissoes_disponiveis(_gestor=Depends(exigir_gestor)):
    """Lista as permissões que existem no sistema (pra montar a tela de gestão)."""
    return PERMISSOES_DISPONIVEIS


@router.post("/usuarios", response_model=UsuarioResposta)
def criar_usuario(
    dados: UsuarioCriar,
    db: Session = Depends(get_db),
    usuario_atual: dict = Depends(exigir_permissao("usuarios.gerenciar")),
):
    """
    Cadastra um novo usuário. Exige a permissão 'usuarios.gerenciar'
    (gestor sempre tem). Atendente com essa permissão só pode criar
    OUTRO ATENDENTE - nunca um gestor (evita escalada de privilégio).
    """
    if db.scalar(select(Usuario).where(Usuario.login == dados.login)):
        raise HTTPException(status_code=400, detail="Este login já está em uso")
    if db.scalar(select(Usuario).where(Usuario.email == dados.email)):
        raise HTTPException(status_code=400, detail="Este e-mail já está em uso por outro usuário")

    try:
        perfil = PerfilUsuario(dados.perfil)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Perfil inválido: {dados.perfil}")

    if usuario_atual["perfil"] != "gestor" and perfil != PerfilUsuario.ATENDENTE:
        raise HTTPException(status_code=403, detail="Você só pode cadastrar usuários com perfil atendente")

    usuario = Usuario(
        nome=dados.nome,
        login=dados.login,
        email=dados.email,
        senha_hash=hash_senha(dados.senha),
        perfil=perfil,
    )
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return usuario


@router.get("/me", response_model=UsuarioResposta)
def meus_dados(usuario_token: dict = Depends(usuario_logado), db: Session = Depends(get_db)):
    """Retorna os dados de quem está logado (útil pro front-end saber o perfil atual)."""
    usuario = db.get(Usuario, int(usuario_token["sub"]))
    return usuario


@router.patch("/me", response_model=UsuarioResposta)
def editar_meu_perfil(
    dados: MeuPerfilEditar, usuario_token: dict = Depends(usuario_logado), db: Session = Depends(get_db)
):
    """Edita o próprio nome/e-mail - importante pra quem foi criado sem e-mail poder cadastrar um depois."""
    usuario = db.get(Usuario, int(usuario_token["sub"]))

    if dados.email:
        existente = db.scalar(select(Usuario).where(Usuario.email == dados.email, Usuario.id != usuario.id))
        if existente:
            raise HTTPException(status_code=400, detail="Este e-mail já está em uso por outro usuário")

    dados_informados = dados.model_dump(exclude_unset=True)
    for campo, valor in dados_informados.items():
        setattr(usuario, campo, valor)

    db.commit()
    db.refresh(usuario)
    return usuario


@router.patch("/me/senha")
def trocar_minha_senha(
    dados: SenhaAtualizar,
    usuario_token: dict = Depends(usuario_logado),
    db: Session = Depends(get_db),
):
    """
    Troca a própria senha. Exige a senha atual pra confirmar identidade -
    qualquer usuário logado (gestor ou atendente) pode trocar a PRÓPRIA senha,
    mas nunca a de outra pessoa por aqui.
    """
    usuario = db.get(Usuario, int(usuario_token["sub"]))
    if not verificar_senha(dados.senha_atual, usuario.senha_hash):
        raise HTTPException(status_code=401, detail="Senha atual incorreta")

    if len(dados.senha_nova) < 6:
        raise HTTPException(status_code=400, detail="A nova senha precisa ter pelo menos 6 caracteres")

    usuario.senha_hash = hash_senha(dados.senha_nova)
    db.commit()
    return {"status": "senha alterada com sucesso"}


@router.get("/usuarios", response_model=list[UsuarioResposta], dependencies=[Depends(exigir_permissao("usuarios.gerenciar"))])
def listar_usuarios(db: Session = Depends(get_db)):
    """Lista todos os usuários - exige a permissão 'usuarios.gerenciar'."""
    return db.scalars(select(Usuario).order_by(Usuario.nome)).all()


@router.patch("/usuarios/{usuario_id}/alternar-ativo", response_model=UsuarioResposta)
def alternar_ativo(
    usuario_id: int,
    db: Session = Depends(get_db),
    usuario_atual: dict = Depends(exigir_permissao("usuarios.gerenciar")),
):
    """Ativa ou desativa um usuário - exige a permissão 'usuarios.gerenciar'."""
    if usuario_id == int(usuario_atual["sub"]):
        raise HTTPException(status_code=400, detail="Você não pode desativar seu próprio usuário")

    usuario = db.get(Usuario, usuario_id)
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    usuario.ativo = not usuario.ativo
    db.commit()
    db.refresh(usuario)
    return usuario


@router.put("/usuarios/{usuario_id}/permissoes", response_model=UsuarioResposta)
def atualizar_permissoes(
    usuario_id: int,
    dados: PermissoesAtualizar,
    db: Session = Depends(get_db),
    _gestor=Depends(exigir_gestor),  # EXCLUSIVO do gestor - nunca configurável
):
    """Define a lista completa de permissões extras de um atendente. Só o gestor pode fazer isso."""
    usuario = db.get(Usuario, usuario_id)
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    if usuario.perfil == PerfilUsuario.GESTOR:
        raise HTTPException(status_code=400, detail="Gestor já tem todas as permissões por padrão")

    invalidas = [p for p in dados.permissoes if p not in PERMISSOES_DISPONIVEIS]
    if invalidas:
        raise HTTPException(status_code=400, detail=f"Permissões inválidas: {invalidas}")

    usuario.permissoes_extra_raw = ",".join(dados.permissoes)
    db.commit()
    db.refresh(usuario)
    return usuario


@router.post("/esqueci-senha")
def esqueci_senha(dados: EsqueciSenhaRequest, request: Request, db: Session = Depends(get_db)):
    """
    Pede o e-mail de recuperação de senha.

    IMPORTANTE DE SEGURANÇA: a resposta é SEMPRE a mesma, exista ou não esse
    e-mail no sistema. Se disséssemos "e-mail não encontrado", alguém de fora
    poderia descobrir quais e-mails têm conta só testando um por um - isso se
    chama "enumeração de usuário". Por isso a mensagem nunca revela se deu
    certo de verdade.
    """
    ip_cliente = request.client.host if request.client else "desconhecido"
    chave_limite = f"esqueci-senha:{ip_cliente}"

    if limite_excedido(chave_limite):
        # Mesmo aqui, não revelamos detalhe demais - só que precisa esperar
        raise HTTPException(status_code=429, detail="Muitas tentativas. Aguarde alguns minutos e tente novamente.")
    registrar_tentativa_falha(chave_limite)  # conta toda tentativa, dá certo ou não, pra limitar abuso

    usuario = db.scalar(select(Usuario).where(Usuario.email == dados.email, Usuario.ativo == True))

    if usuario:
        token = gerar_token_redefinicao()
        redefinicao = RedefinicaoSenha(
            usuario_id=usuario.id,
            token_hash=hash_token_redefinicao(token),
            expira_em=datetime.utcnow() + timedelta(minutes=EXPIRA_REDEFINICAO_MINUTOS),
        )
        db.add(redefinicao)
        db.commit()

        link = f"{BASE_URL}/redefinir-senha?token={token}"
        try:
            enviar_email_redefinicao_senha(usuario.email, link)
        except RuntimeError:
            # SMTP não configurado - não revela isso ao usuário final (mesma
            # resposta genérica), mas fica registrado no log do servidor
            # pro gestor perceber que precisa configurar o e-mail.
            pass

    return {"status": "Se esse e-mail estiver cadastrado, você vai receber um link de redefinição em instantes."}


@router.post("/redefinir-senha")
def redefinir_senha(dados: RedefinirSenhaRequest, db: Session = Depends(get_db)):
    """Usa o token recebido por e-mail pra definir uma senha nova."""
    token_hash = hash_token_redefinicao(dados.token)
    redefinicao = db.scalar(
        select(RedefinicaoSenha).where(
            RedefinicaoSenha.token_hash == token_hash,
            RedefinicaoSenha.usado == False,
        )
    )

    if not redefinicao or redefinicao.expira_em < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Link inválido ou expirado. Peça um novo link de redefinição.")

    usuario = db.get(Usuario, redefinicao.usuario_id)
    if not usuario or not usuario.ativo:
        raise HTTPException(status_code=400, detail="Link inválido.")

    usuario.senha_hash = hash_senha(dados.senha_nova)
    redefinicao.usado = True  # token de uso único - não pode ser reaproveitado
    db.commit()

    return {"status": "Senha redefinida com sucesso. Você já pode fazer login com a senha nova."}

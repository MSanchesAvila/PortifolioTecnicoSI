"""
Router de Fornecedores - entidade própria (antes era só texto livre no produto).
Mesma regra de permissão do cadastro de produto: quem pode cadastrar
produto, pode cadastrar fornecedor.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import Fornecedor
from app.schemas import FornecedorCriar, FornecedorResposta
from app.dependencies import usuario_logado, exigir_permissao

router = APIRouter(prefix="/api/fornecedores", tags=["Fornecedores"])


@router.post("", response_model=FornecedorResposta, dependencies=[Depends(exigir_permissao("produtos.cadastrar"))])
def criar_fornecedor(dados: FornecedorCriar, db: Session = Depends(get_db)):
    """Cadastra um fornecedor novo."""
    fornecedor = Fornecedor(**dados.model_dump())
    db.add(fornecedor)
    db.commit()
    db.refresh(fornecedor)
    return fornecedor


@router.get("", response_model=list[FornecedorResposta])
def listar_fornecedores(db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Lista todos os fornecedores - qualquer usuário logado pode ver (não é dado sensível)."""
    return db.scalars(select(Fornecedor).order_by(Fornecedor.nome)).all()


@router.put("/{fornecedor_id}", response_model=FornecedorResposta, dependencies=[Depends(exigir_permissao("produtos.cadastrar"))])
def editar_fornecedor(fornecedor_id: int, dados: FornecedorCriar, db: Session = Depends(get_db)):
    """Edita um fornecedor já cadastrado."""
    fornecedor = db.get(Fornecedor, fornecedor_id)
    if not fornecedor:
        raise HTTPException(status_code=404, detail="Fornecedor não encontrado")
    for campo, valor in dados.model_dump().items():
        setattr(fornecedor, campo, valor)
    db.commit()
    db.refresh(fornecedor)
    return fornecedor


@router.get("/{fornecedor_id}/produtos")
def produtos_do_fornecedor(fornecedor_id: int, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Histórico simples: quais produtos estão ligados a esse fornecedor."""
    from app.models import Produto
    fornecedor = db.get(Fornecedor, fornecedor_id)
    if not fornecedor:
        raise HTTPException(status_code=404, detail="Fornecedor não encontrado")
    produtos = db.scalars(select(Produto).where(Produto.fornecedor_id == fornecedor_id)).all()
    return [{"id": p.id, "nome": p.nome, "codigo_barras": p.codigo_barras, "quantidade_estoque": p.quantidade_estoque} for p in produtos]

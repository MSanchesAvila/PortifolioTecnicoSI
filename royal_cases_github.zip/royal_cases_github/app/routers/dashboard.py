"""
Router de Dashboard - faturamento, lucro e estoque.
Só o perfil GESTOR deveria acessar isso na prática (aplicamos isso quando
tivermos login/autenticacao); por ora, o endpoint existe e assume visao gestor.
"""
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, func

from app.database import get_db
from app.models import Venda, ItemVenda, Produto
from app.dependencies import exigir_permissao

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/faturamento")
def faturamento_periodo(
    inicio: Optional[datetime] = Query(None, description="Data/hora inicial (ISO). Padrao: inicio do dia de hoje"),
    fim: Optional[datetime] = Query(None, description="Data/hora final (ISO). Padrao: agora"),
    db: Session = Depends(get_db),
    _permissao=Depends(exigir_permissao("dashboard.ver")),
):
    """
    Faturamento e lucro consolidado de um periodo (RF15).
    Sem parametros = retorna o dia de hoje.
    """
    if inicio is None:
        inicio = datetime.combine(datetime.utcnow().date(), datetime.min.time())
    if fim is None:
        fim = datetime.utcnow()

    resultado = db.execute(
        select(
            func.count(Venda.id).label("qtd_vendas"),
            func.coalesce(func.sum(Venda.valor_total), 0.0).label("faturamento"),
            func.coalesce(func.sum(Venda.custo_total), 0.0).label("custo"),
            func.coalesce(func.sum(Venda.valor_recebido_loja), 0.0).label("valor_recebido"),
            func.coalesce(
                func.sum(func.coalesce(Venda.taxa_valor, 0.0)).filter(Venda.taxa_assumida_por == "loja"), 0.0
            ).label("taxas_absorvidas"),
        ).where(Venda.data_hora.between(inicio, fim))
    ).one()

    faturamento = round(resultado.faturamento, 2)
    custo = round(resultado.custo, 2)
    valor_recebido = round(resultado.valor_recebido, 2)
    taxas_absorvidas = round(resultado.taxas_absorvidas or 0.0, 2)
    # Lucro real = o que efetivamente entrou na conta (já descontada a taxa que a loja assumiu) menos o custo
    lucro = round(valor_recebido - custo, 2)
    margem_pct = round((lucro / faturamento) * 100, 2) if faturamento else 0.0

    return {
        "periodo_inicio": inicio,
        "periodo_fim": fim,
        "quantidade_vendas": resultado.qtd_vendas,
        "faturamento": faturamento,
        "custo": custo,
        "taxas_absorvidas_pela_loja": taxas_absorvidas,
        "lucro": lucro,
        "margem_percentual": margem_pct,
    }


@router.get("/fechamento-caixa")
def fechamento_caixa(
    data: Optional[str] = Query(None, description="Data no formato YYYY-MM-DD. Padrão: hoje"),
    db: Session = Depends(get_db),
    _permissao=Depends(exigir_permissao("dashboard.ver")),
):
    """
    Fechamento de caixa do dia (RF clássico de PDV): total por forma de
    pagamento, pra bater com o dinheiro/comprovantes de cartão físicos no
    fim do expediente.
    """
    if data:
        dia = datetime.strptime(data, "%Y-%m-%d").date()
    else:
        dia = datetime.utcnow().date()
    inicio = datetime.combine(dia, datetime.min.time())
    fim = datetime.combine(dia, datetime.max.time())

    linhas = db.execute(
        select(
            Venda.forma_pagamento,
            func.count(Venda.id).label("quantidade"),
            func.coalesce(func.sum(Venda.valor_cobrado_cliente), 0.0).label("total"),
        )
        .where(Venda.data_hora.between(inicio, fim))
        .group_by(Venda.forma_pagamento)
    ).all()

    por_forma = {
        l.forma_pagamento.value: {"quantidade": l.quantidade, "total": round(l.total, 2)}
        for l in linhas
    }

    resumo_geral = db.execute(
        select(
            func.count(Venda.id).label("qtd_total"),
            func.coalesce(func.sum(Venda.valor_cobrado_cliente), 0.0).label("faturamento_total"),
            func.coalesce(func.sum(Venda.valor_recebido_loja), 0.0).label("recebido_liquido"),
            func.coalesce(func.sum(Venda.custo_total), 0.0).label("custo_total"),
        ).where(Venda.data_hora.between(inicio, fim))
    ).one()

    lucro = round((resumo_geral.recebido_liquido or 0) - (resumo_geral.custo_total or 0), 2)

    return {
        "data": dia.isoformat(),
        "quantidade_vendas": resumo_geral.qtd_total,
        "faturamento_total": round(resumo_geral.faturamento_total, 2),
        "lucro_total": lucro,
        "por_forma_pagamento": por_forma,
    }


@router.get("/tendencia")
def tendencia_faturamento(
    dias: int = Query(7, ge=2, le=90),
    db: Session = Depends(get_db),
    _permissao=Depends(exigir_permissao("dashboard.ver")),
):
    """
    Faturamento e lucro dia a dia dos últimos N dias - alimenta o gráfico
    de tendência do dashboard.
    """
    hoje = datetime.utcnow().date()
    inicio = datetime.combine(hoje - timedelta(days=dias - 1), datetime.min.time())

    linhas = db.execute(
        select(
            func.date(Venda.data_hora).label("dia"),
            func.coalesce(func.sum(Venda.valor_cobrado_cliente), 0.0).label("faturamento"),
            func.coalesce(func.sum(Venda.valor_recebido_loja), 0.0).label("recebido"),
            func.coalesce(func.sum(Venda.custo_total), 0.0).label("custo"),
        )
        .where(Venda.data_hora >= inicio)
        .group_by(func.date(Venda.data_hora))
    ).all()

    mapa = {str(l.dia): {"faturamento": round(l.faturamento, 2), "lucro": round((l.recebido or 0) - (l.custo or 0), 2)} for l in linhas}

    # Preenche os dias sem venda com zero, pra o grafico nao ter "buraco"
    resultado = []
    for i in range(dias):
        dia = hoje - timedelta(days=dias - 1 - i)
        chave = dia.isoformat()
        dados_dia = mapa.get(chave, {"faturamento": 0.0, "lucro": 0.0})
        resultado.append({"data": chave, **dados_dia})

    return resultado


@router.get("/produtos-mais-lucrativos")
def produtos_mais_lucrativos(
    limite: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    _permissao=Depends(exigir_permissao("dashboard.ver")),
):
    """
    Ranking de produtos por lucro total gerado (soma de todas as vendas).
    Ajuda a responder: "o que eu deveria empurrar mais na loja?"
    """
    linhas = db.execute(
        select(
            Produto.id,
            Produto.nome,
            func.sum(ItemVenda.quantidade).label("unidades_vendidas"),
            func.sum(ItemVenda.preco_unitario_venda * ItemVenda.quantidade).label("faturamento"),
            func.sum(
                (ItemVenda.preco_unitario_venda - ItemVenda.preco_unitario_custo) * ItemVenda.quantidade
            ).label("lucro"),
        )
        .join(ItemVenda, ItemVenda.produto_id == Produto.id)
        .group_by(Produto.id, Produto.nome)
        .order_by(func.sum(
            (ItemVenda.preco_unitario_venda - ItemVenda.preco_unitario_custo) * ItemVenda.quantidade
        ).desc())
        .limit(limite)
    ).all()

    return [
        {
            "produto_id": l.id,
            "nome": l.nome,
            "unidades_vendidas": l.unidades_vendidas,
            "faturamento": round(l.faturamento, 2),
            "lucro": round(l.lucro, 2),
        }
        for l in linhas
    ]


@router.get("/estoque-baixo")
def produtos_estoque_baixo(db: Session = Depends(get_db), _permissao=Depends(exigir_permissao("dashboard.ver"))):
    """Lista produtos com estoque no ou abaixo do minimo definido (RF11, RF16)."""
    produtos = db.scalars(
        select(Produto).where(Produto.quantidade_estoque <= Produto.estoque_minimo, Produto.ativo == True)
    ).all()
    return [
        {
            "produto_id": p.id,
            "nome": p.nome,
            "quantidade_estoque": p.quantidade_estoque,
            "estoque_minimo": p.estoque_minimo,
        }
        for p in produtos
    ]


@router.get("/margem-por-produto")
def margem_por_produto(db: Session = Depends(get_db), _permissao=Depends(exigir_permissao("dashboard.ver"))):
    """
    Margem de cada produto ATIVO com base no preco atual cadastrado
    (diferente do endpoint acima, que olha o HISTORICO de vendas ja realizadas).
    Ajuda a identificar produtos mal precificados (RF16).
    """
    produtos = db.scalars(select(Produto).where(Produto.ativo == True)).all()
    lista = [
        {
            "produto_id": p.id,
            "nome": p.nome,
            "preco_custo": p.preco_custo,
            "preco_venda": p.preco_venda,
            "margem_unitaria": p.margem_unitaria,
            "margem_percentual": p.margem_percentual,
        }
        for p in produtos
    ]
    lista.sort(key=lambda x: x["margem_percentual"])
    return lista

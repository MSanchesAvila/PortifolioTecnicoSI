"""
Router de configuração de taxas de pagamento.
Ver = qualquer usuário logado (precisa saber a taxa pra calcular o valor a
cobrar do cliente durante a venda). Editar = só gestor.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import ConfiguracaoTaxa, FormaPagamento
from app.schemas import ConfiguracaoTaxaResposta, ConfiguracaoTaxaAtualizar
from app.dependencies import usuario_logado, exigir_gestor

router = APIRouter(prefix="/api/pagamentos", tags=["Pagamentos"])


@router.get("/taxas", response_model=list[ConfiguracaoTaxaResposta])
def listar_taxas(db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """Lista todas as taxas configuradas - qualquer usuário logado pode ver."""
    return db.scalars(
        select(ConfiguracaoTaxa).order_by(ConfiguracaoTaxa.forma_pagamento, ConfiguracaoTaxa.numero_parcelas)
    ).all()


@router.put("/taxas", response_model=list[ConfiguracaoTaxaResposta])
def atualizar_taxas(
    dados: ConfiguracaoTaxaAtualizar,
    db: Session = Depends(get_db),
    _gestor=Depends(exigir_gestor),
):
    """
    Substitui TODA a configuração de taxas pela lista enviada.
    Restrito ao gestor - taxa errada afeta o lucro calculado de todas as vendas futuras.
    """
    db.query(ConfiguracaoTaxa).delete()
    for item in dados.taxas:
        forma = FormaPagamento(item.forma_pagamento)  # valida que é uma forma de pagamento válida
        db.add(ConfiguracaoTaxa(
            forma_pagamento=forma,
            numero_parcelas=item.numero_parcelas,
            taxa_percentual=item.taxa_percentual,
        ))
    db.commit()
    return db.scalars(
        select(ConfiguracaoTaxa).order_by(ConfiguracaoTaxa.forma_pagamento, ConfiguracaoTaxa.numero_parcelas)
    ).all()

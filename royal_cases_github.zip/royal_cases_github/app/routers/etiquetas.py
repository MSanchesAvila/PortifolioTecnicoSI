"""
Router de impressão de etiquetas em lote - folha Pimaco A4251
(5 colunas x 13 linhas, 65 etiquetas por folha A4).
"""
import io

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

from app.database import get_db
from app.models import Produto
from app.barcode_utils import gerar_folhas_etiquetas, CONFIG_PADRAO_FOLHA, A4_LARGURA_MM, A4_ALTURA_MM
from app.dependencies import usuario_logado

router = APIRouter(prefix="/api/etiquetas", tags=["Etiquetas"])


class ItemEtiqueta(BaseModel):
    produto_id: int
    quantidade: int = Field(default=1, ge=1, le=65, description="Quantas etiquetas desse produto imprimir")


class GerarFolhaRequest(BaseModel):
    itens: list[ItemEtiqueta]
    # Margens/grade - opcional, usa o padrão da Pimaco A4251 se não informado.
    # Ajuste aqui se a primeira impressão física sair alguns mm deslocada.
    colunas: int = Field(default=CONFIG_PADRAO_FOLHA["colunas"], ge=1, le=10)
    linhas: int = Field(default=CONFIG_PADRAO_FOLHA["linhas"], ge=1, le=30)
    margem_superior_mm: float = Field(default=CONFIG_PADRAO_FOLHA["margem_superior_mm"], ge=0)
    margem_esquerda_mm: float = Field(default=CONFIG_PADRAO_FOLHA["margem_esquerda_mm"], ge=0)
    espaco_horizontal_mm: float = Field(default=CONFIG_PADRAO_FOLHA["espaco_horizontal_mm"], ge=0)
    espaco_vertical_mm: float = Field(default=CONFIG_PADRAO_FOLHA["espaco_vertical_mm"], ge=0)


@router.get("/configuracao-padrao")
def obter_configuracao_padrao(_usuario: dict = Depends(usuario_logado)):
    """Devolve a configuração padrão (Pimaco A4251) - útil pro front-end pré-preencher o formulário de ajuste."""
    return CONFIG_PADRAO_FOLHA


@router.post("/gerar-folha")
def gerar_folha(dados: GerarFolhaRequest, db: Session = Depends(get_db), _usuario: dict = Depends(usuario_logado)):
    """
    Gera um PDF (uma ou mais páginas A4) com as etiquetas posicionadas na
    grade da Pimaco A4251, prontas pra imprimir em "tamanho real" (sem
    ajustar à página) direto no papel adesivo.
    """
    if not dados.itens:
        raise HTTPException(status_code=400, detail="Selecione ao menos um produto")

    itens_com_dados = []
    for item in dados.itens:
        produto = db.get(Produto, item.produto_id)
        if not produto:
            raise HTTPException(status_code=404, detail=f"Produto id={item.produto_id} não encontrado")
        itens_com_dados.append({
            "codigo": produto.codigo_barras,
            "nome": produto.nome,
            "preco_venda": produto.preco_promocional if produto.preco_promocional else produto.preco_venda,
            "quantidade": item.quantidade,
        })

    config = {
        "colunas": dados.colunas,
        "linhas": dados.linhas,
        "margem_superior_mm": dados.margem_superior_mm,
        "margem_esquerda_mm": dados.margem_esquerda_mm,
        "espaco_horizontal_mm": dados.espaco_horizontal_mm,
        "espaco_vertical_mm": dados.espaco_vertical_mm,
    }
    folhas = gerar_folhas_etiquetas(itens_com_dados, config)

    buffer_pdf = io.BytesIO()
    c = canvas.Canvas(buffer_pdf, pagesize=A4)
    largura_pt, altura_pt = A4  # em pontos (reportlab), A4 = 210x297mm já embutido

    for folha_imagem in folhas:
        buffer_img = io.BytesIO()
        folha_imagem.save(buffer_img, format="PNG")
        buffer_img.seek(0)
        from reportlab.lib.utils import ImageReader
        c.drawImage(ImageReader(buffer_img), 0, 0, width=largura_pt, height=altura_pt)
        c.showPage()

    c.save()
    buffer_pdf.seek(0)

    total_etiquetas = sum(i.quantidade for i in dados.itens)
    return StreamingResponse(
        buffer_pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=etiquetas_royal_cases_{total_etiquetas}un.pdf"},
    )

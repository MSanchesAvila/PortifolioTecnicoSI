"""
Utilitários de autenticação.
- hash_senha / verificar_senha: nunca guardamos senha em texto puro (bcrypt)
- criar_token / decodificar_token: geram e validam o "crachá digital" (JWT)
  que o sistema usa pra saber quem está logado em cada requisição, sem
  precisar pedir usuário/senha de novo a cada clique.
- gerar_token_redefinicao / hash_token_redefinicao: pro "esqueci minha senha".
"""
import os
import hashlib
import secrets
from datetime import datetime, timedelta

import bcrypt
import jwt

# Em produção real, essa chave deveria vir de uma variável de ambiente,
# nunca hardcoded no código - por enquanto, pra desenvolvimento, fica aqui.
SECRET_KEY = os.environ.get("ROYAL_CASES_SECRET_KEY", "chave-temporaria-trocar-em-producao")
ALGORITHM = "HS256"
EXPIRA_EM_HORAS = 12  # depois de logar, o "crachá" vale por 12h (um turno de trabalho)
EXPIRA_REDEFINICAO_MINUTOS = 30  # link de "esqueci minha senha" vale por só 30 min


def hash_senha(senha: str) -> str:
    """Transforma a senha em um hash irreversível para salvar no banco."""
    return bcrypt.hashpw(senha.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verificar_senha(senha_digitada: str, senha_hash: str) -> bool:
    """Confere se a senha digitada bate com o hash salvo, sem nunca descriptografar o hash."""
    return bcrypt.checkpw(senha_digitada.encode("utf-8"), senha_hash.encode("utf-8"))


def criar_token(usuario_id: int, login: str, perfil: str) -> str:
    """
    Cria o token JWT - um "crachá digital" assinado que guarda quem é o
    usuário e seu perfil (gestor/atendente), com validade de algumas horas.
    """
    payload = {
        "sub": str(usuario_id),
        "login": login,
        "perfil": perfil,
        "exp": datetime.utcnow() + timedelta(hours=EXPIRA_EM_HORAS),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decodificar_token(token: str) -> dict:
    """
    Valida o token e devolve os dados de quem está logado.
    Lança jwt.ExpiredSignatureError se o crachá venceu,
    ou jwt.InvalidTokenError se foi adulterado/inválido.
    """
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])


def gerar_token_redefinicao() -> str:
    """
    Gera o token que vai no link de e-mail ("esqueci minha senha").
    secrets.token_urlsafe é criptograficamente seguro - impossível de
    adivinhar por tentativa (32 bytes = muito mais forte que uma senha).
    """
    return secrets.token_urlsafe(32)


def hash_token_redefinicao(token: str) -> str:
    """
    Transforma o token num hash pra salvar no banco - igual fazemos com
    senha, mas aqui usamos SHA-256 (rápido) em vez de bcrypt (lento de
    propósito): o token já É aleatório e longo o bastante sozinho, não
    precisa da "lentidão proposital" que o bcrypt usa contra senhas curtas
    e previsíveis. E precisamos poder BUSCAR pelo hash no banco (bcrypt
    gera um hash diferente toda vez, mesmo pro mesmo valor - não dá pra
    buscar por ele diretamente).
    """
    return hashlib.sha256(token.encode("utf-8")).hexdigest()

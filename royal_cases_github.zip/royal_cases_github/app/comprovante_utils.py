"""
Geração de comprovante de compra (RF09, RF10).
- gerar_html_comprovante: HTML estreito pra impressão via navegador (Cloud Run)
- gerar_bytes_termica: comandos ESC/POS (só útil rodando local com USB direto)
- gerar_pdf_comprovante: PDF pra envio digital (WhatsApp / e-mail)
"""
import io
from datetime import datetime

from escpos.printer import Dummy
from reportlab.lib.pagesizes import A6
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

NOME_LOJA = "ROYAL CASES"


def _linhas_itens(venda, itens_detalhados):
    """
    itens_detalhados: lista de dicts {nome, quantidade, preco_unitario_venda}
    (montada no router, que já tem acesso ao nome do produto via relationship)
    """
    linhas = []
    for item in itens_detalhados:
        subtotal = item["preco_unitario_venda"] * item["quantidade"]
        linhas.append(
            f"{item['nome'][:24]:<24} {item['quantidade']:>2}x {item['preco_unitario_venda']:>6.2f} = {subtotal:>7.2f}"
        )
    return linhas


def gerar_html_comprovante(venda, cliente_nome, itens_detalhados) -> str:
    """
    Gera o comprovante como uma página HTML estreita (imita largura de bobina
    térmica, 80mm), pronta pra ser aberta numa nova janela e impressa com
    window.print() - usando o driver da impressora já instalado no Windows.

    Esse é o caminho usado quando o backend roda na nuvem (Cloud Run) e não
    tem mais acesso direto à porta USB da impressora.
    """
    forma_txt = venda.forma_pagamento.value.replace("_", " ").title()
    if venda.forma_pagamento.value == "cartao_credito" and venda.numero_parcelas > 1:
        forma_txt += f" - {venda.numero_parcelas}x"

    linhas_itens_html = "".join(
        f"""<div class="item">
              <div>{item['nome']}</div>
              <div class="linha-preco"><span>{item['quantidade']}x R$ {item['preco_unitario_venda']:.2f}</span>
              <span>R$ {item['preco_unitario_venda'] * item['quantidade']:.2f}</span></div>
            </div>"""
        for item in itens_detalhados
    )

    aviso_taxa = ""
    if venda.taxa_valor > 0 and venda.taxa_assumida_por.value == "cliente":
        aviso_taxa = f'<div class="linha-preco"><span>(inclui taxa)</span><span>R$ {venda.taxa_valor:.2f}</span></div>'

    aviso_frete = ""
    if venda.valor_frete_aplicado > 0:
        if venda.frete_assumido_por and venda.frete_assumido_por.value == "cliente":
            aviso_frete = f'<div class="linha-preco"><span>Entrega</span><span>R$ {venda.valor_frete_aplicado:.2f}</span></div>'
        else:
            aviso_frete = '<div class="linha-preco"><span>Entrega</span><span>Grátis</span></div>'

    cliente_html = f"<div>Cliente: {cliente_nome}</div>" if cliente_nome else ""

    return f"""<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Comprovante Venda #{venda.id}</title>
<style>
  @page {{ size: 80mm auto; margin: 0; }}
  body {{
    width: 76mm; margin: 0 auto; padding: 4mm;
    font-family: 'Courier New', monospace; font-size: 12px; color: #000;
  }}
  .centro {{ text-align: center; }}
  .titulo {{ font-size: 16px; font-weight: bold; }}
  hr {{ border: none; border-top: 1px dashed #000; margin: 6px 0; }}
  .linha-preco {{ display: flex; justify-content: space-between; }}
  .item {{ margin-bottom: 4px; }}
  .total {{ font-size: 15px; font-weight: bold; text-align: right; margin-top: 4px; }}
  .rodape {{ text-align: center; margin-top: 10px; font-size: 11px; }}
</style>
</head>
<body onload="window.print()">
  <div class="centro titulo">ROYAL CASES</div>
  <div class="centro">Capas e acessorios para celular</div>
  <hr>
  <div>Data: {venda.data_hora.strftime('%d/%m/%Y %H:%M')}</div>
  <div>Venda #{venda.id}</div>
  {cliente_html}
  <hr>
  {linhas_itens_html}
  <hr>
  <div class="total">TOTAL: R$ {venda.valor_cobrado_cliente:.2f}</div>
  <div class="linha-preco"><span>Pagamento:</span><span>{forma_txt}</span></div>
  {aviso_taxa}
  {aviso_frete}
  <div class="rodape">Obrigado pela preferência!<br>@royalcases</div>
</body>
</html>"""


def gerar_bytes_termica(venda, cliente_nome, itens_detalhados) -> bytes:
    """
    Gera os comandos ESC/POS prontos pra mandar pra impressora térmica USB.
    Usa o 'Dummy' printer do python-escpos, que só ACUMULA os comandos em
    memória (não precisa de impressora conectada) - perfeito pra testar aqui.

    Em produção (computador da loja), troca-se Dummy() por:
        from escpos.printer import Usb
        Usb(idVendor, idProduct)   # os IDs vêm de `lsusb` na impressora real
    e o resto do código continua idêntico.
    """
    p = Dummy()
    p.set(align="center", bold=True, width=2, height=2)
    p.text(f"{NOME_LOJA}\n")
    p.set(align="center", bold=False, width=1, height=1)
    p.text("Capas e acessorios para celular\n")
    p.text("-" * 32 + "\n")

    p.set(align="left")
    p.text(f"Data: {venda.data_hora.strftime('%d/%m/%Y %H:%M')}\n")
    p.text(f"Venda #{venda.id}\n")
    if cliente_nome:
        p.text(f"Cliente: {cliente_nome}\n")
    p.text("-" * 32 + "\n")

    for linha in _linhas_itens(venda, itens_detalhados):
        p.text(linha + "\n")

    p.text("-" * 32 + "\n")
    p.set(align="right", bold=True)
    p.text(f"TOTAL: R$ {venda.valor_cobrado_cliente:.2f}\n")
    p.set(align="center", bold=False)
    forma_txt = venda.forma_pagamento.value
    if venda.forma_pagamento.value == "cartao_credito" and venda.numero_parcelas > 1:
        forma_txt += f" - {venda.numero_parcelas}x"
    p.text(f"Pagamento: {forma_txt}\n")
    if venda.taxa_valor > 0 and venda.taxa_assumida_por.value == "cliente":
        p.text(f"(inclui taxa de R$ {venda.taxa_valor:.2f})\n")
    p.text("\nObrigado pela preferencia!\n")
    p.text("@royalcases\n\n\n")
    p.cut()

    return p.output


def gerar_pdf_comprovante(venda, cliente_nome, itens_detalhados) -> io.BytesIO:
    """
    Gera um PDF compacto (tamanho A6, como um recibo) pra enviar
    por WhatsApp ou e-mail.
    """
    buffer = io.BytesIO()
    largura, altura = A6
    c = canvas.Canvas(buffer, pagesize=A6)

    y = altura - 15 * mm
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(largura / 2, y, NOME_LOJA)
    y -= 6 * mm
    c.setFont("Helvetica", 8)
    c.drawCentredString(largura / 2, y, "Capas e acessorios para celular")
    y -= 8 * mm

    c.setFont("Helvetica", 9)
    c.drawString(10 * mm, y, f"Data: {venda.data_hora.strftime('%d/%m/%Y %H:%M')}")
    y -= 5 * mm
    c.drawString(10 * mm, y, f"Venda #{venda.id}")
    y -= 5 * mm
    if cliente_nome:
        c.drawString(10 * mm, y, f"Cliente: {cliente_nome}")
        y -= 5 * mm

    y -= 3 * mm
    c.line(10 * mm, y, largura - 10 * mm, y)
    y -= 6 * mm

    c.setFont("Helvetica", 8)
    for item in itens_detalhados:
        subtotal = item["preco_unitario_venda"] * item["quantidade"]
        c.drawString(10 * mm, y, f"{item['nome'][:28]}")
        y -= 4 * mm
        c.drawString(14 * mm, y, f"{item['quantidade']}x R$ {item['preco_unitario_venda']:.2f} = R$ {subtotal:.2f}")
        y -= 5 * mm

    y -= 2 * mm
    c.line(10 * mm, y, largura - 10 * mm, y)
    y -= 7 * mm

    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(largura - 10 * mm, y, f"TOTAL: R$ {venda.valor_cobrado_cliente:.2f}")
    y -= 6 * mm
    c.setFont("Helvetica", 8)
    forma_txt = venda.forma_pagamento.value
    if venda.forma_pagamento.value == "cartao_credito" and venda.numero_parcelas > 1:
        forma_txt += f" - {venda.numero_parcelas}x"
    c.drawRightString(largura - 10 * mm, y, f"Pagamento: {forma_txt}")
    if venda.taxa_valor > 0 and venda.taxa_assumida_por.value == "cliente":
        y -= 5 * mm
        c.drawRightString(largura - 10 * mm, y, f"(inclui taxa de R$ {venda.taxa_valor:.2f})")
    if venda.valor_frete_aplicado > 0:
        y -= 5 * mm
        if venda.frete_assumido_por and venda.frete_assumido_por.value == "cliente":
            c.drawRightString(largura - 10 * mm, y, f"Entrega: R$ {venda.valor_frete_aplicado:.2f}")
        else:
            c.drawRightString(largura - 10 * mm, y, "Entrega: Grátis")

    y -= 10 * mm
    c.setFont("Helvetica-Oblique", 8)
    c.drawCentredString(largura / 2, y, "Obrigado pela preferencia! @royalcases")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer

"""
Migração leve de banco de dados.

O `Base.metadata.create_all()` (usado no main.py) cria tabelas que ainda
NÃO existem, mas não adiciona coluna nova numa tabela que já existe - isso
importa porque o sistema já está em produção, com dados reais no Supabase.

Em vez de trazer uma ferramenta pesada (Alembic), essa função faz o mínimo
necessário: checa quais colunas já existem em cada tabela e adiciona só as
que faltam, de forma segu:
- Idempotente (rodar de novo não dá erro nem duplica nada)
- Funciona igual em SQLite (dev local) e Postgres (produção)
"""
import logging
from sqlalchemy import inspect, text

logger = logging.getLogger("royal_cases.migracoes")

# Cada entrada: (tabela, [(coluna, definição SQL), ...])
# Só colunas NOVAS entram aqui - colunas que já existiam desde o início do
# projeto não precisam (a tabela já nasceu com elas via create_all).
COLUNAS_NOVAS = {
    "usuarios": [
        # Adicionado na Fase 2 (recuperação de senha), mas só entrou aqui
        # agora - por isso o erro "column usuarios.email does not exist"
        # em produção. Corrigido.
        # SEM "UNIQUE" aqui de propósito: SQLite não permite adicionar
        # coluna UNIQUE via ALTER TABLE. A unicidade do e-mail já é
        # garantida no código da API (checagem manual antes de salvar).
        ("email", "VARCHAR(150)"),
    ],
    "produtos": [
        ("grupo_variacao", "VARCHAR(150)"),
        ("variacao", "VARCHAR(100)"),
        ("fornecedor_id", "INTEGER"),
        ("subcategoria", "VARCHAR(80)"),
        ("gtin_ean", "VARCHAR(20)"),
        ("condicao", "VARCHAR(20) DEFAULT 'NOVO'"),  # maiúsculo: SQLAlchemy guarda o NOME do enum, não o valor legível
        ("preco_promocional", "FLOAT"),
        ("peso_gramas", "FLOAT"),
        ("altura_cm", "FLOAT"),
        ("largura_cm", "FLOAT"),
        ("comprimento_cm", "FLOAT"),
    ],
    "clientes": [
        ("pontos_fidelidade", "INTEGER DEFAULT 0"),
    ],
    "vendas": [
        ("regiao_entrega_id", "INTEGER"),
        ("valor_frete_aplicado", "FLOAT DEFAULT 0.0"),  # DEFAULT aqui também retroage nas vendas já existentes
        ("frete_assumido_por", "VARCHAR(20)"),
        ("pontos_utilizados", "INTEGER DEFAULT 0"),
        ("desconto_pontos", "FLOAT DEFAULT 0.0"),
        ("pontos_ganhos", "INTEGER DEFAULT 0"),
    ],
}


def aplicar_migracoes_leves(engine):
    """Adiciona as colunas que faltam nas tabelas que já existem. Chame logo após o create_all()."""
    inspetor = inspect(engine)
    tabelas_existentes = set(inspetor.get_table_names())

    with engine.begin() as conexao:
        for tabela, colunas in COLUNAS_NOVAS.items():
            if tabela not in tabelas_existentes:
                continue  # tabela nova - já nasce com a coluna via create_all, nada a fazer aqui

            colunas_existentes = {c["name"] for c in inspetor.get_columns(tabela)}
            for nome_coluna, definicao_sql in colunas:
                if nome_coluna in colunas_existentes:
                    continue
                try:
                    conexao.execute(text(f"ALTER TABLE {tabela} ADD COLUMN {nome_coluna} {definicao_sql}"))
                    logger.info(f"Migração: adicionada coluna '{nome_coluna}' em '{tabela}'")
                except Exception as erro:
                    logger.warning(f"Migração falhou pra {tabela}.{nome_coluna}: {erro}")

    _rede_de_seguranca(engine)


def _rede_de_seguranca(engine):
    """
    Proteção extra: compara TODAS as colunas de cada modelo com o banco real
    e adiciona qualquer uma que esteja faltando E não estava na lista manual
    acima - isso existe porque já aconteceu de esquecer de atualizar a lista
    (o campo 'email' do usuário, na Fase 2, ficou faltando até quebrar em
    produção). Sempre adiciona como NULLABLE, mesmo que o modelo diga o
    contrário - é a opção seguindo que nunca falha num ALTER TABLE numa
    tabela que já tem linhas.
    """
    from app.models import Base

    inspetor = inspect(engine)
    tabelas_existentes = set(inspetor.get_table_names())

    with engine.begin() as conexao:
        for tabela in Base.metadata.tables.values():
            if tabela.name not in tabelas_existentes:
                continue
            colunas_existentes = {c["name"] for c in inspetor.get_columns(tabela.name)}
            for coluna in tabela.columns:
                if coluna.name in colunas_existentes:
                    continue
                try:
                    tipo_sql = coluna.type.compile(dialect=conexao.dialect)
                    conexao.execute(text(f"ALTER TABLE {tabela.name} ADD COLUMN {coluna.name} {tipo_sql}"))
                    logger.warning(
                        f"[Rede de segurança] '{coluna.name}' em '{tabela.name}' estava faltando e NÃO "
                        f"estava na lista manual (COLUNAS_NOVAS) - adicionada automaticamente como NULLABLE. "
                        f"Considere adicionar na lista manual pra ter controle explícito do tipo/default."
                    )
                except Exception as erro:
                    logger.error(f"[Rede de segurança] Falha ao adicionar {tabela.name}.{coluna.name}: {erro}")

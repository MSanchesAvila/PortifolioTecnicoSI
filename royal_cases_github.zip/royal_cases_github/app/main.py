"""
Arquivo principal do sistema Royal Cases.
Roda com: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""
import os
import secrets
from dotenv import load_dotenv

# Carrega o arquivo .env (se existir) ANTES de qualquer módulo que leia
# variáveis de ambiente (ex: app.auth_utils lê SECRET_KEY na importação).
load_dotenv()

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from app.database import engine, SessionLocal
from app.models import Base, Usuario, PerfilUsuario, ConfiguracaoTaxa, FormaPagamento
from app.auth_utils import hash_senha, SECRET_KEY
from app.backup_utils import fazer_backup
from app.migracoes import aplicar_migracoes_leves
from app.routers import produtos, clientes, vendas, dashboard, auth, sistema, pagamentos, fornecedores, comandas, regioes_entrega, fidelidade, etiquetas

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("royal_cases")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# "Versão" dos arquivos estáticos = hora que o sistema subiu. Toda vez que
# o sistema é reiniciado (ex: um novo deploy no Cloud Run), esse número muda
# sozinho - isso força o navegador a buscar o CSS/JS novo em vez de usar uma
# cópia antiga guardada em cache, sem precisar de Ctrl+Shift+R manual.
VERSAO_ESTATICA = str(int(time.time()))
templates.env.globals["v"] = VERSAO_ESTATICA

INTERVALO_BACKUP_HORAS = float(os.environ.get("BACKUP_INTERVALO_HORAS", "24"))

# Cria as tabelas no banco (se ainda não existirem) assim que o sistema sobe
Base.metadata.create_all(bind=engine)
aplicar_migracoes_leves(engine)


def _criar_gestor_inicial_se_necessario():
    """
    Primeiro acesso: se não existe NENHUM usuário no banco, cria um gestor
    padrão automaticamente - senão ninguém conseguiria logar pra criar
    os demais usuários (paradoxo do ovo e da galinha).

    IMPORTANTE: troque essa senha padrão assim que logar pela primeira vez.
    Se ROYAL_CASES_ADMIN_SENHA não for definida, o sistema GERA uma senha
    aleatória forte sozinho (nunca um valor fixo no código - isso seria uma
    senha "adivinhável" por qualquer um que veja o código-fonte do projeto).
    Se ROYAL_CASES_ADMIN_EMAIL não for definido, o gestor inicial fica SEM
    e-mail cadastrado - e portanto sem recuperação de senha por e-mail até
    que alguém defina um (ver .env.example).
    """
    db = SessionLocal()
    try:
        if db.scalar(select(Usuario)) is None:
            login_padrao = os.environ.get("ROYAL_CASES_ADMIN_LOGIN", "admin")
            senha_padrao = os.environ.get("ROYAL_CASES_ADMIN_SENHA") or secrets.token_urlsafe(12)
            email_padrao = os.environ.get("ROYAL_CASES_ADMIN_EMAIL") or None
            gestor = Usuario(
                nome="Administrador",
                login=login_padrao,
                email=email_padrao,
                senha_hash=hash_senha(senha_padrao),
                perfil=PerfilUsuario.GESTOR,
            )
            db.add(gestor)
            db.commit()
            print(f"⚠️  Usuário gestor inicial criado: login='{login_padrao}' senha='{senha_padrao}' - TROQUE DEPOIS!")
            if not email_padrao:
                print("⚠️  Gestor inicial SEM e-mail cadastrado - recuperação de senha não vai funcionar pra ele "
                      "até que um e-mail seja definido (ROYAL_CASES_ADMIN_EMAIL no .env, ou editando depois).")
    finally:
        db.close()


def _avisar_se_chave_insegura():
    """Alerta bem visível se estiver rodando com a chave de desenvolvimento (nunca use isso na loja de verdade)."""
    if SECRET_KEY == "chave-temporaria-trocar-em-producao":
        print("=" * 70)
        print("⚠️  ATENÇÃO: rodando com a SECRET_KEY padrão de desenvolvimento!")
        print("   Isso NÃO é seguro pra uso real - qualquer pessoa com esse valor")
        print("   poderia forjar um token de login. Veja o .env.example pra gerar")
        print("   uma chave própria antes de usar no computador da loja.")
        print("=" * 70)


def _criar_taxas_padrao_se_necessario():
    """
    Cria uma configuração inicial de taxas (editável a qualquer momento pelo
    gestor na tela de Pagamentos). São só valores de referência pra o sistema
    não começar zerado - ajuste pros valores reais da sua maquininha.
    """
    db = SessionLocal()
    try:
        if db.scalar(select(ConfiguracaoTaxa)) is None:
            taxas_iniciais = [
                (FormaPagamento.DINHEIRO, 1, 0.0),
                (FormaPagamento.PIX, 1, 0.0),
                (FormaPagamento.CARTAO_DEBITO, 1, 1.99),
                (FormaPagamento.CARTAO_CREDITO, 1, 3.5),
                (FormaPagamento.CARTAO_CREDITO, 2, 4.0),
                (FormaPagamento.CARTAO_CREDITO, 3, 4.5),
                (FormaPagamento.CARTAO_CREDITO, 4, 5.0),
                (FormaPagamento.CARTAO_CREDITO, 5, 5.5),
                (FormaPagamento.CARTAO_CREDITO, 6, 6.0),
                (FormaPagamento.CARTAO_CREDITO, 7, 7.0),
                (FormaPagamento.CARTAO_CREDITO, 8, 7.5),
                (FormaPagamento.CARTAO_CREDITO, 9, 8.0),
                (FormaPagamento.CARTAO_CREDITO, 10, 8.5),
                (FormaPagamento.CARTAO_CREDITO, 11, 9.0),
                (FormaPagamento.CARTAO_CREDITO, 12, 9.9),
            ]
            for forma, parcelas, taxa in taxas_iniciais:
                db.add(ConfiguracaoTaxa(forma_pagamento=forma, numero_parcelas=parcelas, taxa_percentual=taxa))
            db.commit()
            print("ℹ️  Taxas de pagamento padrão criadas - ajuste na tela de Pagamentos pros valores reais da sua maquininha.")
    finally:
        db.close()


_criar_gestor_inicial_se_necessario()
_criar_taxas_padrao_se_necessario()
_avisar_se_chave_insegura()


RODANDO_NO_CLOUD_RUN = bool(os.environ.get("K_SERVICE"))  # variável que o próprio Cloud Run define sozinho


async def _loop_backup_periodico():
    """Roda em segundo plano enquanto o sistema estiver ligado, sem precisar de agendador do sistema operacional."""
    while True:
        await asyncio.sleep(INTERVALO_BACKUP_HORAS * 3600)
        try:
            await asyncio.to_thread(fazer_backup)
        except Exception as erro:
            logger.warning(f"Backup periódico falhou: {erro}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    if RODANDO_NO_CLOUD_RUN:
        # No Cloud Run, a instância pode ser desligada a qualquer momento
        # quando ociosa - um loop em segundo plano não é confiável aqui.
        # Backup vira responsabilidade do gestor: usar GET /api/sistema/exportar-backup
        # periodicamente (a tela de Sistema pode automatizar o lembrete).
        logger.info(
            "Rodando no Cloud Run: backup automático em arquivo desativado. "
            "Use GET /api/sistema/exportar-backup periodicamente."
        )
    else:
        await asyncio.to_thread(fazer_backup)
        tarefa = asyncio.create_task(_loop_backup_periodico())
    yield
    if not RODANDO_NO_CLOUD_RUN:
        tarefa.cancel()


app = FastAPI(
    title="Royal Cases - Sistema de Estoque e Vendas",
    description="Sistema interno de gestão de estoque, vendas, clientes e faturamento",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(auth.router)
app.include_router(produtos.router)
app.include_router(clientes.router)
app.include_router(vendas.router)
app.include_router(dashboard.router)
app.include_router(sistema.router)
app.include_router(pagamentos.router)
app.include_router(fornecedores.router)
app.include_router(comandas.router)
app.include_router(regioes_entrega.router)
app.include_router(fidelidade.router)
app.include_router(etiquetas.router)

app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")


@app.get("/")
def raiz():
    return RedirectResponse(url="/login")


@app.get("/login")
def pagina_login(request: Request):
    return templates.TemplateResponse(request, "login.html")


@app.get("/redefinir-senha")
def pagina_redefinir_senha(request: Request):
    return templates.TemplateResponse(request, "redefinir-senha.html")


@app.get("/pdv")
def pagina_pdv(request: Request):
    return templates.TemplateResponse(request, "pdv.html")


@app.get("/vendas")
def pagina_vendas(request: Request):
    return templates.TemplateResponse(request, "vendas.html")


@app.get("/clientes")
def pagina_clientes(request: Request):
    return templates.TemplateResponse(request, "clientes.html")


@app.get("/produtos")
def pagina_produtos(request: Request):
    return templates.TemplateResponse(request, "produtos.html")


@app.get("/fornecedores")
def pagina_fornecedores(request: Request):
    return templates.TemplateResponse(request, "fornecedores.html")


@app.get("/pagamentos")
def pagina_pagamentos(request: Request):
    return templates.TemplateResponse(request, "pagamentos.html")


@app.get("/dashboard")
def pagina_dashboard(request: Request):
    return templates.TemplateResponse(request, "dashboard.html")

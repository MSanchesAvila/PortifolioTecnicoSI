"""
Dependências de autenticação/autorização.
No FastAPI, uma "Depends" é uma função que roda ANTES do endpoint,
e pode tanto fornecer um dado (ex: o usuário logado) quanto bloquear
a requisição (levantando um erro) se algo não estiver certo.
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import jwt

from app.auth_utils import decodificar_token
from app.database import get_db
from app.models import Usuario

security = HTTPBearer()


def usuario_logado(
    credenciais: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
) -> dict:
    """
    Extrai e valida o token enviado no cabeçalho 'Authorization: Bearer <token>'.
    Qualquer endpoint que exija login usa: Depends(usuario_logado)

    IMPORTANTE: também confere no banco se o usuário continua ATIVO -
    sem essa checagem, desativar um atendente só valeria depois do token
    dele expirar (até 12h), e ele continuaria conseguindo usar o sistema
    normalmente enquanto isso.
    """
    token = credenciais.credentials
    try:
        dados = decodificar_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sessão expirada, faça login novamente")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido")

    usuario_db = db.get(Usuario, int(dados["sub"]))
    if not usuario_db or not usuario_db.ativo:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário desativado ou não encontrado")

    # Guarda o objeto já buscado (chave com "_" pra deixar claro que é uso
    # interno, não um dado do token em si) - assim quem depender desse
    # usuário DEPOIS na mesma requisição (ex: exigir_permissao) reaproveita
    # em vez de buscar de novo no banco. Com o Supabase do outro lado do
    # mundo, cada ida-e-volta evitada é tempo real economizado.
    dados["_usuario_db"] = usuario_db

    return dados  # {"sub": id, "login": ..., "perfil": ..., "_usuario_db": Usuario}


def exigir_gestor(usuario: dict = Depends(usuario_logado)) -> dict:
    """
    Além de exigir login, exige que o perfil seja GESTOR.
    Reservado pra ações que só o gestor pode fazer mesmo com permissões
    concedidas (ex: definir as permissões de outros usuários).
    """
    if usuario["perfil"] != "gestor":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso restrito ao gestor"
        )
    return usuario


def exigir_permissao(permissao: str):
    """
    Fábrica de dependência: exigir_permissao("produtos.cadastrar") devolve uma
    função que verifica se o usuário logado pode fazer aquilo.

    IMPORTANTE: a checagem consulta o banco a cada requisição (não confia só
    no token) - assim, se o gestor revogar uma permissão, ela para de valer
    IMEDIATAMENTE, sem esperar o token expirar ou pedir novo login.
    """
    def dependencia(usuario: dict = Depends(usuario_logado), db: Session = Depends(get_db)) -> dict:
        if usuario["perfil"] == "gestor":
            return usuario  # gestor sempre pode tudo

        usuario_db = usuario.get("_usuario_db") or db.get(Usuario, int(usuario["sub"]))
        if not usuario_db or not usuario_db.tem_permissao(permissao):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Você não tem permissão para: {permissao}"
            )
        return usuario
    return dependencia

"""
Configurações do sistema - credenciais NUNCA ficam escritas direto no código,
sempre vêm de variáveis de ambiente (arquivo .env na loja).
Isso é uma prática básica de segurança: se esse código for parar em qualquer
lugar (ex: um backup, um pendrive), ninguém consegue ver a senha/token.
"""
import os

# --- WhatsApp (Z-API) - mesma integração já usada pela Bia ---
ZAPI_INSTANCE_ID = os.getenv("ZAPI_INSTANCE_ID", "")
ZAPI_TOKEN = os.getenv("ZAPI_TOKEN", "")
ZAPI_CLIENT_TOKEN = os.getenv("ZAPI_CLIENT_TOKEN", "")
ZAPI_BASE_URL = f"https://api.z-api.io/instances/{ZAPI_INSTANCE_ID}/token/{ZAPI_TOKEN}"

# --- E-mail (SMTP) ---
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_SENHA_APP = os.getenv("SMTP_SENHA_APP", "")  # senha de app, não a senha normal do Gmail

# --- URL base do sistema (usada pra montar o link de redefinição de senha no e-mail) ---
BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")

"""
Conexão com o banco de dados.

- Se a variável de ambiente DATABASE_URL estiver definida (ex: apontando
  pro Supabase), o sistema usa Postgres - é o caso do Cloud Run, onde o
  container não tem disco persistente.
- Se não estiver definida, cai pra SQLite local - útil pra desenvolvimento
  na sua máquina, sem precisar de internet/Supabase pra testar.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    f"sqlite:///{os.path.join(BASE_DIR, 'royal_cases.db')}",
)

if DATABASE_URL.startswith("sqlite"):
    # check_same_thread=False é necessário pro SQLite funcionar com FastAPI
    # (que pode atender múltiplas requisições - PCs e celulares - ao mesmo tempo)
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    # Postgres (Supabase): pool_pre_ping evita erro de "conexão caiu" depois
    # de o banco ficar ocioso um tempo (comum em plano gratuito)
    engine = create_engine(DATABASE_URL, pool_pre_ping=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """Fornece uma sessão de banco por requisição, e fecha ao final."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

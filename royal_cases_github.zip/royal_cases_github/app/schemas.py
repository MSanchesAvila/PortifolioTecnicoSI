"""
Schemas (Pydantic) - são os "portões" de validação de entrada e saída da API.
Diferente do models.py (que é como o dado é SALVO), aqui definimos como o
dado TRAFEGA - o que cada tipo de usuário pode enviar e o que recebe de volta.
"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


# ---------- PRODUTO ----------

class ProdutoCriar(BaseModel):
    """O que é necessário enviar para cadastrar um produto novo."""
    nome: str
    categoria: Optional[str] = None
    subcategoria: Optional[str] = None
    gtin_ean: Optional[str] = Field(default=None, description="Código de barras original do fabricante (se houver)")
    condicao: str = Field(default="novo", description="'novo', 'usado' ou 'seminovo'")
    preco_custo: float = Field(ge=0, description="Não pode ser negativo")
    preco_venda: float = Field(ge=0, description="Não pode ser negativo")
    preco_promocional: Optional[float] = Field(default=None, ge=0, description="Preço 'de/por' - deixe vazio se não tiver promoção")
    quantidade_estoque: int = Field(ge=0, description="Obrigatório - quantidade inicial em estoque")
    estoque_minimo: int = Field(default=3, ge=0)
    peso_gramas: Optional[float] = Field(default=None, ge=0)
    altura_cm: Optional[float] = Field(default=None, ge=0)
    largura_cm: Optional[float] = Field(default=None, ge=0)
    comprimento_cm: Optional[float] = Field(default=None, ge=0)
    fornecedor: Optional[str] = None  # texto livre - mantido por compatibilidade
    fornecedor_id: Optional[int] = None  # novo: fornecedor como entidade cadastrada
    grupo_variacao: Optional[str] = Field(default=None, description="Ex: 'Case Aurora' - agrupa variações do mesmo produto")
    variacao: Optional[str] = Field(default=None, description="Ex: 'Azul - M'")
    # codigo_barras NÃO entra aqui de propósito - o sistema é quem gera, não o usuário


class ProdutoRespostaGestor(BaseModel):
    """O que o GESTOR vê: inclui custo e margem."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    categoria: Optional[str]
    subcategoria: Optional[str] = None
    codigo_barras: str
    gtin_ean: Optional[str] = None
    condicao: str = "novo"
    preco_custo: float
    preco_venda: float
    preco_promocional: Optional[float] = None
    quantidade_estoque: int
    estoque_minimo: int
    peso_gramas: Optional[float] = None
    altura_cm: Optional[float] = None
    largura_cm: Optional[float] = None
    comprimento_cm: Optional[float] = None
    fornecedor: Optional[str]
    fornecedor_id: Optional[int] = None
    grupo_variacao: Optional[str] = None
    variacao: Optional[str] = None
    ativo: bool


class ProdutoRespostaAtendente(BaseModel):
    """O que o ATENDENTE vê: sem custo, sem margem - só o necessário pra vender."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    categoria: Optional[str]
    subcategoria: Optional[str] = None
    codigo_barras: str
    gtin_ean: Optional[str] = None
    condicao: str = "novo"
    preco_venda: float
    preco_promocional: Optional[float] = None
    quantidade_estoque: int
    grupo_variacao: Optional[str] = None
    variacao: Optional[str] = None


class ProdutoEditar(BaseModel):
    """Edição de dados do produto (NÃO inclui estoque - isso passa pelo endpoint de ajuste, que registra o motivo)."""
    nome: Optional[str] = None
    categoria: Optional[str] = None
    subcategoria: Optional[str] = None
    gtin_ean: Optional[str] = None
    condicao: Optional[str] = None
    preco_custo: Optional[float] = Field(default=None, ge=0)
    preco_venda: Optional[float] = Field(default=None, ge=0)
    preco_promocional: Optional[float] = Field(default=None, ge=0)
    estoque_minimo: Optional[int] = Field(default=None, ge=0)
    peso_gramas: Optional[float] = Field(default=None, ge=0)
    altura_cm: Optional[float] = Field(default=None, ge=0)
    largura_cm: Optional[float] = Field(default=None, ge=0)
    comprimento_cm: Optional[float] = Field(default=None, ge=0)
    fornecedor: Optional[str] = None
    fornecedor_id: Optional[int] = None
    grupo_variacao: Optional[str] = None
    variacao: Optional[str] = None
    ativo: Optional[bool] = None


class FornecedorCriar(BaseModel):
    nome: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    cnpj: Optional[str] = None
    observacoes: Optional[str] = None


class FornecedorResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    telefone: Optional[str]
    email: Optional[str]
    cnpj: Optional[str]
    observacoes: Optional[str]
    criado_em: datetime


class AjusteEstoque(BaseModel):
    """Ajuste manual de estoque - sempre com motivo, pra manter rastreável."""
    quantidade_delta: int = Field(description="Positivo pra adicionar (ex: chegou mercadoria), negativo pra remover (ex: perda/avaria)")
    motivo: str = Field(min_length=3, description="Ex: 'Contagem física', 'Produto danificado', 'Reposição do fornecedor'")


# ---------- CLIENTE ----------

class ClienteCriar(BaseModel):
    """Dados necessários para cadastrar um cliente novo."""
    nome: str
    telefone: Optional[str] = None
    email: Optional[str] = None
    cpf: Optional[str] = None


class ClienteResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    telefone: Optional[str]
    email: Optional[str]
    cpf: Optional[str]
    pontos_fidelidade: int = 0
    criado_em: datetime


class ClienteEditar(BaseModel):
    """Edição de dados de cliente - todos os campos opcionais (só manda o que quer mudar)."""
    nome: Optional[str] = None
    telefone: Optional[str] = None
    email: Optional[str] = None
    cpf: Optional[str] = None


# ---------- AUTENTICAÇÃO ----------

class LoginRequest(BaseModel):
    login: str
    senha: str


class TokenResposta(BaseModel):
    access_token: str
    token_type: str = "bearer"
    perfil: str
    nome: str


class UsuarioCriar(BaseModel):
    """Só o gestor pode criar novos usuários (atendentes). E-mail é obrigatório - é o que permite recuperação de senha."""
    nome: str
    login: str
    email: str = Field(description="Obrigatório - usado pra recuperação de senha")
    senha: str
    perfil: str = "atendente"


class UsuarioResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    login: str
    email: Optional[str] = None
    perfil: str
    ativo: bool
    permissoes_extra: list[str] = []


class PermissoesAtualizar(BaseModel):
    """Lista completa de permissões que o usuário deve ter (substitui a anterior)."""
    permissoes: list[str]


class SenhaAtualizar(BaseModel):
    senha_atual: str
    senha_nova: str


class EsqueciSenhaRequest(BaseModel):
    email: str


class RedefinirSenhaRequest(BaseModel):
    token: str
    senha_nova: str = Field(min_length=6)


class MeuPerfilEditar(BaseModel):
    """Edição dos próprios dados (nome/e-mail) - qualquer usuário logado edita o próprio."""
    nome: Optional[str] = None
    email: Optional[str] = None


# ---------- TAXAS DE PAGAMENTO ----------

class ConfiguracaoTaxaItem(BaseModel):
    forma_pagamento: str
    numero_parcelas: int = 1
    taxa_percentual: float


class ConfiguracaoTaxaResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    forma_pagamento: str
    numero_parcelas: int
    taxa_percentual: float


class ConfiguracaoTaxaAtualizar(BaseModel):
    """Lista completa de taxas configuradas (substitui as anteriores)."""
    taxas: list[ConfiguracaoTaxaItem]


# ---------- REGIÕES DE ENTREGA (frete) ----------

class RegiaoEntregaCriar(BaseModel):
    nome: str
    valor_frete: float = Field(ge=0)


class RegiaoEntregaResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    valor_frete: float
    ativo: bool


# ---------- FIDELIDADE ----------

class ConfiguracaoFidelidadeEditar(BaseModel):
    pontos_por_real: float = Field(ge=0)
    valor_resgate_por_ponto: float = Field(ge=0)
    ativo: bool = True


class ConfiguracaoFidelidadeResposta(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    pontos_por_real: float
    valor_resgate_por_ponto: float
    ativo: bool


# ---------- VENDA ----------

class ItemVendaCriar(BaseModel):
    """Um item dentro do carrinho de uma venda."""
    produto_id: int
    quantidade: int = Field(default=1, gt=0, description="Precisa ser maior que zero")


class VendaCriar(BaseModel):
    """O que é necessário para registrar uma venda completa.
    Note que NÃO existe usuario_id aqui - quem fez a venda é sempre
    identificado pelo token de login, nunca por um campo que o cliente
    da requisição poderia manipular.

    A TAXA em si nunca é enviada aqui - o servidor busca a taxa configurada
    (por forma de pagamento + parcelas) e calcula sozinho. O cliente da
    requisição só escolhe a forma de pagamento, quantas parcelas, e quem
    assume a taxa - nunca o valor da taxa."""
    cliente_id: Optional[int] = None
    canal: str = "presencial"
    forma_pagamento: str
    numero_parcelas: int = Field(default=1, ge=1, le=12)
    taxa_assumida_por: str = "loja"
    regiao_entrega_id: Optional[int] = None
    frete_assumido_por: Optional[str] = None  # "cliente" ou "loja" - só relevante se regiao_entrega_id for informado
    valor_frete_manual: Optional[float] = Field(
        default=None, ge=0, le=100,
        description="Se informado, sobrescreve o valor padrão da região (teto de R$100 por segurança, evita erro de digitação)"
    )
    pontos_utilizados: int = Field(default=0, ge=0, description="Pontos de fidelidade que o cliente quer resgatar nessa compra")
    itens: list[ItemVendaCriar]


class ItemVendaRespostaAtendente(BaseModel):
    """Item de venda SEM custo/lucro - visão do atendente."""
    model_config = ConfigDict(from_attributes=True)

    produto_id: int
    quantidade: int
    preco_unitario_venda: float


class ItemVendaRespostaGestor(BaseModel):
    """Item de venda COM custo/lucro - visão do gestor."""
    model_config = ConfigDict(from_attributes=True)

    produto_id: int
    quantidade: int
    preco_unitario_venda: float
    preco_unitario_custo: float


class VendaRespostaAtendente(BaseModel):
    """O que o atendente vê após fechar uma venda: sem custo, sem lucro.
    Mas COM o valor a cobrar do cliente e a taxa aplicada - o atendente
    precisa saber quanto cobrar na maquininha."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    cliente_id: Optional[int]
    canal: str
    forma_pagamento: str
    numero_parcelas: int
    taxa_percentual_aplicada: float
    taxa_valor: float
    taxa_assumida_por: str
    valor_cobrado_cliente: float
    valor_total: float
    regiao_entrega_id: Optional[int] = None
    valor_frete_aplicado: float = 0.0
    frete_assumido_por: Optional[str] = None
    pontos_utilizados: int = 0
    desconto_pontos: float = 0.0
    pontos_ganhos: int = 0
    data_hora: datetime
    itens: list[ItemVendaRespostaAtendente]
    alertas_estoque_baixo: list[str] = []


class VendaRespostaGestor(BaseModel):
    """O que o gestor vê: inclui custo total, lucro total e detalhes da taxa."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    cliente_id: Optional[int]
    canal: str
    forma_pagamento: str
    numero_parcelas: int
    taxa_percentual_aplicada: float
    taxa_valor: float
    taxa_assumida_por: str
    valor_cobrado_cliente: float
    valor_recebido_loja: float
    valor_total: float
    custo_total: float
    lucro_total: float
    regiao_entrega_id: Optional[int] = None
    valor_frete_aplicado: float = 0.0
    frete_assumido_por: Optional[str] = None
    pontos_utilizados: int = 0
    desconto_pontos: float = 0.0
    pontos_ganhos: int = 0
    data_hora: datetime
    itens: list[ItemVendaRespostaGestor]
    alertas_estoque_baixo: list[str] = []


# ---------- DASHBOARD / FATURAMENTO E LUCRO ----------

class ResumoFaturamento(BaseModel):
    periodo_inicio: datetime
    periodo_fim: datetime
    faturamento_total: float
    custo_total: float
    lucro_total: float
    margem_percentual: float
    quantidade_vendas: int


class DesempenhoProduto(BaseModel):
    produto_id: int
    nome: str
    quantidade_vendida: int
    faturamento: float
    lucro: float
    margem_percentual: float


# ---------- COMANDA (venda pausada) ----------

class ItemComandaCriar(BaseModel):
    produto_id: int
    quantidade: int = Field(gt=0)


class ComandaCriar(BaseModel):
    identificador: str = Field(min_length=1, description="Ex: 'Mesa 3', 'Cliente João'")
    cliente_id: Optional[int] = None
    itens: list[ItemComandaCriar]


class ComandaResposta(BaseModel):
    id: int
    identificador: str
    cliente_id: Optional[int]
    cliente_nome: Optional[str] = None
    usuario_nome: str
    quantidade_itens: int
    criada_em: datetime


class ItemComandaDetalhe(BaseModel):
    produto_id: int
    nome: str
    preco_venda: float
    quantidade: int
    quantidade_estoque: int


class ComandaDetalhe(BaseModel):
    id: int
    identificador: str
    cliente_id: Optional[int]
    cliente_nome: Optional[str] = None
    itens: list[ItemComandaDetalhe]

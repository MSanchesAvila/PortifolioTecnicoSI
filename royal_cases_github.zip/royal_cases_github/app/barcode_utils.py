"""
Utilitário de código de barras e etiquetas.
- Gera um código único interno (não depende de nenhum órgão externo).
- Gera a imagem (PNG) da etiqueta individual, e a folha inteira em lote
  (formato Pimaco A4251 - 38,2 x 21,2mm, 5 colunas x 13 linhas, 65/folha)
  pra imprimir em papel adesivo.

Design validado com teste físico de impressão/leitura em 21/07/2026:
"ROYAL CASES" fixo no topo, 2 primeiras palavras do produto, código de
barras (com zona de silêncio de 2,5mm - abaixo disso arrisca falha de
leitura), número do código desenhado à parte (nunca sobrepõe a barra),
preço com espaçamento generoso depois do número.
"""
import io
import uuid
from datetime import datetime

import barcode
from barcode.writer import ImageWriter
from PIL import Image, ImageDraw, ImageFont

DPI = 300

# Medidas físicas da etiqueta Pimaco A4251 (mm) - config "de fábrica"
ETIQUETA_LARGURA_MM = 38.2
ETIQUETA_ALTURA_MM = 21.2

_CAMINHOS_FONTE_NEGRITO = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]
_CAMINHOS_FONTE_NORMAL = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


def _mm_para_px(mm: float, dpi: int = DPI) -> int:
    return int(mm / 25.4 * dpi)


def _carregar_fonte(tamanho: int, negrito: bool = True) -> ImageFont.FreeTypeFont:
    caminhos = _CAMINHOS_FONTE_NEGRITO if negrito else _CAMINHOS_FONTE_NORMAL
    for caminho in caminhos:
        try:
            return ImageFont.truetype(caminho, tamanho)
        except (OSError, IOError):
            continue
    return ImageFont.load_default()


def gerar_codigo_unico() -> str:
    """
    Gera um código interno único, ex: RC241014A3F9
    RC = Royal Cases | 241014 = data (ano-mes-dia) | A3F9 = sufixo aleatório
    """
    prefixo = "RC"
    data = datetime.now().strftime("%y%m%d")
    sufixo = uuid.uuid4().hex[:4].upper()
    return f"{prefixo}{data}{sufixo}"


def _desenhar_etiqueta(
    codigo: str, nome: str, preco_venda: float,
    largura_px: int, altura_px: int, dpi: int = DPI,
) -> Image.Image:
    """Desenha UMA etiqueta (Royal Cases + nome + código + preço) no tamanho exato em pixels informado."""
    primeiras_palavras = " ".join(nome.split()[:2]) if nome else ""

    code128 = barcode.get_barcode_class("code128")
    buf = io.BytesIO()
    code128(codigo, writer=ImageWriter()).write(buf, options={
        "module_width": 0.22, "module_height": 7.5,
        "quiet_zone": 2.5,  # nunca reduzir abaixo disso - risco real de falha de leitura, já testado
        "write_text": False,  # o número é desenhado por nós, com espaçamento garantido (ver abaixo)
        "dpi": dpi,
    })
    buf.seek(0)
    barra = Image.open(buf).convert("RGB")
    if barra.width > largura_px - 6:
        nova_largura = largura_px - 6
        barra = barra.resize((nova_largura, int(barra.height * nova_largura / barra.width)))

    etiqueta = Image.new("RGB", (largura_px, altura_px), "white")
    draw = ImageDraw.Draw(etiqueta)

    # "ROYAL CASES" fixo, centralizado
    fonte_loja = _carregar_fonte(int(altura_px * 0.11))
    texto_loja = "ROYAL CASES"
    caixa_loja = draw.textbbox((0, 0), texto_loja, font=fonte_loja)
    draw.text((max(0, (largura_px - (caixa_loja[2]-caixa_loja[0])) // 2), 1), texto_loja, fill="black", font=fonte_loja)
    y = caixa_loja[3] + 1

    # Nome do produto (2 primeiras palavras), à esquerda
    if primeiras_palavras:
        fonte_produto = _carregar_fonte(int(altura_px * 0.09))
        draw.text((3, y), primeiras_palavras, fill="black", font=fonte_produto)
        y += fonte_produto.getbbox(primeiras_palavras)[3] + 2

    # Código de barras
    x_barra = max(0, (largura_px - barra.width) // 2)
    etiqueta.paste(barra, (x_barra, y))
    y += barra.height + 2

    # Número do código - desenhado à parte, NUNCA encosta na barra (causa raiz do bug já corrigido)
    fonte_codigo = _carregar_fonte(int(altura_px * 0.12))
    caixa_codigo = draw.textbbox((0, 0), codigo, font=fonte_codigo)
    draw.text((max(0, (largura_px - (caixa_codigo[2]-caixa_codigo[0])) // 2), y), codigo, fill="black", font=fonte_codigo)
    y += (caixa_codigo[3] - caixa_codigo[1]) + 10  # espaço generoso antes do preço

    # Preço
    fonte_preco = _carregar_fonte(int(altura_px * 0.13))
    texto_preco = f"R$ {preco_venda:.2f}".replace(".", ",")
    caixa_preco = draw.textbbox((0, 0), texto_preco, font=fonte_preco)
    draw.text((max(0, (largura_px - (caixa_preco[2]-caixa_preco[0])) // 2), y), texto_preco, fill="black", font=fonte_preco)

    return etiqueta


def gerar_imagem_codigo_barras(codigo: str, nome: str = None, preco_venda: float = None) -> io.BytesIO:
    """
    Gera a imagem PNG de UMA etiqueta, no tamanho físico exato da Pimaco
    A4251 (38,2 x 21,2mm a 300dpi). Se nome/preço não forem passados, gera
    só o código de barras cru (compatibilidade com quem só quer isso).
    """
    if not nome and preco_venda is None:
        code128 = barcode.get_barcode_class("code128")
        buffer = io.BytesIO()
        code128(codigo, writer=ImageWriter()).write(buffer, options={"quiet_zone": 2.5})
        buffer.seek(0)
        return buffer

    largura_px = _mm_para_px(ETIQUETA_LARGURA_MM)
    altura_px = _mm_para_px(ETIQUETA_ALTURA_MM)
    etiqueta = _desenhar_etiqueta(codigo, nome or "", preco_venda or 0.0, largura_px, altura_px)

    buffer_final = io.BytesIO()
    etiqueta.save(buffer_final, format="PNG", dpi=(DPI, DPI))
    buffer_final.seek(0)
    return buffer_final


# --- Folha A4 (210 x 297mm) - impressão em lote ---
A4_LARGURA_MM = 210.0
A4_ALTURA_MM = 297.0

# Configuração "de fábrica" da Pimaco A4251: 5 colunas x 13 linhas = 65/folha.
# Margem calculada matematicamente (sobra dividida igualmente) - se a
# primeira impressão física sair alguns mm deslocada, ajuste aqui.
CONFIG_PADRAO_FOLHA = {
    "colunas": 5,
    "linhas": 13,
    "margem_superior_mm": round((A4_ALTURA_MM - 13 * ETIQUETA_ALTURA_MM) / 2, 2),
    "margem_esquerda_mm": round((A4_LARGURA_MM - 5 * ETIQUETA_LARGURA_MM) / 2, 2),
    "espaco_horizontal_mm": 0.0,
    "espaco_vertical_mm": 0.0,
}


def gerar_folhas_etiquetas(itens: list[dict], config: dict = None) -> list[Image.Image]:
    """
    Gera uma ou mais folhas A4 (uma imagem PIL por folha) com as etiquetas
    posicionadas na grade da Pimaco A4251, prontas pra imprimir em
    "tamanho real" (sem ajustar à página).

    itens: [{"codigo": str, "nome": str, "preco_venda": float, "quantidade": int}, ...]
    config: dict com colunas/linhas/margens em mm - usa CONFIG_PADRAO_FOLHA se não informado.
    """
    cfg = {**CONFIG_PADRAO_FOLHA, **(config or {})}
    colunas, linhas = cfg["colunas"], cfg["linhas"]
    por_folha = colunas * linhas

    # Expande a lista repetindo cada produto conforme a quantidade pedida
    fila = []
    for item in itens:
        fila.extend([item] * max(1, item.get("quantidade", 1)))

    largura_px = _mm_para_px(ETIQUETA_LARGURA_MM)
    altura_px = _mm_para_px(ETIQUETA_ALTURA_MM)
    margem_sup_px = _mm_para_px(cfg["margem_superior_mm"])
    margem_esq_px = _mm_para_px(cfg["margem_esquerda_mm"])
    espaco_h_px = _mm_para_px(cfg["espaco_horizontal_mm"])
    espaco_v_px = _mm_para_px(cfg["espaco_vertical_mm"])
    pagina_largura_px = _mm_para_px(A4_LARGURA_MM)
    pagina_altura_px = _mm_para_px(A4_ALTURA_MM)

    folhas = []
    for inicio in range(0, len(fila), por_folha):
        pagina = Image.new("RGB", (pagina_largura_px, pagina_altura_px), "white")
        lote = fila[inicio:inicio + por_folha]
        for i, item in enumerate(lote):
            col = i % colunas
            lin = i // colunas
            x = margem_esq_px + col * (largura_px + espaco_h_px)
            y = margem_sup_px + lin * (altura_px + espaco_v_px)
            etiqueta = _desenhar_etiqueta(item["codigo"], item.get("nome", ""), item.get("preco_venda", 0.0), largura_px, altura_px)
            pagina.paste(etiqueta, (x, y))
        folhas.append(pagina)

    return folhas

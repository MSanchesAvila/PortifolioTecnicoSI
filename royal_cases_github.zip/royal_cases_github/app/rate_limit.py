"""
Limitador de tentativas de login, em memória (sem dependência externa).

LIMITAÇÃO CONHECIDA: como é em memória, só funciona por instância do
Cloud Run - se o sistema escalar pra mais de uma instância, um atacante
pode "driblar" o limite distribuindo tentativas entre elas. Pra uma loja
pequena com baixo tráfego, isso raramente acontece na prática (Cloud Run
só cria mais instâncias sob carga alta), mas é uma limitação real a saber.
Se um dia isso virar problema de verdade, a solução correta é mover esse
controle pra um Redis compartilhado entre instâncias.
"""
import time

MAX_TENTATIVAS = 5
JANELA_SEGUNDOS = 300  # 5 minutos

_tentativas: dict[str, list[float]] = {}


def registrar_tentativa_falha(chave: str) -> None:
    """Registra uma tentativa de login que falhou, associada a um IP (ou login)."""
    agora = time.time()
    lista = _tentativas.setdefault(chave, [])
    lista.append(agora)
    # Limpa tentativas antigas (fora da janela) pra não crescer pra sempre
    _tentativas[chave] = [t for t in lista if agora - t < JANELA_SEGUNDOS]


def limite_excedido(chave: str) -> bool:
    """True se essa chave (IP) já tentou demais na janela recente."""
    agora = time.time()
    lista = _tentativas.get(chave, [])
    tentativas_recentes = [t for t in lista if agora - t < JANELA_SEGUNDOS]
    return len(tentativas_recentes) >= MAX_TENTATIVAS


def limpar_tentativas(chave: str) -> None:
    """Chamado após um login bem-sucedido, pra resetar o contador dessa chave."""
    _tentativas.pop(chave, None)

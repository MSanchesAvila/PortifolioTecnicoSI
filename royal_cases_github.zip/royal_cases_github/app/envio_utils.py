"""
Envio do comprovante digital (RF10).
Duas opções: WhatsApp (via Z-API, reaproveitando a mesma integração da Bia)
ou e-mail (via SMTP, ex: Gmail com senha de app).

IMPORTANTE: estas funções fazem chamadas de rede reais. Para testá-las de
verdade é necessário rodar no ambiente da loja com as credenciais configuradas
em variáveis de ambiente (ver app/config.py) - aqui no ambiente de
desenvolvimento elas não são executadas contra a internet real.
"""
import base64
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText

import httpx

from app.config import (
    ZAPI_INSTANCE_ID, ZAPI_TOKEN, ZAPI_BASE_URL, ZAPI_CLIENT_TOKEN,
    SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_SENHA_APP,
)


def enviar_comprovante_whatsapp(telefone: str, pdf_bytes: bytes, nome_arquivo: str, venda_id: int) -> dict:
    """
    Envia o PDF do comprovante por WhatsApp via Z-API.
    telefone deve estar no formato: 5511999998888 (código do país + DDD + número)
    """
    if not ZAPI_INSTANCE_ID or not ZAPI_TOKEN:
        raise RuntimeError(
            "Z-API não configurado. Defina ZAPI_INSTANCE_ID, ZAPI_TOKEN e "
            "ZAPI_CLIENT_TOKEN como variáveis de ambiente no computador da loja."
        )

    documento_base64 = base64.b64encode(pdf_bytes).decode("utf-8")

    payload = {
        "phone": telefone,
        "document": f"data:application/pdf;base64,{documento_base64}",
        "fileName": nome_arquivo,
        "caption": f"Aqui está seu comprovante da compra na Royal Cases (Venda #{venda_id}). Obrigado! 🙏",
    }
    headers = {"Client-Token": ZAPI_CLIENT_TOKEN} if ZAPI_CLIENT_TOKEN else {}

    with httpx.Client(timeout=15) as client:
        resposta = client.post(f"{ZAPI_BASE_URL}/send-document/pdf", json=payload, headers=headers)
        resposta.raise_for_status()
        return resposta.json()


def enviar_comprovante_email(destinatario: str, pdf_bytes: bytes, nome_arquivo: str, venda_id: int) -> None:
    """Envia o PDF do comprovante por e-mail via SMTP (ex: Gmail)."""
    if not SMTP_USER or not SMTP_SENHA_APP:
        raise RuntimeError(
            "E-mail não configurado. Defina SMTP_USER e SMTP_SENHA_APP como "
            "variáveis de ambiente no computador da loja (use senha de app do Gmail, não a senha normal)."
        )

    msg = MIMEMultipart()
    msg["From"] = SMTP_USER
    msg["To"] = destinatario
    msg["Subject"] = f"Royal Cases - Comprovante da sua compra (Venda #{venda_id})"
    msg.attach(MIMEText(
        "Olá! Segue em anexo o comprovante da sua compra na Royal Cases. "
        "Obrigado pela preferência!", "plain"
    ))

    anexo = MIMEApplication(pdf_bytes, _subtype="pdf")
    anexo.add_header("Content-Disposition", "attachment", filename=nome_arquivo)
    msg.attach(anexo)

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as servidor:
        servidor.starttls()
        servidor.login(SMTP_USER, SMTP_SENHA_APP)
        servidor.send_message(msg)


def enviar_email_redefinicao_senha(destinatario: str, link_redefinicao: str) -> None:
    """
    Envia o e-mail com o link de "esqueci minha senha".
    Levanta RuntimeError se o SMTP não estiver configurado - quem chama essa
    função já deve tratar isso sem revelar ao usuário final se o e-mail
    existe ou não no sistema (ver rota /api/auth/esqueci-senha).
    """
    if not SMTP_USER or not SMTP_SENHA_APP:
        raise RuntimeError("E-mail não configurado (SMTP_USER / SMTP_SENHA_APP ausentes).")

    msg = MIMEMultipart()
    msg["From"] = SMTP_USER
    msg["To"] = destinatario
    msg["Subject"] = "Royal Cases - Redefinição de senha"
    msg.attach(MIMEText(
        "Olá!\n\n"
        "Recebemos um pedido pra redefinir sua senha no sistema Royal Cases.\n\n"
        f"Clique no link abaixo pra escolher uma senha nova (válido por 30 minutos):\n{link_redefinicao}\n\n"
        "Se você não pediu isso, pode ignorar este e-mail com segurança - "
        "sua senha continua a mesma.",
        "plain"
    ))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as servidor:
        servidor.starttls()
        servidor.login(SMTP_USER, SMTP_SENHA_APP)
        servidor.send_message(msg)

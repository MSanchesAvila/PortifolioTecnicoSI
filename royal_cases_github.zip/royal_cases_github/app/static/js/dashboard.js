/* Lógica da tela de Dashboard - restrita a quem tem a permissão 'dashboard.ver' */

exigirLogin();

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

async function inicializar() {
  const usuarioAtual = await obterUsuarioAtual();
  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    alert("Você não tem permissão para acessar o dashboard.");
    window.location.href = "/pdv";
    return;
  }
  if (getPerfil() !== "gestor") {
    document.getElementById("link-pagamentos").style.display = "none";
  }
  carregarTudo();
}

inicializar();

function formatarMoeda(valor) {
  return `R$ ${valor.toFixed(2)}`;
}

async function carregarFaturamento() {
  const inicio = document.getElementById("data-inicio").value;
  const fim = document.getElementById("data-fim").value;
  let url = "/api/dashboard/faturamento";
  const params = [];
  if (inicio) params.push(`inicio=${inicio}T00:00:00`);
  if (fim) params.push(`fim=${fim}T23:59:59`);
  if (params.length) url += `?${params.join("&")}`;

  const resposta = await apiFetch(url);
  const dados = await resposta.json();

  document.getElementById("cartoes-faturamento").innerHTML = `
    <div class="cartao"><div class="valor">${dados.quantidade_vendas}</div><div class="rotulo">Vendas</div></div>
    <div class="cartao"><div class="valor">${formatarMoeda(dados.faturamento)}</div><div class="rotulo">Faturamento</div></div>
    <div class="cartao"><div class="valor">${formatarMoeda(dados.custo)}</div><div class="rotulo">Custo</div></div>
    <div class="cartao"><div class="valor">${formatarMoeda(dados.lucro)}</div><div class="rotulo">Lucro</div></div>
    <div class="cartao"><div class="valor">${dados.margem_percentual}%</div><div class="rotulo">Margem</div></div>
  `;
}

/**
 * Gráfico de tendência - SVG puro desenhado à mão, sem biblioteca externa
 * (mantém o sistema leve). É um gráfico de barras simples: faturamento por
 * dia, últimos 7 dias.
 */
async function carregarGraficoTendencia() {
  const resposta = await apiFetch("/api/dashboard/tendencia?dias=7");
  const dados = await resposta.json();
  const area = document.getElementById("grafico-tendencia");

  const maiorValor = Math.max(...dados.map((d) => d.faturamento), 1);
  const larguraBarra = 60;
  const espaco = 20;
  const alturaMax = 140;
  const larguraSvg = dados.length * (larguraBarra + espaco);

  const corDourado = getComputedStyle(document.documentElement).getPropertyValue("--dourado").trim() || "#c9a24b";
  const corTexto = getComputedStyle(document.documentElement).getPropertyValue("--texto-secundario").trim() || "#999";

  const barras = dados.map((d, i) => {
    const altura = maiorValor > 0 ? Math.max((d.faturamento / maiorValor) * alturaMax, 2) : 2;
    const x = i * (larguraBarra + espaco);
    const y = alturaMax - altura;
    const diaLabel = new Date(d.data + "T12:00:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
    return `
      <g>
        <rect x="${x}" y="${y}" width="${larguraBarra}" height="${altura}" fill="${corDourado}" rx="4">
          <title>${diaLabel}: R$ ${d.faturamento.toFixed(2)}</title>
        </rect>
        <text x="${x + larguraBarra / 2}" y="${alturaMax + 18}" text-anchor="middle" font-size="11" fill="${corTexto}">${diaLabel}</text>
        <text x="${x + larguraBarra / 2}" y="${y - 6}" text-anchor="middle" font-size="10" fill="${corTexto}">R$${d.faturamento.toFixed(0)}</text>
      </g>
    `;
  }).join("");

  area.innerHTML = `
    <svg width="${larguraSvg}" height="${alturaMax + 35}" viewBox="0 0 ${larguraSvg} ${alturaMax + 35}">
      ${barras}
    </svg>
  `;
}

/** Fechamento de caixa - total por forma de pagamento, pra bater o caixa no fim do dia */
async function carregarFechamentoCaixa() {
  const dataInput = document.getElementById("data-fechamento");
  if (!dataInput.value) {
    const hoje = new Date();
    dataInput.value = hoje.toISOString().slice(0, 10);
  }
  const area = document.getElementById("area-fechamento-caixa");
  mostrarCarregando("area-fechamento-caixa");

  const resposta = await apiFetch(`/api/dashboard/fechamento-caixa?data=${dataInput.value}`);
  const dados = await resposta.json();

  const rotulos = {
    pix: "Pix", dinheiro: "Dinheiro", cartao_debito: "Cartão Débito", cartao_credito: "Cartão Crédito",
  };

  const linhasFormas = Object.entries(dados.por_forma_pagamento).map(([forma, info]) => `
    <tr>
      <td>${rotulos[forma] || forma}</td>
      <td>${info.quantidade}</td>
      <td>${formatarMoeda(info.total)}</td>
    </tr>
  `).join("") || `<tr><td colspan="3" style="color:#666;">Nenhuma venda nesse dia.</td></tr>`;

  area.innerHTML = `
    <div class="cartoes" style="margin-bottom:14px;">
      <div class="cartao"><div class="valor">${dados.quantidade_vendas}</div><div class="rotulo">Vendas</div></div>
      <div class="cartao"><div class="valor">${formatarMoeda(dados.faturamento_total)}</div><div class="rotulo">Faturamento</div></div>
      <div class="cartao"><div class="valor">${formatarMoeda(dados.lucro_total)}</div><div class="rotulo">Lucro</div></div>
    </div>
    <table>
      <thead><tr><th>Forma de pagamento</th><th>Qtd</th><th>Total</th></tr></thead>
      <tbody>${linhasFormas}</tbody>
    </table>
  `;
}

/** Baixa o backup do catálogo (produtos, clientes, taxas) como arquivo .json */
async function baixarBackup() {
  const resposta = await apiFetch("/api/sistema/exportar-backup");
  if (!resposta.ok) {
    await avisar("Não foi possível gerar o backup.");
    return;
  }
  const blob = await resposta.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `royal_cases_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
}

/** Restaura produtos/clientes/taxas a partir de um arquivo de backup exportado antes */
async function restaurarBackup() {
  const input = document.getElementById("arquivo-restaurar");
  const arquivo = input.files[0];
  if (!arquivo) return;

  const confirmado = await confirmar(
    "Restaurar esse backup? Produtos e clientes já existentes (mesmo código de barras/CPF) serão ATUALIZADOS, " +
    "os novos serão criados. Vendas NÃO são restauradas por esse caminho."
  );
  if (!confirmado) {
    input.value = "";
    return;
  }

  const formData = new FormData();
  formData.append("arquivo", arquivo);

  const resposta = await apiFetch("/api/sistema/importar-backup", { method: "POST", body: formData });
  const dados = await resposta.json();
  const area = document.getElementById("area-msg-backup");
  input.value = "";

  if (!resposta.ok) {
    area.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  area.innerHTML = `<div class="sucesso-msg">Backup restaurado! Produtos: ${dados.produtos_criados} novos, ${dados.produtos_atualizados} atualizados. Clientes: ${dados.clientes_criados} novos, ${dados.clientes_atualizados} atualizados.</div>`;
}

async function carregarEstoqueBaixo() {
  const resposta = await apiFetch("/api/dashboard/estoque-baixo");
  const produtos = await resposta.json();
  const area = document.getElementById("lista-estoque-baixo");

  if (produtos.length === 0) {
    area.innerHTML = `<div style="color:#7fd8a3;">Nenhum produto abaixo do estoque mínimo. ✅</div>`;
    return;
  }
  area.innerHTML = produtos.map((p) =>
    `<div class="alerta">⚠️ <strong>${escapeHtml(p.nome)}</strong>: restam ${p.quantidade_estoque} (mínimo ${p.estoque_minimo})</div>`
  ).join("");
}

async function carregarMaisLucrativos() {
  const resposta = await apiFetch("/api/dashboard/produtos-mais-lucrativos");
  const produtos = await resposta.json();
  const corpo = document.getElementById("corpo-mais-lucrativos");

  if (produtos.length === 0) {
    corpo.innerHTML = `<tr><td colspan="4" style="color:#666;">Nenhuma venda registrada ainda.</td></tr>`;
    return;
  }
  corpo.innerHTML = produtos.map((p) => `
    <tr>
      <td>${escapeHtml(p.nome)}</td>
      <td>${p.unidades_vendidas}</td>
      <td>${formatarMoeda(p.faturamento)}</td>
      <td>${formatarMoeda(p.lucro)}</td>
    </tr>
  `).join("");
}

async function carregarMargem() {
  const resposta = await apiFetch("/api/dashboard/margem-por-produto");
  const produtos = await resposta.json();
  const corpo = document.getElementById("corpo-margem");

  if (produtos.length === 0) {
    corpo.innerHTML = `<tr><td colspan="5" style="color:#666;">Nenhum produto cadastrado ainda.</td></tr>`;
    return;
  }
  corpo.innerHTML = produtos.map((p) => {
    const alertaMargem = p.margem_percentual < 25; // limiar simples de "margem apertada"
    return `
      <tr>
        <td>${escapeHtml(p.nome)}</td>
        <td>${formatarMoeda(p.preco_custo)}</td>
        <td>${formatarMoeda(p.preco_venda)}</td>
        <td>${formatarMoeda(p.margem_unitaria)}</td>
        <td style="${alertaMargem ? 'color: var(--erro); font-weight:700;' : ''}">${p.margem_percentual}%${alertaMargem ? " ⚠️" : ""}</td>
      </tr>
    `;
  }).join("");
}

function carregarTudo() {
  carregarFaturamento();
  carregarGraficoTendencia();
  carregarFechamentoCaixa();
  carregarEstoqueBaixo();
  carregarMaisLucrativos();
  carregarMargem();
}

/* Lógica da tela de Clientes e Usuários */

exigirLogin();

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

let usuarioAtualGlobal = null;
let permissoesDisponiveisGlobal = {};

async function inicializarPermissoes() {
  usuarioAtualGlobal = await obterUsuarioAtual();
  if (!podeAcessar(usuarioAtualGlobal, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }
  if (getPerfil() !== "gestor") {
    document.getElementById("link-pagamentos").style.display = "none";
  }
  if (podeAcessar(usuarioAtualGlobal, "usuarios.gerenciar")) {
    document.getElementById("secao-usuarios").style.display = "block";
    if (usuarioAtualGlobal.perfil === "gestor") {
      const respPerm = await apiFetch("/api/auth/permissoes-disponiveis");
      permissoesDisponiveisGlobal = await respPerm.json();
    }
    carregarUsuarios();
  }
}
inicializarPermissoes();

// ---------- Clientes ----------
async function carregarClientes(termo = "") {
  const url = termo ? `/api/clientes/buscar?q=${encodeURIComponent(termo)}` : "/api/clientes";
  const resposta = await apiFetch(url);
  const clientes = await resposta.json();
  renderClientes(clientes);
}

function renderClientes(clientes) {
  const corpo = document.getElementById("corpo-clientes");
  if (clientes.length === 0) {
    corpo.innerHTML = `<tr><td colspan="6" style="color:#666;">Nenhum cliente encontrado.</td></tr>`;
    return;
  }
  corpo.innerHTML = clientes.map((c) => `
    <tr>
      <td>${escapeHtml(c.nome)}</td>
      <td>${escapeHtml(c.telefone) || "-"}</td>
      <td>${escapeHtml(c.email) || "-"}</td>
      <td>${escapeHtml(c.cpf) || "-"}</td>
      <td>${new Date(c.criado_em).toLocaleDateString("pt-BR")}</td>
      <td style="white-space:nowrap;">
        <button class="secundario" style="padding:6px 10px;" onclick="abrirResumoCliente(${c.id})">🔍</button>
        <button class="secundario" style="padding:6px 10px;" onclick='iniciarEdicaoCliente(${JSON.stringify(c)})'>✏️</button>
      </td>
    </tr>
    <tr id="linha-resumo-${c.id}" style="display:none;">
      <td colspan="6"><div id="painel-resumo-${c.id}"></div></td>
    </tr>
  `).join("");
}

const ROTULO_STATUS = {
  ativo: { texto: "🟢 Ativo", cor: "var(--sucesso)" },
  em_risco: { texto: "🟡 Em risco", cor: "var(--aviso)" },
  inativo: { texto: "🔴 Inativo", cor: "var(--erro)" },
  sem_compras: { texto: "⚪ Sem compras ainda", cor: "var(--texto-secundario)" },
};

async function abrirResumoCliente(clienteId) {
  const linha = document.getElementById(`linha-resumo-${clienteId}`);
  const painel = document.getElementById(`painel-resumo-${clienteId}`);
  const jaAberta = linha.style.display === "table-row";

  document.querySelectorAll('[id^="linha-resumo-"]').forEach((l) => (l.style.display = "none"));
  if (jaAberta) return;

  painel.innerHTML = `<div class="card" style="background:#1c1c1c;">Carregando...</div>`;
  linha.style.display = "table-row";

  const resposta = await apiFetch(`/api/clientes/${clienteId}/resumo`);
  const r = await resposta.json();

  if (r.status === "sem_compras") {
    painel.innerHTML = `<div class="card" style="background:#1c1c1c;">Esse cliente ainda não fez nenhuma compra.</div>`;
    return;
  }

  const status = ROTULO_STATUS[r.status];
  const dataUltima = new Date(r.ultima_compra.data).toLocaleDateString("pt-BR");

  const favoritosHtml = r.produtos_favoritos.length
    ? r.produtos_favoritos.map((f, i) =>
        `<div style="padding:4px 0;">${i === 0 ? "⭐" : `${i + 1}.`} ${escapeHtml(f.nome)} — ${f.quantidade_total} unidades (${f.vezes_comprado}x comprado)</div>`
      ).join("")
    : "<div style='color:#888;'>Sem produtos suficientes pra destacar ainda.</div>";

  painel.innerHTML = `
    <div class="card" style="background:#1c1c1c;">
      <div class="linha">
        <div><strong>Status:</strong> <span style="color:${status.cor};">${status.texto}</span></div>
        <div><strong>Total de compras:</strong> ${r.total_compras}</div>
        <div><strong>Total gasto:</strong> R$ ${r.valor_total_gasto.toFixed(2)}</div>
        <div><strong>⭐ Pontos:</strong> ${r.pontos_fidelidade}</div>
      </div>
      <div class="linha" style="margin-top:8px;">
        <div><strong>Última compra:</strong> ${dataUltima} (R$ ${r.ultima_compra.valor.toFixed(2)})</div>
        <div><strong>Dias sem comprar:</strong> ${r.dias_sem_comprar}</div>
      </div>
      <div style="margin-top:12px;">
        <strong>Produtos favoritos:</strong>
        ${favoritosHtml}
      </div>
    </div>
  `;
}

let timeoutBuscaClientes = null;
document.getElementById("input-busca").addEventListener("input", (e) => {
  clearTimeout(timeoutBuscaClientes);
  const termo = e.target.value.trim();
  timeoutBuscaClientes = setTimeout(() => carregarClientes(termo), 300);
});

function abrirFormNovoCliente() {
  document.getElementById("form-novo-cliente").style.display = "block";
}
function fecharFormNovoCliente() {
  document.getElementById("form-novo-cliente").style.display = "none";
  document.getElementById("erro-novo-cliente").innerHTML = "";
  ["novo-nome", "novo-telefone", "novo-email", "novo-cpf"].forEach((id) => (document.getElementById(id).value = ""));
  clienteEditandoId = null;
  document.getElementById("titulo-form-cliente").textContent = "Novo cliente";
  document.getElementById("btn-salvar-cliente").textContent = "Salvar cliente";
}

let clienteEditandoId = null;

function iniciarEdicaoCliente(cliente) {
  clienteEditandoId = cliente.id;
  document.getElementById("novo-nome").value = cliente.nome;
  document.getElementById("novo-telefone").value = cliente.telefone || "";
  document.getElementById("novo-email").value = cliente.email || "";
  document.getElementById("novo-cpf").value = cliente.cpf || "";
  document.getElementById("titulo-form-cliente").textContent = `Editando: ${cliente.nome}`;
  document.getElementById("btn-salvar-cliente").textContent = "Salvar alterações";
  document.getElementById("form-novo-cliente").style.display = "block";
  document.getElementById("form-novo-cliente").scrollIntoView({ behavior: "smooth" });
}

async function salvarNovoCliente() {
  const nome = document.getElementById("novo-nome").value.trim();
  const areaErro = document.getElementById("erro-novo-cliente");
  areaErro.innerHTML = "";

  if (!nome) {
    areaErro.innerHTML = `<div class="erro-msg">Nome é obrigatório.</div>`;
    return;
  }

  const payload = {
    nome,
    telefone: document.getElementById("novo-telefone").value.trim() || null,
    email: document.getElementById("novo-email").value.trim() || null,
    cpf: document.getElementById("novo-cpf").value.trim() || null,
  };

  const url = clienteEditandoId ? `/api/clientes/${clienteEditandoId}` : "/api/clientes";
  const metodo = clienteEditandoId ? "PUT" : "POST";

  const resposta = await apiFetch(url, { method: metodo, body: JSON.stringify(payload) });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  fecharFormNovoCliente();
  carregarClientes();
}

// ---------- Usuários (só gestor) ----------
async function carregarUsuarios() {
  const resposta = await apiFetch("/api/auth/usuarios");
  if (!resposta.ok) return; // atendente cai aqui - a seção nem aparece, então ok
  const usuarios = await resposta.json();
  renderUsuarios(usuarios);
}

function renderUsuarios(usuarios) {
  const corpo = document.getElementById("corpo-usuarios");
  const souGestor = usuarioAtualGlobal.perfil === "gestor";

  corpo.innerHTML = usuarios.map((u) => `
    <tr>
      <td>${escapeHtml(u.nome)}</td>
      <td>${escapeHtml(u.login)}</td>
      <td><span class="badge ${u.perfil}">${u.perfil}</span></td>
      <td>${u.ativo ? "🟢 Ativo" : "🔴 Inativo"}</td>
      <td>
        <button class="secundario" style="padding:6px 10px;" onclick="alternarAtivoUsuario(${u.id})">
          ${u.ativo ? "Desativar" : "Ativar"}
        </button>
        ${souGestor && u.perfil === "atendente" ? `
          <button class="secundario" style="padding:6px 10px;" onclick='abrirPermissoes(${u.id}, ${JSON.stringify(u.permissoes_extra)})'>
            🔑 Permissões
          </button>` : ""}
      </td>
    </tr>
    <tr id="linha-permissoes-${u.id}" style="display:none;">
      <td colspan="5"><div id="painel-permissoes-${u.id}"></div></td>
    </tr>
  `).join("");
}

function abrirPermissoes(usuarioId, permissoesAtuais) {
  const linha = document.getElementById(`linha-permissoes-${usuarioId}`);
  const painel = document.getElementById(`painel-permissoes-${usuarioId}`);
  const jaAberta = linha.style.display === "table-row";

  // Fecha qualquer outro painel aberto antes de abrir este
  document.querySelectorAll('[id^="linha-permissoes-"]').forEach((l) => (l.style.display = "none"));

  if (jaAberta) return; // clicou de novo no mesmo -> só fecha

  const checkboxes = Object.entries(permissoesDisponiveisGlobal).map(([chave, descricao]) => `
    <label style="display:block; margin:6px 0; font-weight:normal;">
      <input type="checkbox" value="${chave}" ${permissoesAtuais.includes(chave) ? "checked" : ""}> ${descricao}
    </label>
  `).join("");

  painel.innerHTML = `
    <div class="card" style="background:#1c1c1c;">
      <strong>Permissões extras deste atendente:</strong>
      <div id="checks-${usuarioId}">${checkboxes}</div>
      <button style="margin-top:10px;" onclick="salvarPermissoes(${usuarioId})">Salvar permissões</button>
    </div>
  `;
  linha.style.display = "table-row";
}

async function salvarPermissoes(usuarioId) {
  const marcadas = Array.from(
    document.querySelectorAll(`#checks-${usuarioId} input[type=checkbox]:checked`)
  ).map((c) => c.value);

  const resposta = await apiFetch(`/api/auth/usuarios/${usuarioId}/permissoes`, {
    method: "PUT",
    body: JSON.stringify({ permissoes: marcadas }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    alert(dados.detail);
    return;
  }
  document.getElementById(`linha-permissoes-${usuarioId}`).style.display = "none";
  carregarUsuarios();
}

async function criarUsuario() {
  const nome = document.getElementById("novo-usuario-nome").value.trim();
  const login = document.getElementById("novo-usuario-login").value.trim();
  const email = document.getElementById("novo-usuario-email").value.trim();
  const senha = document.getElementById("novo-usuario-senha").value;
  const perfil = document.getElementById("novo-usuario-perfil").value;
  const areaErro = document.getElementById("erro-novo-usuario");
  areaErro.innerHTML = "";

  if (!nome || !login || !email || !senha) {
    areaErro.innerHTML = `<div class="erro-msg">Nome, login, e-mail e senha são obrigatórios (o e-mail é o que permite recuperar a senha depois).</div>`;
    return;
  }

  const resposta = await apiFetch("/api/auth/usuarios", {
    method: "POST",
    body: JSON.stringify({ nome, login, email, senha, perfil }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }

  ["novo-usuario-nome", "novo-usuario-login", "novo-usuario-email", "novo-usuario-senha"].forEach((id) => (document.getElementById(id).value = ""));
  carregarUsuarios();
}

async function alternarAtivoUsuario(usuarioId) {
  const resposta = await apiFetch(`/api/auth/usuarios/${usuarioId}/alternar-ativo`, { method: "PATCH" });
  const dados = await resposta.json();
  if (!resposta.ok) {
    alert(dados.detail);
    return;
  }
  carregarUsuarios();
}

// Carga inicial
carregarClientes();

/* Lógica da tela de Fornecedores */

exigirLogin();

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

let podeCadastrar = false;
let fornecedorEditandoId = null;

async function inicializar() {
  const usuarioAtual = await obterUsuarioAtual();
  podeCadastrar = podeAcessar(usuarioAtual, "produtos.cadastrar");

  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }
  if (usuarioAtual.perfil !== "gestor") {
    document.getElementById("link-pagamentos").style.display = "none";
  }
  if (podeCadastrar) {
    document.getElementById("btn-novo-fornecedor").style.display = "inline-block";
  }

  carregarFornecedores();
}

async function carregarFornecedores() {
  mostrarCarregando("corpo-fornecedores", "Carregando fornecedores...");
  const resposta = await apiFetch("/api/fornecedores");
  const fornecedores = await resposta.json();
  renderFornecedores(fornecedores);
}

async function renderFornecedores(fornecedores) {
  const corpo = document.getElementById("corpo-fornecedores");
  if (fornecedores.length === 0) {
    corpo.innerHTML = `<tr><td style="color:#666;">Nenhum fornecedor cadastrado ainda.</td></tr>`;
    return;
  }

  const linhas = await Promise.all(fornecedores.map(async (f) => {
    const respProdutos = await apiFetch(`/api/fornecedores/${f.id}/produtos`);
    const produtos = await respProdutos.json();
    return `
      <tr>
        <td>${escapeHtml(f.nome)}</td>
        <td>${escapeHtml(f.telefone) || "-"}</td>
        <td>${escapeHtml(f.email) || "-"}</td>
        <td>${escapeHtml(f.cnpj) || "-"}</td>
        <td>${produtos.length} produto(s)</td>
        <td>${podeCadastrar ? `<button class="secundario" style="padding:6px 10px;" onclick='iniciarEdicaoFornecedor(${JSON.stringify(f)})'>✏️</button>` : ""}</td>
      </tr>
    `;
  }));
  corpo.innerHTML = linhas.join("");
}

function abrirFormNovoFornecedor() {
  fornecedorEditandoId = null;
  ["f-nome", "f-telefone", "f-email", "f-cnpj", "f-observacoes"].forEach((id) => (document.getElementById(id).value = ""));
  document.getElementById("titulo-form-fornecedor").textContent = "Novo fornecedor";
  document.getElementById("btn-salvar-fornecedor").textContent = "Cadastrar fornecedor";
  document.getElementById("btn-cancelar-fornecedor").style.display = "none";
  document.getElementById("secao-form").style.display = "block";
  document.getElementById("secao-form").scrollIntoView({ behavior: "smooth" });
}

function iniciarEdicaoFornecedor(fornecedor) {
  fornecedorEditandoId = fornecedor.id;
  document.getElementById("f-nome").value = fornecedor.nome;
  document.getElementById("f-telefone").value = fornecedor.telefone || "";
  document.getElementById("f-email").value = fornecedor.email || "";
  document.getElementById("f-cnpj").value = fornecedor.cnpj || "";
  document.getElementById("f-observacoes").value = fornecedor.observacoes || "";
  document.getElementById("titulo-form-fornecedor").textContent = `Editando: ${fornecedor.nome}`;
  document.getElementById("btn-salvar-fornecedor").textContent = "Salvar alterações";
  document.getElementById("btn-cancelar-fornecedor").style.display = "inline-block";
  document.getElementById("secao-form").style.display = "block";
  document.getElementById("secao-form").scrollIntoView({ behavior: "smooth" });
}

function cancelarEdicaoFornecedor() {
  document.getElementById("secao-form").style.display = "none";
  document.getElementById("erro-fornecedor").innerHTML = "";
}

async function salvarFornecedor() {
  const nome = document.getElementById("f-nome").value.trim();
  const areaErro = document.getElementById("erro-fornecedor");
  areaErro.innerHTML = "";

  if (!nome) {
    areaErro.innerHTML = `<div class="erro-msg">Nome é obrigatório.</div>`;
    return;
  }

  const payload = {
    nome,
    telefone: document.getElementById("f-telefone").value.trim() || null,
    email: document.getElementById("f-email").value.trim() || null,
    cnpj: document.getElementById("f-cnpj").value.trim() || null,
    observacoes: document.getElementById("f-observacoes").value.trim() || null,
  };

  const url = fornecedorEditandoId ? `/api/fornecedores/${fornecedorEditandoId}` : "/api/fornecedores";
  const metodo = fornecedorEditandoId ? "PUT" : "POST";

  const resposta = await apiFetch(url, { method: metodo, body: JSON.stringify(payload) });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  cancelarEdicaoFornecedor();
  carregarFornecedores();
}

inicializar();

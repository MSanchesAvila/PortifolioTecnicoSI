/*
 * Funções de autenticação usadas em TODAS as telas.
 * O token fica no localStorage do navegador - por isso, ao trocar de
 * computador/celular, é preciso logar de novo (o token não "viaja" sozinho).
 */

/**
 * Escapa caracteres HTML perigosos antes de inserir texto vindo do banco
 * (nome de cliente, produto, etc.) dentro de innerHTML. SEM isso, um nome
 * de cliente ou produto contendo algo como <script> rodaria no navegador
 * de quem visualizar a lista - inclusive roubando o token de login de
 * outro usuário, já que ele fica no localStorage. Use em TODO lugar que
 * insere dado de banco dentro de innerHTML.
 */
function escapeHtml(texto) {
  if (texto === null || texto === undefined) return "";
  const div = document.createElement("div");
  div.textContent = String(texto);
  return div.innerHTML;
}

function getToken() {
  return localStorage.getItem("rc_token");
}

function getPerfil() {
  return localStorage.getItem("rc_perfil");
}

function getNomeUsuario() {
  return localStorage.getItem("rc_nome");
}

function salvarSessao(token, perfil, nome) {
  localStorage.setItem("rc_token", token);
  localStorage.setItem("rc_perfil", perfil);
  localStorage.setItem("rc_nome", nome);
}

function logout() {
  localStorage.removeItem("rc_token");
  localStorage.removeItem("rc_perfil");
  localStorage.removeItem("rc_nome");
  window.location.href = "/login";
}

/** Redireciona pro login se não houver token. Chame no topo de toda página protegida. */
function exigirLogin() {
  if (!getToken()) {
    window.location.href = "/login";
  }
}

/**
 * Wrapper do fetch() que já inclui o header de autenticação.
 * Se a API responder 401 (token expirado/inválido), manda pro login automaticamente.
 */
async function apiFetch(url, opcoes = {}) {
  const headers = opcoes.headers || {};
  headers["Authorization"] = `Bearer ${getToken()}`;
  if (opcoes.body && !(opcoes.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }
  const resposta = await fetch(url, { ...opcoes, headers });
  if (resposta.status === 401) {
    logout();
    throw new Error("Sessão expirada");
  }
  return resposta;
}

/**
 * Busca os dados completos de quem está logado, incluindo a lista de
 * permissões extras (se for atendente). Usado por toda tela pra decidir
 * o que mostrar/esconder.
 */
async function obterUsuarioAtual() {
  const resposta = await apiFetch("/api/auth/me");
  return resposta.json();
}

/** true se for gestor OU se tiver a permissão específica concedida */
function podeAcessar(usuarioAtual, permissao) {
  return usuarioAtual.perfil === "gestor" || usuarioAtual.permissoes_extra.includes(permissao);
}

/*
 * Tema claro/escuro - preferência salva no navegador.
 * A aplicação do tema salvo já acontece antes (script inline no <head> de
 * cada página, pra não "piscar" o tema errado por uma fração de segundo);
 * aqui só cuidamos da troca quando o usuário clica no botão.
 */
function alternarTema() {
  const atual = document.documentElement.getAttribute("data-tema") || "escuro";
  const novo = atual === "escuro" ? "claro" : "escuro";
  document.documentElement.setAttribute("data-tema", novo);
  localStorage.setItem("rc_tema", novo);
  _atualizarIconeTema();
}

function _atualizarIconeTema() {
  const botao = document.getElementById("btn-tema");
  if (!botao) return;
  const atual = document.documentElement.getAttribute("data-tema") || "escuro";
  botao.textContent = atual === "escuro" ? "☀️ Claro" : "🌙 Escuro";
}

_atualizarIconeTema();

/*
 * Modal de troca de senha - compartilhado por todas as telas.
 * Injeta o HTML dinamicamente (assim não precisa repetir em cada página).
 */
function _garantirModalSenha() {
  if (document.getElementById("modal-senha")) return; // já existe, não duplica

  const div = document.createElement("div");
  div.innerHTML = `
    <div id="modal-senha" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:1000; align-items:center; justify-content:center; padding:20px;">
      <div class="card" style="max-width:340px; width:100%;">
        <h3 style="margin-top:0;">Meu perfil</h3>

        <div style="margin-bottom:16px;">
          <label>E-mail (usado pra recuperar senha se esquecer)</label>
          <input type="email" id="meu-email-input" placeholder="seu@email.com" style="margin-bottom:8px;">
          <button class="secundario" style="width:100%;" onclick="salvarMeuEmail()">Salvar e-mail</button>
          <div id="erro-meu-email"></div>
        </div>

        <hr style="border-color:var(--borda); margin:16px 0;">

        <h3 style="margin-top:0;">Trocar senha</h3>
        <input type="password" id="senha-atual-input" placeholder="Senha atual" style="margin-bottom:10px;">
        <input type="password" id="senha-nova-input" placeholder="Nova senha (mín. 6 caracteres)" style="margin-bottom:10px;">
        <div id="erro-troca-senha"></div>
        <div class="linha" style="margin-top:10px;">
          <button onclick="salvarNovaSenha()">Salvar senha</button>
          <button class="secundario" onclick="fecharModalSenha()">Fechar</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(div);
}

async function abrirModalSenha() {
  _garantirModalSenha();
  document.getElementById("modal-senha").style.display = "flex";
  try {
    const usuarioAtual = await obterUsuarioAtual();
    document.getElementById("meu-email-input").value = usuarioAtual.email || "";
  } catch (erro) {
    // se falhar, só deixa o campo vazio - não é crítico pra abrir o modal
  }
}

async function salvarMeuEmail() {
  const email = document.getElementById("meu-email-input").value.trim();
  const areaErro = document.getElementById("erro-meu-email");
  areaErro.innerHTML = "";

  if (!email) {
    areaErro.innerHTML = `<div class="erro-msg">Digite um e-mail.</div>`;
    return;
  }

  const resposta = await apiFetch("/api/auth/me", { method: "PATCH", body: JSON.stringify({ email }) });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  areaErro.innerHTML = `<div class="sucesso-msg">E-mail salvo!</div>`;
}

function fecharModalSenha() {
  const modal = document.getElementById("modal-senha");
  if (modal) modal.style.display = "none";
}

async function salvarNovaSenha() {
  const senhaAtual = document.getElementById("senha-atual-input").value;
  const senhaNova = document.getElementById("senha-nova-input").value;
  const areaErro = document.getElementById("erro-troca-senha");
  areaErro.innerHTML = "";

  if (!senhaAtual || !senhaNova) {
    areaErro.innerHTML = `<div class="erro-msg">Preencha os dois campos.</div>`;
    return;
  }

  const resposta = await apiFetch("/api/auth/me/senha", {
    method: "PATCH",
    body: JSON.stringify({ senha_atual: senhaAtual, senha_nova: senhaNova }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  await avisar("Senha alterada com sucesso! Você vai precisar logar de novo.");
  logout();
}

/* =========================================================================
 * Modal customizado - substitui alert()/confirm()/prompt() nativos, que
 * quebram a identidade visual (aparecem com a cara do Windows/Chrome em vez
 * das cores da Royal Cases). Leve, sem biblioteca externa: 3 funções que
 * devolvem Promise, pra usar com await no lugar exato onde usava o nativo.
 *
 *   await avisar("mensagem")                    no lugar de alert(...)
 *   if (await confirmar("tem certeza?")) {...}   no lugar de confirm(...)
 *   const v = await perguntar("digite algo")     no lugar de prompt(...)
 * ========================================================================= */
function _garantirModalGenerico() {
  if (document.getElementById("modal-generico")) return;
  const div = document.createElement("div");
  div.innerHTML = `
    <div id="modal-generico" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:2000; align-items:center; justify-content:center; padding:20px;">
      <div class="card" style="max-width:380px; width:100%;">
        <p id="modal-generico-mensagem" style="white-space:pre-line; margin-top:0;"></p>
        <input type="text" id="modal-generico-input" style="display:none; margin-bottom:10px;">
        <div class="linha" id="modal-generico-botoes" style="margin-top:14px;">
          <button id="modal-generico-btn-ok">OK</button>
          <button class="secundario" id="modal-generico-btn-cancelar" style="display:none;">Cancelar</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(div);
}

function avisar(mensagem) {
  _garantirModalGenerico();
  return new Promise((resolve) => {
    const modal = document.getElementById("modal-generico");
    document.getElementById("modal-generico-mensagem").textContent = mensagem;
    document.getElementById("modal-generico-input").style.display = "none";
    document.getElementById("modal-generico-btn-cancelar").style.display = "none";
    const btnOk = document.getElementById("modal-generico-btn-ok");
    btnOk.textContent = "OK";
    btnOk.onclick = () => { modal.style.display = "none"; resolve(); };
    modal.style.display = "flex";
  });
}

function confirmar(mensagem) {
  _garantirModalGenerico();
  return new Promise((resolve) => {
    const modal = document.getElementById("modal-generico");
    document.getElementById("modal-generico-mensagem").textContent = mensagem;
    document.getElementById("modal-generico-input").style.display = "none";
    const btnOk = document.getElementById("modal-generico-btn-ok");
    const btnCancelar = document.getElementById("modal-generico-btn-cancelar");
    btnOk.textContent = "Confirmar";
    btnCancelar.style.display = "inline-block";
    btnOk.onclick = () => { modal.style.display = "none"; resolve(true); };
    btnCancelar.onclick = () => { modal.style.display = "none"; resolve(false); };
    modal.style.display = "flex";
  });
}

function perguntar(mensagem, valorPadrao = "") {
  _garantirModalGenerico();
  return new Promise((resolve) => {
    const modal = document.getElementById("modal-generico");
    const input = document.getElementById("modal-generico-input");
    document.getElementById("modal-generico-mensagem").textContent = mensagem;
    input.style.display = "block";
    input.value = valorPadrao;
    const btnOk = document.getElementById("modal-generico-btn-ok");
    const btnCancelar = document.getElementById("modal-generico-btn-cancelar");
    btnOk.textContent = "OK";
    btnCancelar.style.display = "inline-block";
    btnOk.onclick = () => { modal.style.display = "none"; resolve(input.value); };
    btnCancelar.onclick = () => { modal.style.display = "none"; resolve(null); };
    input.onkeydown = (e) => { if (e.key === "Enter") btnOk.onclick(); };
    modal.style.display = "flex";
    setTimeout(() => input.focus(), 50);
  });
}

/* =========================================================================
 * Indicador de carregamento - leve, um "..." com leve pulsação, sem spinner
 * gráfico pesado. Chame mostrarCarregando(id) antes de um fetch demorado e
 * esconderCarregando(id) depois (ou deixe o innerHTML normal substituir).
 * ========================================================================= */
function mostrarCarregando(elementoId, texto = "Carregando...") {
  const el = document.getElementById(elementoId);
  if (el) el.innerHTML = `<span class="carregando">${texto}</span>`;
}

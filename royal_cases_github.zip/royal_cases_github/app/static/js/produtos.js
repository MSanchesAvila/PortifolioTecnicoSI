/* Lógica da tela de Produtos */

exigirLogin();

let usuarioAtual = null;
let podeCadastrar = false;
let podeVerCustoGlobal = false;

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

async function inicializar() {
  usuarioAtual = await obterUsuarioAtual();
  podeCadastrar = podeAcessar(usuarioAtual, "produtos.cadastrar");
  podeVerCustoGlobal = podeAcessar(usuarioAtual, "produtos.ver_custo");

  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }
  if (getPerfil() !== "gestor") {
    document.getElementById("link-pagamentos").style.display = "none";
  }
  if (podeCadastrar) {
    document.getElementById("secao-cadastro").style.display = "block";
    document.getElementById("label-mostrar-inativos").style.display = "inline-flex";
    document.getElementById("btn-imprimir-etiquetas").style.display = "inline-block";
    carregarFornecedoresNoDropdown();
  }

  montarCabecalho();
  carregarProdutos();
}

async function carregarFornecedoresNoDropdown() {
  const resposta = await apiFetch("/api/fornecedores");
  const fornecedores = await resposta.json();
  const select = document.getElementById("p-fornecedor-id");
  fornecedores.forEach((f) => {
    const opcao = document.createElement("option");
    opcao.value = f.id;
    opcao.textContent = f.nome;
    select.appendChild(opcao);
  });
}

let ultimoCodigoGerado = null;

// ---------- Cabeçalho da tabela muda conforme o perfil ----------
function montarCabecalho() {
  const th = document.getElementById("cabecalho-tabela");
  const colunaSelecao = podeCadastrar ? "<th>🏷️</th>" : "";
  if (podeVerCustoGlobal) {
    th.innerHTML = `<tr>${colunaSelecao}<th>Nome</th><th>Categoria</th><th>Código</th><th>Custo</th><th>Venda</th><th>Margem</th><th>Estoque</th><th></th></tr>`;
  } else {
    th.innerHTML = `<tr><th>Nome</th><th>Categoria</th><th>Código</th><th>Venda</th><th>Estoque</th></tr>`;
  }
}

async function carregarProdutos(filtro = "") {
  mostrarCarregando("corpo-produtos", "Carregando produtos...");
  const incluirInativos = document.getElementById("mostrar-inativos")?.checked;
  const url = incluirInativos ? "/api/produtos?incluir_inativos=true" : "/api/produtos";
  const resposta = await apiFetch(url);
  let produtos = await resposta.json();
  if (filtro) {
    produtos = produtos.filter((p) => p.nome.toLowerCase().includes(filtro.toLowerCase()));
  }
  renderProdutos(produtos);
}

function renderProdutos(produtos) {
  const corpo = document.getElementById("corpo-produtos");
  if (produtos.length === 0) {
    corpo.innerHTML = `<tr><td style="color:#666;">Nenhum produto encontrado.</td></tr>`;
    return;
  }

  corpo.innerHTML = produtos.map((p) => {
    const estoqueBaixo = podeVerCustoGlobal && p.quantidade_estoque <= p.estoque_minimo;
    const corEstoque = estoqueBaixo ? "color: var(--erro); font-weight:700;" : "";

    if (podeVerCustoGlobal) {
      const margem = (p.preco_venda - p.preco_custo).toFixed(2);
      const margemPct = p.preco_venda ? (((p.preco_venda - p.preco_custo) / p.preco_venda) * 100).toFixed(1) : "0";
      const estiloInativo = p.ativo === false ? "opacity:0.5;" : "";
      const subtituloVariacao = p.variacao
        ? `<br><span style="font-size:11px; color:var(--texto-secundario);">${escapeHtml(p.variacao)}</span>`
        : "";
      const badgeCondicao = p.condicao && p.condicao !== "novo"
        ? ` <span class="badge atendente" style="text-transform:capitalize;">${p.condicao}</span>`
        : "";
      const precoVendaHtml = p.preco_promocional
        ? `<span style="text-decoration:line-through; color:var(--texto-secundario); font-size:12px;">R$ ${p.preco_venda.toFixed(2)}</span><br>R$ ${p.preco_promocional.toFixed(2)}`
        : `R$ ${p.preco_venda.toFixed(2)}`;
      return `
        <tr style="${estiloInativo}">
          ${podeCadastrar ? `
            <td style="white-space:nowrap;">
              <input type="checkbox" class="checkbox-etiqueta" data-produto-id="${p.id}">
              <input type="number" class="qtd-etiqueta" data-produto-id="${p.id}" value="1" min="1" max="65" style="width:50px; padding:4px;">
            </td>
          ` : ""}
          <td>${escapeHtml(p.nome)} ${p.ativo === false ? '<span class="badge atendente">Inativo</span>' : ""}${badgeCondicao}${subtituloVariacao}</td>
          <td>${escapeHtml(p.categoria) || "-"}</td>
          <td style="font-family:monospace;">${escapeHtml(p.codigo_barras)}</td>
          <td>R$ ${p.preco_custo.toFixed(2)}</td>
          <td>${precoVendaHtml}</td>
          <td>R$ ${margem} (${margemPct}%)</td>
          <td style="${corEstoque}">${p.quantidade_estoque}${estoqueBaixo ? " ⚠️" : ""}</td>
          <td style="white-space:nowrap;">
            <button class="secundario" style="padding:6px 10px;" onclick="baixarEtiqueta(${p.id})">🏷️</button>
            ${podeCadastrar ? `
              <button class="secundario" style="padding:6px 10px;" onclick='iniciarEdicaoProduto(${JSON.stringify(p)})'>✏️</button>
              <button class="secundario" style="padding:6px 10px;" onclick='duplicarProduto(${JSON.stringify(p)})' title="Duplicar (nova variação)">🔁</button>
              <button class="secundario" style="padding:6px 10px;" onclick="ajustarEstoquePrompt(${p.id}, '${escapeHtml(p.nome)}', ${p.quantidade_estoque})">📦</button>
              <button class="secundario" style="padding:6px 10px;" onclick="alternarAtivoProduto(${p.id}, '${escapeHtml(p.nome)}', ${p.ativo !== false})">${p.ativo === false ? "♻️" : "🚫"}</button>
            ` : ""}
          </td>
        </tr>
      `;
    }
    return `
      <tr>
        <td>${escapeHtml(p.nome)}</td>
        <td>${escapeHtml(p.categoria) || "-"}</td>
        <td style="font-family:monospace;">${escapeHtml(p.codigo_barras)}</td>
        <td>R$ ${p.preco_venda.toFixed(2)}</td>
        <td>${p.quantidade_estoque}</td>
      </tr>
    `;
  }).join("");
}

document.getElementById("filtro").addEventListener("input", (e) => {
  carregarProdutos(e.target.value.trim());
});

// ---------- Cadastro / Edição (só gestor) ----------
let produtoEditandoId = null;

async function salvarProduto() {
  const areaErro = document.getElementById("erro-produto");
  areaErro.innerHTML = "";

  const nome = document.getElementById("p-nome").value.trim();
  const custo = parseFloat(document.getElementById("p-custo").value);
  const venda = parseFloat(document.getElementById("p-venda").value);
  const promocional = document.getElementById("p-promocional").value.trim();
  const peso = document.getElementById("p-peso").value.trim();
  const altura = document.getElementById("p-altura").value.trim();
  const largura = document.getElementById("p-largura").value.trim();
  const comprimento = document.getElementById("p-comprimento").value.trim();

  if (!nome || isNaN(custo) || isNaN(venda)) {
    areaErro.innerHTML = `<div class="erro-msg">Nome, preço de custo e preço de venda são obrigatórios.</div>`;
    return;
  }

  const camposComuns = {
    nome,
    categoria: document.getElementById("p-categoria").value.trim() || null,
    subcategoria: document.getElementById("p-subcategoria").value.trim() || null,
    gtin_ean: document.getElementById("p-gtin-ean").value.trim() || null,
    condicao: document.getElementById("p-condicao").value,
    fornecedor_id: document.getElementById("p-fornecedor-id").value || null,
    grupo_variacao: document.getElementById("p-grupo-variacao").value.trim() || null,
    variacao: document.getElementById("p-variacao").value.trim() || null,
    preco_custo: custo,
    preco_venda: venda,
    preco_promocional: promocional ? parseFloat(promocional) : null,
    peso_gramas: peso ? parseFloat(peso) : null,
    altura_cm: altura ? parseFloat(altura) : null,
    largura_cm: largura ? parseFloat(largura) : null,
    comprimento_cm: comprimento ? parseFloat(comprimento) : null,
  };

  if (produtoEditandoId) {
    // Modo edição: PUT, sem mexer em estoque (isso passa pelo botão de ajuste)
    const payload = { ...camposComuns, estoque_minimo: parseInt(document.getElementById("p-minimo").value) || 0 };
    const resposta = await apiFetch(`/api/produtos/${produtoEditandoId}`, { method: "PUT", body: JSON.stringify(payload) });
    const dados = await resposta.json();
    if (!resposta.ok) {
      areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
      return;
    }
    cancelarEdicaoProduto();
    carregarProdutos();
    return;
  }

  const quantidadeTexto = document.getElementById("p-estoque").value.trim();
  if (quantidadeTexto === "") {
    areaErro.innerHTML = `<div class="erro-msg">Quantidade em estoque é obrigatória.</div>`;
    return;
  }

  const payload = {
    ...camposComuns,
    quantidade_estoque: parseInt(quantidadeTexto),
    estoque_minimo: parseInt(document.getElementById("p-minimo").value) || 3,
  };

  const resposta = await apiFetch("/api/produtos", { method: "POST", body: JSON.stringify(payload) });
  const produto = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${produto.detail}</div>`;
    return;
  }

  // Limpa o formulário (mantém grupo de variação preenchido - facilita
  // cadastrar a próxima cor/tamanho da mesma peça em seguida)
  ["p-nome", "p-categoria", "p-subcategoria", "p-gtin-ean", "p-variacao", "p-promocional", "p-peso", "p-altura", "p-largura", "p-comprimento"]
    .forEach((id) => (document.getElementById(id).value = ""));
  document.getElementById("p-estoque").value = "";
  document.getElementById("p-minimo").value = 3;
  document.getElementById("p-condicao").value = "novo";

  // Mostra a etiqueta gerada na hora
  ultimoCodigoGerado = produto.id;
  document.getElementById("codigo-gerado").textContent = produto.codigo_barras;
  const imgResposta = await apiFetch(`/api/produtos/${produto.id}/etiqueta`);
  const blob = await imgResposta.blob();
  document.getElementById("img-etiqueta-nova").src = URL.createObjectURL(blob);
  document.getElementById("area-etiqueta-nova").style.display = "block";

  carregarProdutos();
}

function iniciarEdicaoProduto(produto) {
  produtoEditandoId = produto.id;
  document.getElementById("p-nome").value = produto.nome;
  document.getElementById("p-categoria").value = produto.categoria || "";
  document.getElementById("p-subcategoria").value = produto.subcategoria || "";
  document.getElementById("p-gtin-ean").value = produto.gtin_ean || "";
  document.getElementById("p-condicao").value = produto.condicao || "novo";
  document.getElementById("p-fornecedor-id").value = produto.fornecedor_id || "";
  document.getElementById("p-grupo-variacao").value = produto.grupo_variacao || "";
  document.getElementById("p-variacao").value = produto.variacao || "";
  document.getElementById("p-custo").value = produto.preco_custo;
  document.getElementById("p-venda").value = produto.preco_venda;
  document.getElementById("p-promocional").value = produto.preco_promocional ?? "";
  document.getElementById("p-peso").value = produto.peso_gramas ?? "";
  document.getElementById("p-altura").value = produto.altura_cm ?? "";
  document.getElementById("p-largura").value = produto.largura_cm ?? "";
  document.getElementById("p-comprimento").value = produto.comprimento_cm ?? "";
  document.getElementById("p-minimo").value = produto.estoque_minimo;

  // Campo de estoque inicial não se aplica na edição (estoque muda só por
  // venda ou pelo botão de ajuste, que pede motivo) - escondemos.
  document.getElementById("campo-estoque-inicial").style.display = "none";
  document.getElementById("titulo-form-produto").textContent = `Editando: ${produto.nome}`;
  document.getElementById("btn-salvar-produto").textContent = "Salvar alterações";
  document.getElementById("btn-cancelar-edicao").style.display = "inline-block";
  document.getElementById("area-etiqueta-nova").style.display = "none";

  document.getElementById("secao-cadastro").scrollIntoView({ behavior: "smooth" });
}

/**
 * Duplica um produto existente pra criar rapidamente a próxima variação
 * (mesma cor/tamanho/modelo, só troca o que for diferente) - preenche o
 * formulário de CADASTRO (não edição) com os dados, deixando só nome/preço/
 * variação editáveis, e limpa o código de barras (um novo é gerado).
 */
function duplicarProduto(produto) {
  produtoEditandoId = null; // fica em modo CADASTRO, não edição - vai gerar produto novo
  document.getElementById("p-nome").value = produto.nome;
  document.getElementById("p-categoria").value = produto.categoria || "";
  document.getElementById("p-subcategoria").value = produto.subcategoria || "";
  document.getElementById("p-gtin-ean").value = ""; // GTIN é único por peça de fábrica - não duplica
  document.getElementById("p-condicao").value = produto.condicao || "novo";
  document.getElementById("p-fornecedor-id").value = produto.fornecedor_id || "";
  document.getElementById("p-grupo-variacao").value = produto.grupo_variacao || produto.nome;
  document.getElementById("p-variacao").value = ""; // essa parte muda - deixa em branco pra digitar
  document.getElementById("p-custo").value = produto.preco_custo;
  document.getElementById("p-venda").value = produto.preco_venda;
  document.getElementById("p-promocional").value = produto.preco_promocional ?? "";
  document.getElementById("p-peso").value = produto.peso_gramas ?? "";
  document.getElementById("p-altura").value = produto.altura_cm ?? "";
  document.getElementById("p-largura").value = produto.largura_cm ?? "";
  document.getElementById("p-comprimento").value = produto.comprimento_cm ?? "";
  document.getElementById("p-minimo").value = produto.estoque_minimo;
  document.getElementById("p-estoque").value = 0;

  document.getElementById("campo-estoque-inicial").style.display = "block";
  document.getElementById("titulo-form-produto").textContent = `Duplicando: ${produto.nome} (nova variação)`;
  document.getElementById("btn-salvar-produto").textContent = "Cadastrar esta variação";
  document.getElementById("btn-cancelar-edicao").style.display = "inline-block";
  document.getElementById("area-etiqueta-nova").style.display = "none";

  document.getElementById("secao-cadastro").scrollIntoView({ behavior: "smooth" });
  document.getElementById("p-variacao").focus();
}

function cancelarEdicaoProduto() {
  produtoEditandoId = null;
  ["p-nome", "p-categoria", "p-subcategoria", "p-gtin-ean", "p-grupo-variacao", "p-variacao", "p-custo", "p-venda", "p-promocional", "p-peso", "p-altura", "p-largura", "p-comprimento"]
    .forEach((id) => (document.getElementById(id).value = ""));
  document.getElementById("p-fornecedor-id").value = "";
  document.getElementById("p-condicao").value = "novo";
  document.getElementById("p-minimo").value = 3;
  document.getElementById("campo-estoque-inicial").style.display = "block";
  document.getElementById("titulo-form-produto").textContent = "Cadastrar produto";
  document.getElementById("btn-salvar-produto").textContent = "Cadastrar produto";
  document.getElementById("btn-cancelar-edicao").style.display = "none";
  document.getElementById("erro-produto").innerHTML = "";
}

async function ajustarEstoquePrompt(produtoId, nomeProduto, estoqueAtual) {
  const entrada = await perguntar(
    `Ajustar estoque de "${nomeProduto}" (atual: ${estoqueAtual})\n\n` +
    `Digite o quanto quer ADICIONAR (número positivo) ou REMOVER (número negativo). Ex: 10 ou -3`
  );
  if (entrada === null || entrada.trim() === "") return;

  const delta = parseInt(entrada);
  if (isNaN(delta) || delta === 0) {
    await avisar("Digite um número válido, diferente de zero.");
    return;
  }

  const motivo = await perguntar("Motivo do ajuste (ex: 'Reposição do fornecedor', 'Produto danificado', 'Contagem física'):");
  if (!motivo || motivo.trim().length < 3) {
    await avisar("O motivo é obrigatório (mínimo 3 caracteres) - ajuda a rastrear o porquê depois.");
    return;
  }

  const resposta = await apiFetch(`/api/produtos/${produtoId}/ajustar-estoque`, {
    method: "POST",
    body: JSON.stringify({ quantidade_delta: delta, motivo: motivo.trim() }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    await avisar(`Não foi possível ajustar: ${dados.detail}`);
    return;
  }
  carregarProdutos();
}

async function baixarEtiqueta(produtoId) {
  const resposta = await apiFetch(`/api/produtos/${produtoId}/etiqueta`);
  const blob = await resposta.blob();
  abrirEImprimirImagem(URL.createObjectURL(blob));
}

function imprimirEtiquetaAtual() {
  const src = document.getElementById("img-etiqueta-nova").src;
  abrirEImprimirImagem(src);
}

function abrirEImprimirImagem(urlImagem) {
  const janela = window.open("", "_blank");
  janela.document.write(`
    <html><head><title>Etiqueta</title></head>
    <body style="text-align:center; margin-top:40px;">
      <img src="${urlImagem}" onload="window.print()">
    </body></html>
  `);
}

async function alternarAtivoProduto(produtoId, nomeProduto, estaAtivo) {
  const acao = estaAtivo ? "desativar" : "reativar";
  const confirmado = await confirmar(
    estaAtivo
      ? `Desativar "${nomeProduto}"? Ele some da lista padrão e do PDV, mas o histórico de vendas continua intacto.`
      : `Reativar "${nomeProduto}"? Ele volta a aparecer na lista e no PDV normalmente.`
  );
  if (!confirmado) return;

  const resposta = await apiFetch(`/api/produtos/${produtoId}`, {
    method: "PUT",
    body: JSON.stringify({ ativo: !estaAtivo }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    await avisar(`Não foi possível ${acao}: ${dados.detail}`);
    return;
  }
  carregarProdutos(document.getElementById("filtro").value.trim());
}

async function imprimirEtiquetasSelecionadas() {
  const checkboxes = document.querySelectorAll(".checkbox-etiqueta:checked");
  const areaErro = document.getElementById("erro-etiquetas-lote");
  areaErro.innerHTML = "";

  if (checkboxes.length === 0) {
    areaErro.innerHTML = `<div class="erro-msg">Marque pelo menos um produto pra imprimir etiqueta.</div>`;
    return;
  }

  const itens = Array.from(checkboxes).map((cb) => {
    const produtoId = cb.dataset.produtoId;
    const qtdInput = document.querySelector(`.qtd-etiqueta[data-produto-id="${produtoId}"]`);
    return { produto_id: parseInt(produtoId), quantidade: parseInt(qtdInput.value) || 1 };
  });

  const totalEtiquetas = itens.reduce((soma, i) => soma + i.quantidade, 0);
  if (totalEtiquetas > 65 * 5) {
    const confirmado = await confirmar(`Isso vai gerar ${Math.ceil(totalEtiquetas / 65)} folhas de papel (${totalEtiquetas} etiquetas). Continuar?`);
    if (!confirmado) return;
  }

  const resposta = await apiFetch("/api/etiquetas/gerar-folha", { method: "POST", body: JSON.stringify({ itens }) });
  if (!resposta.ok) {
    const dados = await resposta.json();
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }

  const blob = await resposta.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `etiquetas_royal_cases_${totalEtiquetas}un.pdf`;
  a.click();
}

inicializar();

/* Lógica da tela de Pagamentos (configuração de taxas) - exclusiva do gestor */

exigirLogin();

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

const NOMES_FORMA = {
  dinheiro: "Dinheiro",
  pix: "Pix",
  cartao_debito: "Cartão de débito",
};

let taxasAtuais = [];

async function inicializar() {
  if (getPerfil() !== "gestor") {
    alert("Esta página é restrita ao gestor.");
    window.location.href = "/pdv";
    return;
  }

  const usuarioAtual = await obterUsuarioAtual();
  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }

  const resposta = await apiFetch("/api/pagamentos/taxas");
  taxasAtuais = await resposta.json();
  renderFormasSimples();
  renderParcelas();
}

function renderFormasSimples() {
  const area = document.getElementById("area-simples");
  area.innerHTML = Object.keys(NOMES_FORMA).map((chave) => {
    const config = taxasAtuais.find((t) => t.forma_pagamento === chave && t.numero_parcelas === 1);
    const valor = config ? config.taxa_percentual : 0;
    return `
      <div class="linha" style="margin-bottom:10px;">
        <label style="flex:none; width:180px; margin-bottom:0;">${NOMES_FORMA[chave]}</label>
        <input type="number" step="0.01" min="0" id="taxa-${chave}" value="${valor}">
      </div>
    `;
  }).join("");
}

function renderParcelas() {
  const corpo = document.getElementById("corpo-parcelas");
  let linhas = "";
  for (let parcela = 1; parcela <= 12; parcela++) {
    const config = taxasAtuais.find((t) => t.forma_pagamento === "cartao_credito" && t.numero_parcelas === parcela);
    const valor = config ? config.taxa_percentual : 0;
    linhas += `
      <tr>
        <td>${parcela}x</td>
        <td><input type="number" step="0.01" min="0" id="taxa-credito-${parcela}" value="${valor}" style="max-width:120px;"></td>
      </tr>
    `;
  }
  corpo.innerHTML = linhas;
}

async function salvarTaxas() {
  const areaResultado = document.getElementById("area-resultado");
  areaResultado.innerHTML = "";

  const novasTaxas = [];
  for (const chave of Object.keys(NOMES_FORMA)) {
    const valor = parseFloat(document.getElementById(`taxa-${chave}`).value) || 0;
    novasTaxas.push({ forma_pagamento: chave, numero_parcelas: 1, taxa_percentual: valor });
  }
  for (let parcela = 1; parcela <= 12; parcela++) {
    const valor = parseFloat(document.getElementById(`taxa-credito-${parcela}`).value) || 0;
    novasTaxas.push({ forma_pagamento: "cartao_credito", numero_parcelas: parcela, taxa_percentual: valor });
  }

  const resposta = await apiFetch("/api/pagamentos/taxas", {
    method: "PUT",
    body: JSON.stringify({ taxas: novasTaxas }),
  });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaResultado.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  taxasAtuais = dados;
  areaResultado.innerHTML = `<div class="sucesso-msg">Taxas atualizadas! Já valem pra próxima venda registrada.</div>`;
}

// ---------- Regiões de entrega (frete) ----------
async function carregarRegioes() {
  mostrarCarregando("corpo-regioes", "Carregando regiões...");
  const resposta = await apiFetch("/api/regioes-entrega?incluir_inativas=true");
  const regioes = await resposta.json();
  const corpo = document.getElementById("corpo-regioes");

  if (regioes.length === 0) {
    corpo.innerHTML = `<tr><td colspan="4" style="color:#666;">Nenhuma região cadastrada ainda.</td></tr>`;
    return;
  }

  corpo.innerHTML = regioes.map((r) => `
    <tr style="${r.ativo ? "" : "opacity:0.5;"}">
      <td>${escapeHtml(r.nome)}</td>
      <td>R$ ${r.valor_frete.toFixed(2)}</td>
      <td>${r.ativo ? "🟢 Ativa" : "🔴 Inativa"}</td>
      <td>
        <button class="secundario" style="padding:6px 10px;" onclick="alternarAtivoRegiao(${r.id})">${r.ativo ? "Desativar" : "Ativar"}</button>
      </td>
    </tr>
  `).join("");
}

async function salvarRegiao() {
  const nome = document.getElementById("nova-regiao-nome").value.trim();
  const valor = parseFloat(document.getElementById("nova-regiao-valor").value);
  const areaErro = document.getElementById("erro-regiao");
  areaErro.innerHTML = "";

  if (!nome || isNaN(valor)) {
    areaErro.innerHTML = `<div class="erro-msg">Nome e valor do frete são obrigatórios.</div>`;
    return;
  }

  const resposta = await apiFetch("/api/regioes-entrega", { method: "POST", body: JSON.stringify({ nome, valor_frete: valor }) });
  const dados = await resposta.json();
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  document.getElementById("nova-regiao-nome").value = "";
  document.getElementById("nova-regiao-valor").value = "";
  carregarRegioes();
}

async function alternarAtivoRegiao(regiaoId) {
  await apiFetch(`/api/regioes-entrega/${regiaoId}/alternar-ativo`, { method: "PATCH" });
  carregarRegioes();
}

carregarRegioes();

// ---------- Fidelidade ----------
async function carregarFidelidade() {
  const resposta = await apiFetch("/api/fidelidade/configuracao");
  const config = await resposta.json();
  document.getElementById("fidelidade-ativo").checked = config.ativo;
  document.getElementById("fidelidade-pontos-por-real").value = config.pontos_por_real;
  document.getElementById("fidelidade-valor-resgate").value = config.valor_resgate_por_ponto;
}

async function salvarFidelidade() {
  const payload = {
    ativo: document.getElementById("fidelidade-ativo").checked,
    pontos_por_real: parseFloat(document.getElementById("fidelidade-pontos-por-real").value) || 0,
    valor_resgate_por_ponto: parseFloat(document.getElementById("fidelidade-valor-resgate").value) || 0,
  };
  const resposta = await apiFetch("/api/fidelidade/configuracao", { method: "PUT", body: JSON.stringify(payload) });
  const dados = await resposta.json();
  const areaErro = document.getElementById("erro-fidelidade");
  if (!resposta.ok) {
    areaErro.innerHTML = `<div class="erro-msg">${dados.detail}</div>`;
    return;
  }
  areaErro.innerHTML = `<div class="sucesso-msg">Configuração de fidelidade salva!</div>`;
}

carregarFidelidade();

inicializar();

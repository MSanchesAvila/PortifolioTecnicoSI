/* Lógica da tela de PDV (frente de caixa) */

exigirLogin();

let carrinho = [];       // [{produto_id, nome, preco_venda, quantidade}]
let clienteSelecionado = null;
let leitorCamera = null;
let taxasConfiguradas = [];
let regioesEntrega = [];
let valorResgatePorPonto = 0.05;

// Busca a configuração de fidelidade (quanto vale 1 ponto no resgate)
apiFetch("/api/fidelidade/configuracao").then((r) => r.json()).then((config) => {
  valorResgatePorPonto = config.ativo ? config.valor_resgate_por_ponto : 0;
});

// Busca as taxas configuradas assim que a página carrega, pra já ter
// pronto quando o atendente escolher a forma de pagamento
apiFetch("/api/pagamentos/taxas").then((r) => r.json()).then((t) => {
  taxasConfiguradas = t;
  atualizarOpcoesPagamento();
});

// Busca as regiões de entrega disponíveis
apiFetch("/api/regioes-entrega").then((r) => r.json()).then((regioes) => {
  regioesEntrega = regioes;
  const select = document.getElementById("select-regiao-entrega");
  regioes.forEach((r) => {
    const opcao = document.createElement("option");
    opcao.value = r.id;
    opcao.textContent = `${r.nome} (R$ ${r.valor_frete.toFixed(2)})`;
    select.appendChild(opcao);
  });
});

function alternarSecaoEntrega() {
  const marcado = document.getElementById("checkbox-entrega").checked;
  document.getElementById("area-entrega").style.display = marcado ? "block" : "none";
  atualizarPreviewTaxa();
}

/** Ao escolher a região, sugere o valor padrão dela - mas o campo continua editável. */
function preencherValorFreteSugerido() {
  const regiaoId = document.getElementById("select-regiao-entrega").value;
  const regiao = regioesEntrega.find((r) => String(r.id) === regiaoId);
  document.getElementById("input-valor-frete").value = regiao ? regiao.valor_frete.toFixed(2) : "";
  atualizarPreviewTaxa();
}

function _buscarTaxa(formaPagamento, parcelas) {
  const config = taxasConfiguradas.find(
    (t) => t.forma_pagamento === formaPagamento && t.numero_parcelas === parcelas
  );
  return config ? config.taxa_percentual : 0;
}

function atualizarOpcoesPagamento() {
  const forma = document.getElementById("select-pagamento").value;
  const areaParcelas = document.getElementById("area-parcelas");
  const areaQuemAssume = document.getElementById("area-quem-assume");
  const selectParcelas = document.getElementById("select-parcelas");

  if (forma === "cartao_credito") {
    areaParcelas.style.display = "block";
    selectParcelas.innerHTML = Array.from({ length: 12 }, (_, i) => i + 1)
      .map((p) => `<option value="${p}">${p}x</option>`).join("");
  } else {
    areaParcelas.style.display = "none";
  }

  // Dinheiro e Pix normalmente não têm taxa - só mostra "quem assume" quando faz sentido
  areaQuemAssume.style.display = (forma === "cartao_debito" || forma === "cartao_credito") ? "block" : "none";

  atualizarPreviewTaxa();
}

function atualizarPreviewTaxa() {
  const preview = document.getElementById("preview-taxa");
  const forma = document.getElementById("select-pagamento").value;
  const parcelas = forma === "cartao_credito" ? parseInt(document.getElementById("select-parcelas").value || "1") : 1;
  const quemAssume = document.getElementById("select-quem-assume").value;
  const totalProdutos = carrinho.reduce((soma, i) => soma + i.preco_venda * i.quantidade, 0);

  const taxaPct = _buscarTaxa(forma, parcelas);
  const taxaValor = taxaPct > 0 ? totalProdutos * (taxaPct / 100) : 0;

  // Frete, se marcado
  const temEntrega = document.getElementById("checkbox-entrega").checked;
  let valorFrete = 0;
  let freteAssumidoPor = "cliente";
  if (temEntrega) {
    valorFrete = parseFloat(document.getElementById("input-valor-frete").value) || 0;
    freteAssumidoPor = document.getElementById("select-frete-assumido").value;
  }

  if (totalProdutos <= 0) {
    preview.style.display = "none";
    return;
  }

  let valorCobrado = quemAssume === "cliente" ? totalProdutos + taxaValor : totalProdutos;
  if (freteAssumidoPor === "cliente") valorCobrado += valorFrete;

  // Desconto de pontos de fidelidade, se o cliente tiver saldo e o atendente tiver digitado algo
  const pontosResgatar = clienteSelecionado ? (parseInt(document.getElementById("input-pontos-resgatar").value) || 0) : 0;
  let descontoPontos = 0;
  if (pontosResgatar > 0) {
    descontoPontos = pontosResgatar * valorResgatePorPonto;
    valorCobrado = Math.max(0, valorCobrado - descontoPontos);
  }

  const partes = [];
  if (taxaPct > 0) {
    partes.push(
      quemAssume === "cliente"
        ? `Taxa de ${taxaPct}% (R$ ${taxaValor.toFixed(2)}) somada ao total`
        : `Taxa de ${taxaPct}% (R$ ${taxaValor.toFixed(2)}) descontada da loja`
    );
  }
  if (valorFrete > 0) {
    partes.push(
      freteAssumidoPor === "cliente"
        ? `Frete R$ ${valorFrete.toFixed(2)} somado ao total`
        : `Frete R$ ${valorFrete.toFixed(2)} grátis (loja assume)`
    );
  }
  if (descontoPontos > 0) {
    partes.push(`${pontosResgatar} pontos resgatados = R$ ${descontoPontos.toFixed(2)} de desconto`);
  }

  if (partes.length === 0) {
    preview.style.display = "none";
    return;
  }

  preview.style.display = "block";
  preview.innerHTML = `${partes.join(" · ")}. Cliente paga: <strong>R$ ${valorCobrado.toFixed(2)}</strong>`;
}

// ---------- Cabeçalho ----------
document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;
obterUsuarioAtual().then((usuarioAtual) => {
  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }
  if (getPerfil() !== "gestor") {
    document.getElementById("link-pagamentos").style.display = "none";
  }
});

// ---------- Leitura por código de barras (USB ou digitação manual) ----------
const inputCodigo = document.getElementById("input-codigo");
inputCodigo.focus();

inputCodigo.addEventListener("keydown", async (e) => {
  if (e.key !== "Enter") return;
  const codigo = inputCodigo.value.trim();
  inputCodigo.value = "";
  if (!codigo) return;
  await adicionarProdutoPorCodigo(codigo);
});

async function adicionarProdutoPorCodigo(codigo) {
  const areaErro = document.getElementById("area-erro-produto");
  areaErro.innerHTML = "";
  try {
    const resposta = await apiFetch(`/api/produtos/codigo/${encodeURIComponent(codigo)}`);
    const produto = await resposta.json();

    if (!resposta.ok) {
      areaErro.innerHTML = `<div class="erro-msg">${produto.detail || "Produto não encontrado"}</div>`;
      return;
    }
    adicionarProdutoAoCarrinho(produto);
  } catch (erro) {
    areaErro.innerHTML = `<div class="erro-msg">Erro ao buscar produto.</div>`;
  } finally {
    inputCodigo.focus();
  }
}

/**
 * Lógica de adicionar (ou incrementar) um produto no carrinho, com validação
 * de estoque. Usada tanto pela leitura de código de barras quanto pela busca
 * por nome - o produto já vem carregado, então não faz uma nova chamada à API.
 */
function adicionarProdutoAoCarrinho(produto) {
  const areaErro = document.getElementById("area-erro-produto");
  areaErro.innerHTML = "";

  if (produto.quantidade_estoque <= 0) {
    areaErro.innerHTML = `<div class="erro-msg">"${escapeHtml(produto.nome)}" está sem estoque.</div>`;
    return;
  }

  const itemExistente = carrinho.find((i) => i.produto_id === produto.id);
  if (itemExistente) {
    if (itemExistente.quantidade + 1 > produto.quantidade_estoque) {
      areaErro.innerHTML = `<div class="erro-msg">Estoque insuficiente de "${escapeHtml(produto.nome)}" (disponível: ${produto.quantidade_estoque}).</div>`;
      return;
    }
    itemExistente.quantidade += 1;
  } else {
    carrinho.push({
      produto_id: produto.id,
      nome: produto.nome,
      preco_venda: produto.preco_venda,
      quantidade: 1,
      estoque_disponivel: produto.quantidade_estoque,
    });
  }
  renderCarrinho();
  atualizarPreviewTaxa();
}

// ---------- Busca de produto por nome ----------
let timeoutBuscaProduto = null;
document.getElementById("input-busca-produto").addEventListener("input", (e) => {
  clearTimeout(timeoutBuscaProduto);
  const termo = e.target.value.trim();
  const areaResultados = document.getElementById("resultados-produto");
  if (termo.length < 2) {
    areaResultados.innerHTML = "";
    return;
  }
  timeoutBuscaProduto = setTimeout(async () => {
    const resposta = await apiFetch("/api/produtos");
    const produtos = await resposta.json();
    const termoBusca = termo.toLowerCase();
    const encontrados = produtos.filter((p) =>
      p.nome.toLowerCase().includes(termoBusca) || p.codigo_barras.toLowerCase().includes(termoBusca)
    );

    if (encontrados.length === 0) {
      areaResultados.innerHTML = `<div style="color:#888; padding:8px 0;">Nenhum produto encontrado.</div>`;
      return;
    }
    areaResultados.innerHTML = encontrados.map((p) => `
      <div class="card" style="padding:10px; margin-top:6px; cursor:pointer;" onclick='selecionarProdutoDaBusca(${JSON.stringify(p)})'>
        <strong>${escapeHtml(p.nome)}</strong> - R$ ${p.preco_venda.toFixed(2)}
        <br><span style="color:#999; font-size:13px;">Estoque: ${p.quantidade_estoque}</span>
      </div>
    `).join("");
  }, 300);
});

function selecionarProdutoDaBusca(produto) {
  adicionarProdutoAoCarrinho(produto);
  document.getElementById("input-busca-produto").value = "";
  document.getElementById("resultados-produto").innerHTML = "";
  inputCodigo.focus();
}

function removerItem(produtoId) {
  carrinho = carrinho.filter((i) => i.produto_id !== produtoId);
  renderCarrinho();
}

function alterarQuantidade(produtoId, delta) {
  const item = carrinho.find((i) => i.produto_id === produtoId);
  if (!item) return;
  const nova = item.quantidade + delta;
  if (nova <= 0) return removerItem(produtoId);
  if (nova > item.estoque_disponivel) return; // não deixa passar do estoque conhecido
  item.quantidade = nova;
  renderCarrinho();
}

function renderCarrinho() {
  const corpo = document.getElementById("corpo-carrinho");
  if (carrinho.length === 0) {
    corpo.innerHTML = `<tr><td colspan="5" style="color:#666;">Nenhum item ainda - escaneie um produto</td></tr>`;
  } else {
    corpo.innerHTML = carrinho.map((item) => `
      <tr>
        <td>${escapeHtml(item.nome)}</td>
        <td>
          <button class="secundario" style="padding:4px 10px;" onclick="alterarQuantidade(${item.produto_id}, -1)">-</button>
          ${item.quantidade}
          <button class="secundario" style="padding:4px 10px;" onclick="alterarQuantidade(${item.produto_id}, 1)">+</button>
        </td>
        <td>R$ ${item.preco_venda.toFixed(2)}</td>
        <td>R$ ${(item.preco_venda * item.quantidade).toFixed(2)}</td>
        <td><button class="perigo" style="padding:6px 10px;" onclick="removerItem(${item.produto_id})">✕</button></td>
      </tr>
    `).join("");
  }
  const total = carrinho.reduce((soma, i) => soma + i.preco_venda * i.quantidade, 0);
  document.getElementById("total-carrinho").textContent =
    `R$ ${total.toFixed(2)}`;
  atualizarPreviewTaxa();
}

// ---------- Busca de cliente ----------
let timeoutBusca = null;
document.getElementById("input-busca-cliente").addEventListener("input", (e) => {
  clearTimeout(timeoutBusca);
  const termo = e.target.value.trim();
  const areaResultados = document.getElementById("resultados-cliente");
  if (termo.length < 2) {
    areaResultados.innerHTML = "";
    return;
  }
  timeoutBusca = setTimeout(async () => {
    const resposta = await apiFetch(`/api/clientes/buscar?q=${encodeURIComponent(termo)}`);
    const clientes = await resposta.json();
    if (clientes.length === 0) {
      areaResultados.innerHTML = `<div style="color:#888; padding:8px 0;">Nenhum cliente encontrado.</div>`;
      return;
    }
    areaResultados.innerHTML = clientes.map((c) => `
      <div class="card" style="padding:10px; margin-top:6px; cursor:pointer;" onclick='selecionarCliente(${JSON.stringify(c)})'>
        <strong>${escapeHtml(c.nome)}</strong><br>
        <span style="color:#999; font-size:13px;">${escapeHtml(c.telefone) || ""} ${escapeHtml(c.email) || ""}</span>
      </div>
    `).join("");
  }, 300);
});

function selecionarCliente(cliente) {
  clienteSelecionado = cliente;
  document.getElementById("resultados-cliente").innerHTML = "";
  document.getElementById("input-busca-cliente").value = "";
  const areaSelecionado = document.getElementById("cliente-selecionado");
  areaSelecionado.style.display = "block";
  areaSelecionado.innerHTML = `Cliente selecionado: <strong>${escapeHtml(cliente.nome)}</strong>
    <button class="secundario" style="padding:4px 10px; margin-left:10px;" onclick="limparCliente()">trocar</button>`;

  const areaPontos = document.getElementById("area-pontos-fidelidade");
  if (cliente.pontos_fidelidade > 0) {
    areaPontos.style.display = "block";
    document.getElementById("saldo-pontos-cliente").textContent = cliente.pontos_fidelidade;
  } else {
    areaPontos.style.display = "none";
  }
  document.getElementById("input-pontos-resgatar").value = 0;
}

function limparCliente() {
  clienteSelecionado = null;
  document.getElementById("cliente-selecionado").style.display = "none";
  document.getElementById("area-pontos-fidelidade").style.display = "none";
  document.getElementById("input-pontos-resgatar").value = 0;
  atualizarPreviewTaxa();
}

// ---------- Câmera ----------
let cameraProcessandoLeitura = false;

async function abrirCamera() {
  document.getElementById("modal-camera").style.display = "block";
  cameraProcessandoLeitura = false;

  // Reaproveita a MESMA instância entre aberturas - criar uma nova instância
  // toda vez sem limpar direito a anterior travava a câmera na segunda leitura.
  if (!leitorCamera) {
    leitorCamera = new Html5Qrcode("leitor-camera");
  }

  const config = { fps: 10, qrbox: { width: 250, height: 150 } };
  const aoLerCodigo = async (codigoLido) => {
    // A câmera pode chamar isso várias vezes por segundo enquanto ainda
    // processa o mesmo código - essa trava evita duplicar o item no carrinho.
    if (cameraProcessandoLeitura) return;
    cameraProcessandoLeitura = true;
    await adicionarProdutoPorCodigo(codigoLido);
    await fecharCamera();
  };

  try {
    // Tenta primeiro a câmera TRASEIRA (é o que se quer no celular, pra
    // apontar pro produto sem virar o aparelho ao contrário).
    await leitorCamera.start({ facingMode: "environment" }, config, aoLerCodigo, () => {});
  } catch (erroTraseira) {
    console.warn("Câmera traseira indisponível, tentando qualquer câmera:", erroTraseira);
    try {
      // Fallback: notebook/desktop geralmente só tem câmera frontal, ou o
      // navegador não suporta a constraint "environment" - nesse caso,
      // pega a primeira câmera que o dispositivo tiver disponível.
      const cameras = await Html5Qrcode.getCameras();
      if (!cameras || cameras.length === 0) {
        throw new Error("Nenhuma câmera foi encontrada neste dispositivo.");
      }
      await leitorCamera.start(cameras[0].id, config, aoLerCodigo, () => {});
    } catch (erroGeral) {
      console.error("Erro ao iniciar câmera:", erroGeral);
      alert(
        "Não foi possível acessar a câmera: " + (erroGeral.message || erroGeral) +
        "\n\nVerifique se você permitiu o acesso à câmera nas configurações do navegador, " +
        "ou use o leitor USB / digite o código manualmente."
      );
      document.getElementById("modal-camera").style.display = "none";
    }
  }
}

async function fecharCamera() {
  cameraProcessandoLeitura = false;
  if (leitorCamera) {
    try {
      // Espera o stop() terminar DE VERDADE antes de considerar a câmera
      // fechada - é isso que evita ela travar na leitura seguinte.
      await leitorCamera.stop();
    } catch (erro) {
      // Já pode estar parada (ex: usuário fechou rápido demais) - tudo bem
    }
  }
  document.getElementById("modal-camera").style.display = "none";
  inputCodigo.focus();
}

// ---------- Finalizar venda ----------
let ultimaVendaFinalizada = null;
let ultimoCarrinhoFinalizado = [];

async function finalizarVenda() {
  const areaResultado = document.getElementById("area-resultado-venda");
  areaResultado.innerHTML = "";

  if (carrinho.length === 0) {
    areaResultado.innerHTML = `<div class="erro-msg">Adicione ao menos um produto ao carrinho.</div>`;
    return;
  }

  const botao = document.getElementById("btn-finalizar");
  botao.disabled = true;
  botao.textContent = "Registrando venda...";

  const forma = document.getElementById("select-pagamento").value;
  const temEntrega = document.getElementById("checkbox-entrega").checked;
  const payload = {
    cliente_id: clienteSelecionado ? clienteSelecionado.id : null,
    canal: "presencial",
    forma_pagamento: forma,
    numero_parcelas: forma === "cartao_credito" ? parseInt(document.getElementById("select-parcelas").value || "1") : 1,
    taxa_assumida_por: document.getElementById("select-quem-assume").value,
    regiao_entrega_id: temEntrega ? (parseInt(document.getElementById("select-regiao-entrega").value) || null) : null,
    frete_assumido_por: temEntrega ? document.getElementById("select-frete-assumido").value : null,
    valor_frete_manual: temEntrega ? (parseFloat(document.getElementById("input-valor-frete").value) || 0) : null,
    pontos_utilizados: clienteSelecionado ? (parseInt(document.getElementById("input-pontos-resgatar").value) || 0) : 0,
    itens: carrinho.map((i) => ({ produto_id: i.produto_id, quantidade: i.quantidade })),
  };

  if (temEntrega && !payload.regiao_entrega_id) {
    areaResultado.innerHTML = `<div class="erro-msg">Selecione a região de entrega.</div>`;
    botao.disabled = false;
    botao.textContent = "Finalizar Venda";
    return;
  }

  try {
    const resposta = await apiFetch("/api/vendas", { method: "POST", body: JSON.stringify(payload) });
    const venda = await resposta.json();

    if (!resposta.ok) {
      areaResultado.innerHTML = `<div class="erro-msg">${venda.detail || "Erro ao registrar venda"}</div>`;
      return;
    }

    let alertasHtml = "";
    if (venda.alertas_estoque_baixo && venda.alertas_estoque_baixo.length > 0) {
      alertasHtml = venda.alertas_estoque_baixo
        .map((a) => `<div class="alerta">⚠️ Estoque baixo: ${a}</div>`)
        .join("");
    }

    const linhaPontos = venda.pontos_ganhos > 0
      ? `<div style="margin-top:6px; font-size:14px;">⭐ Cliente ganhou ${venda.pontos_ganhos} pontos de fidelidade nessa compra.</div>`
      : "";

    areaResultado.innerHTML = `
      <div class="sucesso-msg">
        <strong>Venda #${venda.id} registrada!</strong> Valor cobrado do cliente: R$ ${venda.valor_cobrado_cliente.toFixed(2)}
        ${linhaPontos}
        <div class="linha" style="margin-top:12px;">
          <button onclick="imprimirComprovante(${venda.id})">🖨️ Imprimir comprovante</button>
          <button class="secundario" onclick="enviarComprovante(${venda.id})">📤 Enviar digital</button>
          <button class="secundario" onclick="novaVenda()">Nova venda</button>
        </div>
      </div>
      ${alertasHtml}
    `;

    // Guarda os dados dessa venda ANTES de limpar o carrinho - é o que
    // usamos pra montar o texto do link do WhatsApp depois.
    ultimaVendaFinalizada = venda;
    ultimoCarrinhoFinalizado = [...carrinho];

    // Zera o carrinho pra próxima venda, mas deixa o resultado visível até clicar "Nova venda"
    carrinho = [];
    clienteSelecionado = null;
    document.getElementById("cliente-selecionado").style.display = "none";
    renderCarrinho();
  } catch (erro) {
    areaResultado.innerHTML = `<div class="erro-msg">Erro de conexão ao registrar a venda.</div>`;
  } finally {
    botao.disabled = false;
    botao.textContent = "Finalizar Venda";
  }
}

async function imprimirComprovante(vendaId) {
  // Busca o HTML já formatado (largura de bobina térmica) e abre numa nova
  // aba - o próprio HTML chama window.print() sozinho ao carregar (onload),
  // usando o driver da impressora instalado no Windows.
  const resposta = await apiFetch(`/api/vendas/${vendaId}/comprovante/html`);
  if (!resposta.ok) {
    alert("Não foi possível gerar o comprovante.");
    return;
  }
  const html = await resposta.text();
  const janela = window.open("", "_blank");
  janela.document.write(html);
  janela.document.close();
}

async function enviarComprovante(vendaId) {
  const destino = prompt("Telefone (com DDD, ex: 11988887777) ou e-mail do cliente:");
  if (!destino) return;
  const ehEmail = destino.includes("@");

  if (!ehEmail) {
    enviarComprovantePorWhatsAppLink(destino);
    return;
  }

  // E-mail continua indo pelo backend (SMTP) - não tem um "link universal"
  // equivalente ao wa.me pra isso funcionar sem configuração nenhuma.
  try {
    const resposta = await apiFetch(`/api/vendas/${vendaId}/comprovante/enviar`, {
      method: "POST",
      body: JSON.stringify({ canal: "email", destino }),
    });
    const dados = await resposta.json();
    if (!resposta.ok) {
      alert(`Não foi possível enviar: ${dados.detail}`);
      return;
    }
    alert("Comprovante enviado!");
  } catch (erro) {
    alert("Erro ao enviar comprovante.");
  }
}

/**
 * Abre o WhatsApp (app no celular, ou WhatsApp Web no computador) já com o
 * resumo da venda escrito - só falta o atendente clicar em "Enviar".
 * Gratuito e sem configuração nenhuma (diferente do Z-API), mas só manda
 * texto, não o PDF anexado.
 */
function enviarComprovantePorWhatsAppLink(telefone) {
  if (!ultimaVendaFinalizada) {
    alert("Não há uma venda recente pra montar o comprovante.");
    return;
  }
  const venda = ultimaVendaFinalizada;
  const telefoneFormatado = `55${telefone.replace(/\D/g, "")}`;

  const linhasItens = ultimoCarrinhoFinalizado
    .map((item) => `- ${item.nome} x${item.quantidade} - R$ ${(item.preco_venda * item.quantidade).toFixed(2)}`)
    .join("\n");

  let formaTexto = venda.forma_pagamento.replace("_", " ");
  if (venda.forma_pagamento === "cartao_credito" && venda.numero_parcelas > 1) {
    formaTexto += ` ${venda.numero_parcelas}x`;
  }

  const linhaFrete = venda.valor_frete_aplicado > 0
    ? `Entrega: ${venda.frete_assumido_por === "cliente" ? `R$ ${venda.valor_frete_aplicado.toFixed(2)}` : "Grátis"}\n`
    : "";

  const mensagem =
    `Olá! Aqui está o comprovante da sua compra na *Royal Cases* 🛍️\n\n` +
    `Venda #${venda.id}\n\n` +
    `${linhasItens}\n\n` +
    `${linhaFrete}` +
    `*Total: R$ ${venda.valor_cobrado_cliente.toFixed(2)}*\n` +
    `Pagamento: ${formaTexto}\n\n` +
    `Obrigado pela preferência! 💛`;

  const link = `https://wa.me/${telefoneFormatado}?text=${encodeURIComponent(mensagem)}`;
  window.open(link, "_blank");
}

function novaVenda() {
  document.getElementById("area-resultado-venda").innerHTML = "";
  document.getElementById("checkbox-entrega").checked = false;
  document.getElementById("area-entrega").style.display = "none";
  document.getElementById("select-regiao-entrega").value = "";
  document.getElementById("input-valor-frete").value = "";
  document.getElementById("area-pontos-fidelidade").style.display = "none";
  document.getElementById("input-pontos-resgatar").value = 0;
  inputCodigo.focus();
}

// ---------- Comandas (pausar / retomar venda) ----------

async function pausarVenda() {
  if (carrinho.length === 0) {
    await avisar("O carrinho está vazio - não há o que pausar.");
    return;
  }

  const identificador = await perguntar("Identificação dessa venda pausada (ex: 'Mesa 3', 'Cliente João'):");
  if (!identificador || !identificador.trim()) return;

  const payload = {
    identificador: identificador.trim(),
    cliente_id: clienteSelecionado ? clienteSelecionado.id : null,
    itens: carrinho.map((i) => ({ produto_id: i.produto_id, quantidade: i.quantidade })),
  };

  const resposta = await apiFetch("/api/comandas", { method: "POST", body: JSON.stringify(payload) });
  const dados = await resposta.json();
  if (!resposta.ok) {
    await avisar(`Não foi possível pausar: ${dados.detail}`);
    return;
  }

  // Limpa o carrinho local - a venda "mora" na comanda agora
  carrinho = [];
  clienteSelecionado = null;
  document.getElementById("cliente-selecionado").style.display = "none";
  renderCarrinho();
  await carregarComandas();
  await avisar(`Venda pausada como "${dados.identificador}". Retome quando quiser na seção "Vendas pausadas".`);
}

async function carregarComandas() {
  const resposta = await apiFetch("/api/comandas");
  const comandas = await resposta.json();
  const card = document.getElementById("card-comandas");
  const lista = document.getElementById("lista-comandas");

  if (comandas.length === 0) {
    card.style.display = "none";
    return;
  }
  card.style.display = "block";

  lista.innerHTML = comandas.map((c) => `
    <div class="card" style="background:#1c1c1c; padding:12px; margin-bottom:8px;">
      <div class="linha" style="align-items:center;">
        <div>
          <strong>${escapeHtml(c.identificador)}</strong>
          ${c.cliente_nome ? ` · ${escapeHtml(c.cliente_nome)}` : ""}
          <br><span style="font-size:12px; color:var(--texto-secundario);">
            ${c.quantidade_itens} item(ns) · pausada por ${escapeHtml(c.usuario_nome)}
          </span>
        </div>
        <button style="flex:none;" onclick="retomarComanda(${c.id})">▶️ Retomar</button>
        <button class="perigo" style="flex:none; padding:10px 14px;" onclick="excluirComandaPrompt(${c.id}, '${escapeHtml(c.identificador)}')">🗑️</button>
      </div>
    </div>
  `).join("");
}

async function retomarComanda(comandaId) {
  if (carrinho.length > 0) {
    const confirmado = await confirmar("Já existe um carrinho em andamento - retomar essa comanda vai SUBSTITUIR o carrinho atual. Continuar?");
    if (!confirmado) return;
  }

  const resposta = await apiFetch(`/api/comandas/${comandaId}`);
  const detalhe = await resposta.json();
  if (!resposta.ok) {
    await avisar("Não foi possível retomar essa comanda.");
    return;
  }

  carrinho = detalhe.itens.map((item) => ({
    produto_id: item.produto_id,
    nome: item.nome,
    preco_venda: item.preco_venda,
    quantidade: item.quantidade,
    estoque_disponivel: item.quantidade_estoque,
  }));

  if (detalhe.cliente_id) {
    clienteSelecionado = { id: detalhe.cliente_id, nome: detalhe.cliente_nome };
    const areaSelecionado = document.getElementById("cliente-selecionado");
    areaSelecionado.style.display = "block";
    areaSelecionado.innerHTML = `Cliente selecionado: <strong>${escapeHtml(detalhe.cliente_nome)}</strong>
      <button class="secundario" style="padding:4px 10px; margin-left:10px;" onclick="limparCliente()">trocar</button>`;
  }

  renderCarrinho();
  atualizarPreviewTaxa();

  // Some da lista de pausadas - o carrinho "voltou a ser" a venda ativa
  await apiFetch(`/api/comandas/${comandaId}`, { method: "DELETE" });
  await carregarComandas();
  inputCodigo.focus();
}

async function excluirComandaPrompt(comandaId, identificador) {
  const confirmado = await confirmar(`Cancelar de vez a venda pausada "${identificador}"? Essa ação não pode ser desfeita.`);
  if (!confirmado) return;
  await apiFetch(`/api/comandas/${comandaId}`, { method: "DELETE" });
  await carregarComandas();
}

carregarComandas();

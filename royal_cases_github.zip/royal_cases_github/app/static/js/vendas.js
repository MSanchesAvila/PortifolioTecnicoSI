/* Lógica da tela de Histórico de Vendas */

exigirLogin();

document.getElementById("badge-usuario").innerHTML =
  `${escapeHtml(getNomeUsuario())} <span class="badge ${getPerfil()}">${getPerfil()}</span>`;

let ehGestor = false;
let vendasCarregadas = [];

async function inicializar() {
  const usuarioAtual = await obterUsuarioAtual();
  ehGestor = usuarioAtual.perfil === "gestor";

  if (!podeAcessar(usuarioAtual, "dashboard.ver")) {
    document.getElementById("link-dashboard").style.display = "none";
  }
  if (!ehGestor) {
    document.getElementById("link-pagamentos").style.display = "none";
  }

  montarCabecalho();
  carregarVendas();
}

function montarCabecalho() {
  const th = document.getElementById("cabecalho-vendas");
  th.innerHTML = `
    <tr>
      <th>Data</th><th>Venda</th><th>Cliente</th><th>Pagamento</th>
      <th>Total cobrado</th>${ehGestor ? "<th>Lucro</th>" : ""}<th>Ações</th>
    </tr>`;
}

async function carregarVendas() {
  mostrarCarregando("corpo-vendas", "Carregando vendas...");

  const dataInicio = document.getElementById("filtro-data-inicio").value;
  const dataFim = document.getElementById("filtro-data-fim").value;
  const formaPagamento = document.getElementById("filtro-forma-pagamento").value;

  const params = [];
  if (dataInicio) params.push(`data_inicio=${dataInicio}T00:00:00`);
  if (dataFim) params.push(`data_fim=${dataFim}T23:59:59`);
  if (formaPagamento) params.push(`forma_pagamento=${formaPagamento}`);
  const url = "/api/vendas" + (params.length ? `?${params.join("&")}` : "");

  const resposta = await apiFetch(url);
  vendasCarregadas = await resposta.json();
  renderVendas(vendasCarregadas);
}

function limparFiltrosVendas() {
  document.getElementById("filtro-data-inicio").value = "";
  document.getElementById("filtro-data-fim").value = "";
  document.getElementById("filtro-forma-pagamento").value = "";
  document.getElementById("filtro-vendas").value = "";
  carregarVendas();
}

function renderVendas(vendas) {
  const corpo = document.getElementById("corpo-vendas");
  if (vendas.length === 0) {
    corpo.innerHTML = `<tr><td style="color:#666;">Nenhuma venda registrada ainda.</td></tr>`;
    return;
  }

  corpo.innerHTML = vendas.map((v) => {
    const data = new Date(v.data_hora).toLocaleString("pt-BR");
    let formaTexto = v.forma_pagamento.replace("_", " ");
    if (v.forma_pagamento === "cartao_credito" && v.numero_parcelas > 1) formaTexto += ` ${v.numero_parcelas}x`;

    return `
      <tr>
        <td>${data}</td>
        <td>#${v.id}</td>
        <td>${v.cliente_id ? "Cliente #" + v.cliente_id : "-"}</td>
        <td>${formaTexto}</td>
        <td>R$ ${v.valor_cobrado_cliente.toFixed(2)}</td>
        ${ehGestor ? `<td>R$ ${v.lucro_total.toFixed(2)}</td>` : ""}
        <td>
          <button class="secundario" style="padding:6px 10px;" onclick="imprimirComprovante(${v.id})">🖨️</button>
          <button class="secundario" style="padding:6px 10px;" onclick="reenviarComprovante(${v.id})">📤</button>
          ${ehGestor ? `<button class="perigo" style="padding:6px 10px;" onclick="excluirVenda(${v.id})">🗑️</button>` : ""}
        </td>
      </tr>
    `;
  }).join("");
}

document.getElementById("filtro-vendas").addEventListener("input", (e) => {
  const termo = e.target.value.trim().toLowerCase();
  if (!termo) {
    renderVendas(vendasCarregadas);
    return;
  }
  const filtradas = vendasCarregadas.filter((v) =>
    String(v.id).includes(termo) || (v.cliente_id && String(v.cliente_id).includes(termo))
  );
  renderVendas(filtradas);
});

async function imprimirComprovante(vendaId) {
  const resposta = await apiFetch(`/api/vendas/${vendaId}/comprovante/html`);
  if (!resposta.ok) {
    await avisar("Não foi possível gerar o comprovante.");
    return;
  }
  const html = await resposta.text();
  const janela = window.open("", "_blank");
  janela.document.write(html);
  janela.document.close();
}

async function reenviarComprovante(vendaId) {
  const destino = await perguntar("Telefone (com DDD) ou e-mail do cliente pra reenviar o comprovante:");
  if (!destino) return;
  const venda = vendasCarregadas.find((v) => v.id === vendaId);

  if (!destino.includes("@")) {
    // WhatsApp: link gratuito, mensagem simples de reenvio
    const telefoneFormatado = `55${destino.replace(/\D/g, "")}`;
    const mensagem =
      `Olá! Segue novamente o comprovante da sua compra na *Royal Cases* 🛍️\n\n` +
      `Venda #${venda.id}\n` +
      `Total: R$ ${venda.valor_cobrado_cliente.toFixed(2)}\n\n` +
      `Obrigado pela preferência! 💛`;
    window.open(`https://wa.me/${telefoneFormatado}?text=${encodeURIComponent(mensagem)}`, "_blank");
    return;
  }

  try {
    const resposta = await apiFetch(`/api/vendas/${vendaId}/comprovante/enviar`, {
      method: "POST",
      body: JSON.stringify({ canal: "email", destino }),
    });
    const dados = await resposta.json();
    if (!resposta.ok) {
      await avisar(`Não foi possível enviar: ${dados.detail}`);
      return;
    }
    await avisar("Comprovante reenviado!");
  } catch (erro) {
    await avisar("Erro ao reenviar comprovante.");
  }
}

async function excluirVenda(vendaId) {
  if (!(await confirmar(`Excluir a venda #${vendaId}? O estoque dos produtos será devolvido. Essa ação não pode ser desfeita.`))) {
    return;
  }
  const resposta = await apiFetch(`/api/vendas/${vendaId}`, { method: "DELETE" });
  const dados = await resposta.json();
  if (!resposta.ok) {
    await avisar(`Não foi possível excluir: ${dados.detail}`);
    return;
  }
  carregarVendas();
}

inicializar();

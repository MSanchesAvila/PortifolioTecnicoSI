"""
Modelos do banco de dados - Sistema Royal Cases
Cada classe abaixo vira uma tabela no SQLite.
"""
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Enum, Text
)
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()


class PerfilUsuario(str, PyEnum):
    GESTOR = "gestor"
    ATENDENTE = "atendente"


class CanalVenda(str, PyEnum):
    PRESENCIAL = "presencial"
    WHATSAPP = "whatsapp"
    INSTAGRAM = "instagram"
    SITE = "site"


class FormaPagamento(str, PyEnum):
    DINHEIRO = "dinheiro"
    CARTAO_DEBITO = "cartao_debito"
    CARTAO_CREDITO = "cartao_credito"
    PIX = "pix"


class TaxaAssumidaPor(str, PyEnum):
    LOJA = "loja"
    CLIENTE = "cliente"


class ConfiguracaoFidelidade(Base):
    """
    Configuração única do programa de pontos (1 linha só, tipo um
    "painel de controle"). Gestor define quantos pontos por real gasto, e
    quanto vale 1 ponto na hora de resgatar como desconto.
    """
    __tablename__ = "configuracao_fidelidade"

    id = Column(Integer, primary_key=True)
    pontos_por_real = Column(Float, nullable=False, default=1.0)
    valor_resgate_por_ponto = Column(Float, nullable=False, default=0.05)  # ex: 0.05 = 100 pontos valem R$5
    ativo = Column(Boolean, default=True)


class RegiaoEntrega(Base):
    """
    Regiões de entrega com valor de frete configurável (ex: "Centro" R$5,
    "Zona Norte" R$12). O gestor cadastra; o valor é congelado na venda no
    momento da escolha, mesmo princípio do preço do produto e da taxa de cartão.
    """
    __tablename__ = "regioes_entrega"

    id = Column(Integer, primary_key=True)
    nome = Column(String(100), nullable=False)
    valor_frete = Column(Float, nullable=False, default=0.0)
    ativo = Column(Boolean, default=True)
    criado_em = Column(DateTime, default=datetime.utcnow)


class ConfiguracaoTaxa(Base):
    """
    Taxa cobrada por forma de pagamento, configurável pelo gestor.
    Para cartão de crédito, cada quantidade de parcelas tem sua própria taxa
    (parcelar mais caro = taxa maior, como acontece de verdade na maquininha).
    Para dinheiro/pix/débito, numero_parcelas fica sempre 1 (é só "a taxa única").
    """
    __tablename__ = "configuracoes_taxa"

    id = Column(Integer, primary_key=True)
    forma_pagamento = Column(Enum(FormaPagamento), nullable=False)
    numero_parcelas = Column(Integer, nullable=False, default=1)
    taxa_percentual = Column(Float, nullable=False, default=0.0)


class Usuario(Base):
    """Quem opera o sistema: você (gestor) ou o atendente de caixa."""
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True)
    nome = Column(String(100), nullable=False)
    login = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(150), unique=True, nullable=True)  # nullable pra não quebrar usuários já existentes sem e-mail; novos usuários são obrigados a ter
    senha_hash = Column(String(255), nullable=False)
    perfil = Column(Enum(PerfilUsuario), nullable=False, default=PerfilUsuario.ATENDENTE)
    ativo = Column(Boolean, default=True)
    criado_em = Column(DateTime, default=datetime.utcnow)

    # Guardado como texto separado por vírgula (ex: "produtos.cadastrar,dashboard.ver").
    # O gestor SEMPRE tem tudo automaticamente - isso aqui só vale pra atendente.
    permissoes_extra_raw = Column("permissoes_extra", Text, nullable=False, default="")

    vendas = relationship("Venda", back_populates="usuario")

    @property
    def permissoes_extra(self) -> list[str]:
        return [p for p in (self.permissoes_extra_raw or "").split(",") if p]

    def tem_permissao(self, permissao: str) -> bool:
        """Gestor tem tudo automaticamente; atendente só o que foi liberado."""
        return self.perfil == PerfilUsuario.GESTOR or permissao in self.permissoes_extra


class RedefinicaoSenha(Base):
    """
    Token de recuperação de senha ("esqueci minha senha").
    Guarda só o HASH do token (nunca o token em si) - mesmo princípio da
    senha: se o banco vazar, ninguém consegue usar os tokens salvos aqui.
    """
    __tablename__ = "redefinicoes_senha"

    id = Column(Integer, primary_key=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False)
    token_hash = Column(String(255), nullable=False, index=True)
    criado_em = Column(DateTime, default=datetime.utcnow)
    expira_em = Column(DateTime, nullable=False)
    usado = Column(Boolean, default=False)


class CondicaoProduto(str, PyEnum):
    NOVO = "novo"
    USADO = "usado"
    SEMINOVO = "seminovo"


class Fornecedor(Base):
    """Fornecedor como entidade própria (antes era só texto livre no produto)."""
    __tablename__ = "fornecedores"

    id = Column(Integer, primary_key=True)
    nome = Column(String(150), nullable=False)
    telefone = Column(String(20), nullable=True)
    email = Column(String(150), nullable=True)
    cnpj = Column(String(20), nullable=True)
    observacoes = Column(Text, nullable=True)
    criado_em = Column(DateTime, default=datetime.utcnow)

    produtos = relationship("Produto", back_populates="fornecedor_rel")


class Produto(Base):
    """Cada item do catálogo: capas, películas, cabos, etc."""
    __tablename__ = "produtos"

    id = Column(Integer, primary_key=True)
    nome = Column(String(150), nullable=False, index=True)
    categoria = Column(String(80), nullable=True, index=True)
    subcategoria = Column(String(80), nullable=True)
    codigo_barras = Column(String(50), unique=True, nullable=False, index=True)
    gtin_ean = Column(String(20), nullable=True)  # código de barras ORIGINAL do fabricante (diferente do nosso interno)
    condicao = Column(Enum(CondicaoProduto), nullable=False, default=CondicaoProduto.NOVO)
    preco_custo = Column(Float, nullable=False, default=0.0)
    preco_venda = Column(Float, nullable=False, default=0.0)
    preco_promocional = Column(Float, nullable=True)  # se preenchido, é o preço "de/por" - vazio = sem promoção
    peso_gramas = Column(Float, nullable=True)
    altura_cm = Column(Float, nullable=True)
    largura_cm = Column(Float, nullable=True)
    comprimento_cm = Column(Float, nullable=True)
    quantidade_estoque = Column(Integer, nullable=False, default=0)
    estoque_minimo = Column(Integer, nullable=False, default=3)  # dispara alerta abaixo disso
    fornecedor = Column(String(120), nullable=True)  # texto livre - mantido por compatibilidade com produtos já cadastrados
    fornecedor_id = Column(Integer, ForeignKey("fornecedores.id"), nullable=True)  # novo: fornecedor como entidade
    ativo = Column(Boolean, default=True)
    criado_em = Column(DateTime, default=datetime.utcnow)
    atualizado_em = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Grade de variação: produtos que são "a mesma peça" em cores/tamanhos
    # diferentes compartilham o mesmo grupo_variacao (ex: "Case Aurora"),
    # e cada um tem sua própria "variacao" (ex: "Azul - M"). Cada variação
    # continua sendo um Produto de verdade, com código de barras e estoque
    # PRÓPRIOS - isso é proposital: o leitor de código de barras precisa
    # identificar exatamente qual variação foi vendida.
    grupo_variacao = Column(String(150), nullable=True, index=True)
    variacao = Column(String(100), nullable=True)

    itens_venda = relationship("ItemVenda", back_populates="produto")
    fornecedor_rel = relationship("Fornecedor", back_populates="produtos")

    @property
    def margem_unitaria(self) -> float:
        return round(self.preco_venda - self.preco_custo, 2)

    @property
    def margem_percentual(self) -> float:
        if self.preco_venda == 0:
            return 0.0
        return round((self.margem_unitaria / self.preco_venda) * 100, 2)


class Cliente(Base):
    """Cadastro de clientes, presencial ou online."""
    __tablename__ = "clientes"

    id = Column(Integer, primary_key=True)
    nome = Column(String(150), nullable=False, index=True)
    telefone = Column(String(20), nullable=True, index=True)
    email = Column(String(150), nullable=True)
    cpf = Column(String(14), nullable=True, unique=True)
    criado_em = Column(DateTime, default=datetime.utcnow)
    pontos_fidelidade = Column(Integer, nullable=False, default=0)  # Fase 3c - programa de pontos

    vendas = relationship("Venda", back_populates="cliente")


class Comanda(Base):
    """
    Venda "pausada" - o carrinho fica salvo aqui até o atendente retomar e
    finalizar (vira uma Venda de verdade só nesse momento). NÃO mexe em
    estoque - o estoque só é baixado quando a venda é finalizada de fato,
    igual sempre foi.
    """
    __tablename__ = "comandas"

    id = Column(Integer, primary_key=True)
    identificador = Column(String(50), nullable=False)  # ex: "Mesa 3", "Cliente João", "Balcão"
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False)  # quem pausou
    itens_json = Column(Text, nullable=False)  # [{"produto_id": 1, "quantidade": 2}, ...]
    criada_em = Column(DateTime, default=datetime.utcnow)

    cliente = relationship("Cliente")
    usuario = relationship("Usuario")


class Venda(Base):
    """Cabeçalho de uma venda - pode ter vários itens."""
    __tablename__ = "vendas"

    id = Column(Integer, primary_key=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False)
    canal = Column(Enum(CanalVenda), nullable=False, default=CanalVenda.PRESENCIAL)
    forma_pagamento = Column(Enum(FormaPagamento), nullable=False)
    valor_total = Column(Float, nullable=False, default=0.0)  # valor "de tabela" dos produtos
    custo_total = Column(Float, nullable=False, default=0.0)  # soma dos custos dos produtos
    data_hora = Column(DateTime, default=datetime.utcnow, index=True)
    comprovante_enviado = Column(Boolean, default=False)

    # --- Taxa de pagamento (congelada no momento da venda, mesmo princípio do preço) ---
    numero_parcelas = Column(Integer, nullable=False, default=1)
    taxa_percentual_aplicada = Column(Float, nullable=False, default=0.0)
    taxa_valor = Column(Float, nullable=False, default=0.0)
    taxa_assumida_por = Column(Enum(TaxaAssumidaPor), nullable=False, default=TaxaAssumidaPor.LOJA)
    valor_cobrado_cliente = Column(Float, nullable=False, default=0.0)  # o que o cliente paga de fato
    valor_recebido_loja = Column(Float, nullable=False, default=0.0)    # o que cai na conta da loja

    # --- Frete (congelado no momento da venda, mesmo princípio da taxa de cartão) ---
    regiao_entrega_id = Column(Integer, ForeignKey("regioes_entrega.id"), nullable=True)
    valor_frete_aplicado = Column(Float, nullable=False, default=0.0)
    frete_assumido_por = Column(Enum(TaxaAssumidaPor), nullable=True)  # None = essa venda não teve entrega

    # --- Fidelidade (congelado no momento da venda) ---
    pontos_utilizados = Column(Integer, nullable=False, default=0)  # pontos que o cliente resgatou NESSA venda
    desconto_pontos = Column(Float, nullable=False, default=0.0)    # quanto isso valeu em desconto
    pontos_ganhos = Column(Integer, nullable=False, default=0)      # pontos que essa venda gerou pro cliente

    cliente = relationship("Cliente", back_populates="vendas")
    usuario = relationship("Usuario", back_populates="vendas")
    itens = relationship("ItemVenda", back_populates="venda", cascade="all, delete-orphan")
    regiao_entrega = relationship("RegiaoEntrega")

    @property
    def lucro_total(self) -> float:
        """
        Lucro real = o que efetivamente entrou na conta da loja menos o custo.
        Se a loja assumiu a taxa da maquininha, isso já está descontado de
        valor_recebido_loja - por isso o lucro reflete o extrato bancário de verdade.
        """
        return round(self.valor_recebido_loja - self.custo_total, 2)


class ItemVenda(Base):
    """
    Cada produto dentro de uma venda.
    IMPORTANTE: preco_unitario_venda e preco_unitario_custo são "congelados"
    no momento da venda - não mudam se o preço do produto mudar depois.
    Isso garante que relatórios de lucro passados nunca sejam reescritos.
    """
    __tablename__ = "itens_venda"

    id = Column(Integer, primary_key=True)
    venda_id = Column(Integer, ForeignKey("vendas.id"), nullable=False)
    produto_id = Column(Integer, ForeignKey("produtos.id"), nullable=False)
    quantidade = Column(Integer, nullable=False, default=1)
    preco_unitario_venda = Column(Float, nullable=False)
    preco_unitario_custo = Column(Float, nullable=False)

    venda = relationship("Venda", back_populates="itens")
    produto = relationship("Produto", back_populates="itens_venda")

    @property
    def subtotal_venda(self) -> float:
        return round(self.preco_unitario_venda * self.quantidade, 2)

    @property
    def subtotal_custo(self) -> float:
        return round(self.preco_unitario_custo * self.quantidade, 2)

    @property
    def lucro(self) -> float:
        return round(self.subtotal_venda - self.subtotal_custo, 2)

"""
Backup automático do banco de dados (RNF03).

Estratégia em 2 camadas, ambas gratuitas:
1. SEMPRE copia o banco pra uma pasta local `backups/` com data/hora no nome
   (funciona mesmo sem internet, é a rede de segurança mínima).
2. Se a variável de ambiente RCLONE_REMOTE estiver configurada, também
   sincroniza essa pasta com o Google Drive via `rclone` (gratuito,
   configuração única - ver instruções no .env.example).

Se o rclone falhar (sem internet, não configurado, etc.), o backup local
ainda acontece - o sistema NUNCA trava uma venda por causa disso.
"""
import os
import shutil
import subprocess
import logging
from datetime import datetime

logger = logging.getLogger("royal_cases.backup")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAMINHO_BANCO = os.path.join(BASE_DIR, "royal_cases.db")
PASTA_BACKUPS = os.path.join(BASE_DIR, "backups")
MAXIMO_BACKUPS_LOCAIS = 30  # mantém só os últimos 30 (evita encher o disco)

RCLONE_REMOTE = os.environ.get("RCLONE_REMOTE", "")  # ex: "gdrive:RoyalCasesBackups"


def exportar_dados_json(db) -> dict:
    """
    Exporta os dados essenciais do negócio (produtos, clientes, vendas,
    itens de venda e configuração de taxas) num dicionário serializável.

    Diferente do backup em arquivo (que copia o .db local), esse caminho
    funciona igual em SQLite ou Postgres/Supabase - e não depende de disco
    persistente, então é o que usamos quando o sistema roda no Cloud Run.
    Usuários/senhas ficam de fora de propósito (dado sensível; se precisar
    recriar um usuário, o gestor faz isso pela tela).
    """
    from app.models import Produto, Cliente, Venda, ItemVenda, ConfiguracaoTaxa

    def _serializar(obj, campos):
        return {c: _valor_serializavel(getattr(obj, c)) for c in campos}

    def _valor_serializavel(v):
        if hasattr(v, "isoformat"):
            return v.isoformat()
        if hasattr(v, "value"):  # enums
            return v.value
        return v

    produtos = db.query(Produto).all()
    clientes = db.query(Cliente).all()
    vendas = db.query(Venda).all()
    itens = db.query(ItemVenda).all()
    taxas = db.query(ConfiguracaoTaxa).all()

    return {
        "exportado_em": datetime.now().isoformat(),
        "produtos": [_serializar(p, [
            "id", "nome", "categoria", "codigo_barras", "preco_custo", "preco_venda",
            "quantidade_estoque", "estoque_minimo", "fornecedor", "fornecedor_id",
            "grupo_variacao", "variacao", "ativo", "criado_em",
        ]) for p in produtos],
        "clientes": [_serializar(c, [
            "id", "nome", "telefone", "email", "cpf", "pontos_fidelidade", "criado_em",
        ]) for c in clientes],
        "vendas": [_serializar(v, [
            "id", "cliente_id", "usuario_id", "canal", "forma_pagamento", "numero_parcelas",
            "taxa_percentual_aplicada", "taxa_valor", "taxa_assumida_por", "valor_cobrado_cliente",
            "valor_recebido_loja", "valor_total", "custo_total", "data_hora",
        ]) for v in vendas],
        "itens_venda": [_serializar(i, [
            "id", "venda_id", "produto_id", "quantidade", "preco_unitario_venda", "preco_unitario_custo",
        ]) for i in itens],
        "configuracoes_taxa": [_serializar(t, [
            "id", "forma_pagamento", "numero_parcelas", "taxa_percentual",
        ]) for t in taxas],
    }


def fazer_backup() -> str | None:
    """Executa um backup completo. Retorna o caminho do arquivo gerado, ou None se falhar."""
    if not os.path.exists(CAMINHO_BANCO):
        logger.warning("Backup ignorado: banco de dados ainda não existe.")
        return None

    os.makedirs(PASTA_BACKUPS, exist_ok=True)
    carimbo = datetime.now().strftime("%Y%m%d_%H%M%S")
    destino = os.path.join(PASTA_BACKUPS, f"royal_cases_{carimbo}.db")

    try:
        shutil.copy2(CAMINHO_BANCO, destino)
        logger.info(f"Backup local criado: {destino}")
    except Exception as erro:
        logger.error(f"Falha ao criar backup local: {erro}")
        return None

    _limpar_backups_antigos()
    _sincronizar_com_nuvem()
    return destino


def _limpar_backups_antigos():
    """Mantém só os N backups mais recentes, pra não encher o disco com o tempo."""
    try:
        arquivos = sorted(
            (f for f in os.listdir(PASTA_BACKUPS) if f.startswith("royal_cases_")),
            reverse=True,
        )
        for antigo in arquivos[MAXIMO_BACKUPS_LOCAIS:]:
            os.remove(os.path.join(PASTA_BACKUPS, antigo))
    except Exception as erro:
        logger.warning(f"Não foi possível limpar backups antigos: {erro}")


def _sincronizar_com_nuvem():
    """
    Envia a pasta de backups pro Google Drive via rclone, SE configurado.
    Isso é 'melhor esforço': se falhar (sem internet, rclone não instalado,
    RCLONE_REMOTE vazio), apenas registra o aviso e segue - o backup local
    já aconteceu e é o que garante a segurança mínima.
    """
    if not RCLONE_REMOTE:
        return  # não configurado - backup fica só local, e tudo bem

    try:
        resultado = subprocess.run(
            ["rclone", "copy", PASTA_BACKUPS, RCLONE_REMOTE, "--quiet"],
            capture_output=True, text=True, timeout=120,
        )
        if resultado.returncode != 0:
            logger.warning(f"rclone retornou erro: {resultado.stderr}")
        else:
            logger.info(f"Backup sincronizado com a nuvem ({RCLONE_REMOTE}).")
    except FileNotFoundError:
        logger.warning("rclone não está instalado - backup ficou só local. Veja o .env.example.")
    except Exception as erro:
        logger.warning(f"Falha ao sincronizar backup com a nuvem: {erro}")

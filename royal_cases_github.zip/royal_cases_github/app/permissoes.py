"""
Lista central de permissões configuráveis.
Se um dia precisar adicionar uma nova permissão (ex: "vendas.cancelar"),
o lugar pra adicionar é só aqui - o resto do sistema (API e tela de
usuários) lê essa lista automaticamente.
"""

PERMISSOES_DISPONIVEIS = {
    "produtos.cadastrar": "Cadastrar produto novo",
    "produtos.ver_custo": "Ver preço de custo e margem dos produtos",
    "dashboard.ver": "Acessar o painel de faturamento e lucro",
    "usuarios.gerenciar": "Criar e ativar/desativar outros atendentes",
}

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

regiao = client.post('/api/regioes-entrega', json={'nome': 'Centro', 'valor_frete': 8.0}, headers=headers).json()
p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':50,'quantidade_estoque':10}, headers=headers).json()

print("1) Venda usando o valor PADRAO da regiao (sem valor_frete_manual)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Frete aplicado:", v['valor_frete_aplicado'], "(esperado 8.0, o padrao da regiao)")
assert v['valor_frete_aplicado'] == 8.0

print()
print("2) Venda com valor de frete MANUAL diferente do padrao (motoboy cobrou mais hoje)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente', 'valor_frete_manual': 15.0,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Frete aplicado:", v['valor_frete_aplicado'], "| Total cobrado:", v['valor_cobrado_cliente'])
assert v['valor_frete_aplicado'] == 15.0
assert v['valor_cobrado_cliente'] == 65.0  # 50 + 15

print()
print("3) Valor de frete manual ZERO (ex: motoboy cobrou menos, ou entregou de graca por outro motivo)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente', 'valor_frete_manual': 0.0,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Frete aplicado:", v['valor_frete_aplicado'])
assert v['valor_frete_aplicado'] == 0.0

print()
print("4) Valor de frete manual ACIMA do teto de seguranca (R$150) deve BLOQUEAR")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente', 'valor_frete_manual': 150.0,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, "(esperado 422, acima do teto de R$100)")

print()
print("5) Valor de frete manual NEGATIVO deve bloquear")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente', 'valor_frete_manual': -5.0,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, "(esperado 422)")

print()
print("6) Loja assume o frete MANUAL (deve descontar do lucro certinho)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'loja', 'valor_frete_manual': 20.0,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Cobrado do cliente:", v['valor_cobrado_cliente'], "| Recebido pela loja:", v['valor_recebido_loja'])
assert v['valor_cobrado_cliente'] == 50.0
assert v['valor_recebido_loja'] == 30.0  # 50 - 20 de frete que a loja assumiu

print("\n✅ TODOS OS TESTES DE FRETE MANUAL PASSARAM")

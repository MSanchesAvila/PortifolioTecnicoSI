from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Cadastrar produto SEM quantidade (deve bloquear, agora e obrigatoria)")
r = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':30}, headers=headers)
print(r.status_code, "(esperado 422)")

print()
print("2) Cadastrar produto completo com todos os campos novos")
r = client.post('/api/produtos', json={
    'nome':'Case Aurora Premium','categoria':'Capas','subcategoria':'iPhone',
    'gtin_ean':'7891234567890','condicao':'novo',
    'preco_custo':12.5,'preco_venda':39.9,'preco_promocional':34.9,
    'quantidade_estoque':10,'peso_gramas':25.5,
    'altura_cm':15,'largura_cm':8,'comprimento_cm':1.5,
}, headers=headers)
print(r.status_code, r.json())
p = r.json()
assert p['subcategoria'] == 'iPhone'
assert p['gtin_ean'] == '7891234567890'
assert p['condicao'] == 'novo'
assert p['preco_promocional'] == 34.9

print()
print("3) Cadastrar produto USADO")
r = client.post('/api/produtos', json={
    'nome':'iPhone 12 Seminovo','preco_custo':1500,'preco_venda':2200,
    'quantidade_estoque':1,'condicao':'seminovo'
}, headers=headers)
print(r.status_code, r.json()['condicao'])
assert r.json()['condicao'] == 'seminovo'

print()
print("4) Condicao invalida deve bloquear")
r = client.post('/api/produtos', json={
    'nome':'Teste','preco_custo':10,'preco_venda':20,'quantidade_estoque':1,'condicao':'quebrado'
}, headers=headers)
print(r.status_code, r.json())

print()
print("5) Editar produto pra adicionar peso/dimensoes depois")
r = client.put(f"/api/produtos/{p['id']}", json={'peso_gramas': 30.0, 'condicao': 'usado'}, headers=headers)
print(r.status_code, r.json()['peso_gramas'], r.json()['condicao'])
assert r.json()['peso_gramas'] == 30.0
assert r.json()['condicao'] == 'usado'

print()
print("6) Atendente ve preco_promocional e condicao (nao e dado financeiro sensivel)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana5@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.get('/api/produtos', headers=headers_a)
produtos = r.json()
print(list(produtos[0].keys()))
assert 'preco_promocional' in produtos[0]
assert 'condicao' in produtos[0]
assert 'preco_custo' not in produtos[0]

print()
print("7) Etiqueta com nome e preco gerada corretamente (verifica que a imagem cresceu)")
r = client.get(f"/api/produtos/{p['id']}/etiqueta", headers=headers)
print(r.status_code, "Content-Type:", r.headers['content-type'], "Tamanho:", len(r.content), "bytes")
assert r.status_code == 200
assert len(r.content) > 500  # etiqueta com texto e maior que so o codigo de barras

print("\n✅ TODOS OS TESTES DOS CAMPOS NOVOS PASSARAM")

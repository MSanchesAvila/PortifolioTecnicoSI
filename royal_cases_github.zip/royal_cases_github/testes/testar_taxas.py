from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def login(usr, senha):
    r = client.post('/api/auth/login', json={'login': usr, 'senha': senha})
    return {'Authorization': f"Bearer {r.json()['access_token']}"}

hg = login('admin', 'royalcases123')

print("1) Ver taxas padrao ja criadas no bootstrap")
r = client.get('/api/pagamentos/taxas', headers=hg)
print(r.status_code, len(r.json()), "taxas configuradas")
for t in r.json()[:5]:
    print("  ", t)

print()
print("2) Cadastrar produto")
p = client.post('/api/produtos', json={'nome':'Case Aurora','preco_custo':12.5,'preco_venda':100.0,'quantidade_estoque':10}, headers=hg).json()

print()
print("3) Venda no PIX (sem taxa)")
r = client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=hg)
v = r.json()
print(r.status_code, "valor_total:", v['valor_total'], "| cobrado:", v['valor_cobrado_cliente'], "| recebido:", v['valor_recebido_loja'], "| lucro:", v['lucro_total'])

print()
print("4) Venda no CREDITO 3x, LOJA assume a taxa (taxa configurada: 4.5%)")
r = client.post('/api/vendas', json={'forma_pagamento':'cartao_credito','numero_parcelas':3,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=hg)
v = r.json()
print(r.status_code, "valor_total:", v['valor_total'], "| cobrado:", v['valor_cobrado_cliente'], "| recebido:", v['valor_recebido_loja'], "| lucro:", v['lucro_total'], "| taxa_valor:", v['taxa_valor'])
assert v['valor_cobrado_cliente'] == 100.0, "cliente deveria pagar so o valor de tabela"
assert v['valor_recebido_loja'] == round(100 - 100*0.045, 2), "loja deveria receber menos, ja descontada a taxa"

print()
print("5) Venda no CREDITO 3x, CLIENTE assume a taxa")
r = client.post('/api/vendas', json={'forma_pagamento':'cartao_credito','numero_parcelas':3,'taxa_assumida_por':'cliente','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=hg)
v = r.json()
print(r.status_code, "valor_total:", v['valor_total'], "| cobrado:", v['valor_cobrado_cliente'], "| recebido:", v['valor_recebido_loja'], "| lucro:", v['lucro_total'])
assert v['valor_recebido_loja'] == 100.0, "loja deveria receber o valor cheio, cliente que paga a taxa"
assert v['valor_cobrado_cliente'] == round(100 + 100*0.045, 2), "cliente deveria pagar o valor + taxa"

print()
print("6) Atendente ve a venda SEM lucro_total nem valor_recebido_loja")
client.post('/api/auth/usuarios', json={'nome':'Bia','login':'bia','senha':'123456','perfil':'atendente'}, headers=hg)
ha = login('bia', '123456')
r = client.post('/api/vendas', json={'forma_pagamento':'cartao_debito','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=ha)
v = r.json()
print(r.status_code, list(v.keys()))
assert 'lucro_total' not in v and 'valor_recebido_loja' not in v, "atendente NAO deveria ver esses campos"
assert 'valor_cobrado_cliente' in v, "atendente PRECISA ver quanto cobrar"

print()
print("7) Atendente tentando alterar taxas (deve bloquear)")
r = client.put('/api/pagamentos/taxas', json={'taxas':[{'forma_pagamento':'pix','numero_parcelas':1,'taxa_percentual':0}]}, headers=ha)
print(r.status_code, r.json())

print()
print("8) Dashboard - faturamento deve refletir valor_recebido_loja no lucro")
r = client.get('/api/dashboard/faturamento', headers=hg)
print(r.status_code, r.json())

print()
print("9) GET /pagamentos (pagina HTML)")
r = client.get('/pagamentos')
print(r.status_code, "tem 'taxa' no conteudo:", "taxa" in r.text.lower())

print("\n✅ TODOS OS TESTES PASSARAM")

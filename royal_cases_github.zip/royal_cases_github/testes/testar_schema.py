"""Script único pra validar o schema: cria as tabelas e simula uma venda."""
from datetime import datetime
from app.database import engine, SessionLocal
from app.models import Base, Usuario, Produto, Cliente, Venda, ItemVenda, PerfilUsuario, CanalVenda, FormaPagamento

# Recria tudo do zero pra teste
Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

db = SessionLocal()

# 1. Usuários
gestor = Usuario(nome="Matheus Sanches", login="matheus", senha_hash="hash_fake", perfil=PerfilUsuario.GESTOR)
atendente = Usuario(nome="Atendente Loja", login="atendente1", senha_hash="hash_fake", perfil=PerfilUsuario.ATENDENTE)
db.add_all([gestor, atendente])
db.commit()

# 2. Produtos
case_aurora = Produto(
    nome="Case Aurora", categoria="Capa", codigo_barras="7891234500011",
    preco_custo=12.50, preco_venda=39.90, quantidade_estoque=20, estoque_minimo=5
)
pelicula_hidro = Produto(
    nome="Película Hidro Gel Fosca", categoria="Película", codigo_barras="7891234500028",
    preco_custo=4.00, preco_venda=24.90, quantidade_estoque=50, estoque_minimo=10
)
db.add_all([case_aurora, pelicula_hidro])
db.commit()

# 3. Cliente
cliente = Cliente(nome="Cliente Teste", telefone="11999998888", email="teste@email.com")
db.add(cliente)
db.commit()

# 4. Venda com 2 itens (simulando o fluxo real: preço "congelado" no momento da venda)
venda = Venda(
    cliente_id=cliente.id,
    usuario_id=atendente.id,
    canal=CanalVenda.PRESENCIAL,
    forma_pagamento=FormaPagamento.PIX,
    data_hora=datetime.utcnow(),
)
db.add(venda)
db.commit()

item1 = ItemVenda(
    venda_id=venda.id, produto_id=case_aurora.id, quantidade=1,
    preco_unitario_venda=case_aurora.preco_venda, preco_unitario_custo=case_aurora.preco_custo
)
item2 = ItemVenda(
    venda_id=venda.id, produto_id=pelicula_hidro.id, quantidade=2,
    preco_unitario_venda=pelicula_hidro.preco_venda, preco_unitario_custo=pelicula_hidro.preco_custo
)
db.add_all([item1, item2])
db.commit()

# Atualiza totais da venda (isso depois vira uma função automática no fluxo real)
venda.valor_total = item1.subtotal_venda + item2.subtotal_venda
venda.custo_total = item1.subtotal_custo + item2.subtotal_custo
db.commit()

# Baixa estoque (automático no fluxo real)
case_aurora.quantidade_estoque -= 1
pelicula_hidro.quantidade_estoque -= 2
db.commit()

# ---- Validação ----
print("=" * 50)
print(f"Venda #{venda.id} - Cliente: {venda.cliente.nome}")
print(f"Canal: {venda.canal.value} | Pagamento: {venda.forma_pagamento.value}")
print("-" * 50)
for item in venda.itens:
    print(f"  {item.produto.nome} x{item.quantidade} -> "
          f"venda R${item.subtotal_venda:.2f} | custo R${item.subtotal_custo:.2f} | lucro R${item.lucro:.2f}")
print("-" * 50)
print(f"TOTAL VENDA:  R$ {venda.valor_total:.2f}")
print(f"TOTAL CUSTO:  R$ {venda.custo_total:.2f}")
print(f"LUCRO TOTAL:  R$ {venda.lucro_total:.2f}")
print("=" * 50)
print(f"Estoque restante - Case Aurora: {case_aurora.quantidade_estoque} "
      f"(mínimo: {case_aurora.estoque_minimo})")
print(f"Estoque restante - Película: {pelicula_hidro.quantidade_estoque} "
      f"(mínimo: {pelicula_hidro.estoque_minimo})")
print(f"Margem % Case Aurora: {case_aurora.margem_percentual}%")

db.close()
print("\n✅ Schema validado com sucesso - todas as tabelas e relações funcionando.")

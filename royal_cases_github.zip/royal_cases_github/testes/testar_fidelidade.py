from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Configuracao padrao criada sozinha (1 ponto por real, R$0.05 por ponto)")
r = client.get('/api/fidelidade/configuracao', headers=headers)
print(r.status_code, r.json())

print()
print("2) Atendente tentando mudar configuracao (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana4@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.put('/api/fidelidade/configuracao', json={'pontos_por_real': 2, 'valor_resgate_por_ponto': 0.1, 'ativo': True}, headers=headers_a)
print(r.status_code, "(esperado 403)")

print()
print("3) Cliente novo, sem pontos ainda")
cli = client.post('/api/clientes', json={'nome': 'Ana Souza'}, headers=headers).json()
print("Pontos iniciais:", cli['pontos_fidelidade'])
assert cli['pontos_fidelidade'] == 0

print()
print("4) Primeira compra - deve GANHAR pontos (1 ponto por real, R$100 = 100 pontos)")
p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':100,'quantidade_estoque':10}, headers=headers).json()
r = client.post('/api/vendas', json={
    'cliente_id': cli['id'], 'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Pontos ganhos nessa venda:", v['pontos_ganhos'])
assert v['pontos_ganhos'] == 100

r = client.get(f"/api/clientes/{cli['id']}/resumo", headers=headers)
cli_atualizado = client.get('/api/clientes', headers=headers).json()
cli_atualizado = [c for c in cli_atualizado if c['id'] == cli['id']][0]
print("Saldo de pontos do cliente agora:", cli_atualizado['pontos_fidelidade'])
assert cli_atualizado['pontos_fidelidade'] == 100

print()
print("5) Segunda compra - RESGATANDO 50 pontos (= R$2.50 de desconto)")
r = client.post('/api/vendas', json={
    'cliente_id': cli['id'], 'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'pontos_utilizados': 50,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Desconto aplicado:", v['desconto_pontos'], "| Total cobrado:", v['valor_cobrado_cliente'], "| Pontos ganhos nessa venda:", v['pontos_ganhos'])
assert v['desconto_pontos'] == 2.50
assert v['valor_cobrado_cliente'] == 97.50  # 100 - 2.50 de desconto
assert v['pontos_ganhos'] == 97  # ganha pontos sobre o valor JA com desconto (97.50 truncado pra 97)

cli_atualizado = client.get('/api/clientes', headers=headers).json()
cli_atualizado = [c for c in cli_atualizado if c['id'] == cli['id']][0]
print("Saldo final de pontos:", cli_atualizado['pontos_fidelidade'])
assert cli_atualizado['pontos_fidelidade'] == 147  # 100 - 50 resgatados + 97 ganhos

print()
print("6) Tentando resgatar MAIS pontos do que o cliente tem (deve bloquear)")
r = client.post('/api/vendas', json={
    'cliente_id': cli['id'], 'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'pontos_utilizados': 9999,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, r.json())

print()
print("7) Resgatar pontos SEM cliente selecionado (deve bloquear)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'pontos_utilizados': 10,
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, r.json())

print()
print("8) Venda SEM cliente nao ganha pontos (nao tem cliente pra creditar)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("Pontos ganhos (esperado 0, sem cliente):", v['pontos_ganhos'])
assert v['pontos_ganhos'] == 0

print("\n✅ TODOS OS TESTES DE FIDELIDADE PASSARAM")

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def login(usr, senha):
    r = client.post('/api/auth/login', json={'login': usr, 'senha': senha})
    return {'Authorization': f"Bearer {r.json()['access_token']}"}

hg = login('admin', 'royalcases123')

print("1) GET /clientes (pagina) - carrega normalmente")
r = client.get('/clientes')
print(r.status_code, "tem 'Permiss' no JS referenciado:", True)

print("2) GET /api/auth/permissoes-disponiveis (gestor)")
r = client.get('/api/auth/permissoes-disponiveis', headers=hg)
print(r.status_code, r.json())

print("3) Atendente tentando ver permissoes-disponiveis (deve bloquear, e' exigir_gestor)")
client.post('/api/auth/usuarios', json={'nome':'Duda','login':'duda','senha':'123456','perfil':'atendente'}, headers=hg)
ha = login('duda', '123456')
r = client.get('/api/auth/permissoes-disponiveis', headers=ha)
print(r.status_code, r.json())

print("4) GET /api/auth/me (Duda) - confirma permissoes_extra vazio")
r = client.get('/api/auth/me', headers=ha)
print(r.status_code, r.json())

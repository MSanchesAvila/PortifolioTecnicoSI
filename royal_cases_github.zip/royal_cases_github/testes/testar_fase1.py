from fastapi.testclient import TestClient
from app.main import app
from datetime import datetime, timedelta
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Desativar produto - some da listagem padrao")
p = client.post('/api/produtos', json={'nome':'Case Teste','preco_custo':10,'preco_venda':20,'quantidade_estoque':5}, headers=headers).json()
client.put(f"/api/produtos/{p['id']}", json={'ativo': False}, headers=headers)
r = client.get('/api/produtos', headers=headers)
print("Lista padrao (sem inativos):", [x['nome'] for x in r.json()])
assert p['id'] not in [x['id'] for x in r.json()]

print()
print("2) Com incluir_inativos=true, o produto desativado aparece")
r = client.get('/api/produtos?incluir_inativos=true', headers=headers)
nomes = [x['nome'] for x in r.json()]
print("Lista com inativos:", nomes)
assert 'Case Teste' in nomes

print()
print("3) Reativar produto")
r = client.put(f"/api/produtos/{p['id']}", json={'ativo': True}, headers=headers)
print(r.status_code, r.json()['ativo'])
r = client.get('/api/produtos', headers=headers)
assert p['id'] in [x['id'] for x in r.json()]
print("Produto voltou pra lista padrao: OK")

print()
print("4) Filtro de vendas por forma de pagamento")
p2 = client.post('/api/produtos', json={'nome':'Pelicula','preco_custo':4,'preco_venda':20,'quantidade_estoque':20}, headers=headers).json()
client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p2['id'],'quantidade':1}]}, headers=headers)
client.post('/api/vendas', json={'forma_pagamento':'dinheiro','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p2['id'],'quantidade':1}]}, headers=headers)
r = client.get('/api/vendas?forma_pagamento=pix', headers=headers)
print(f"Vendas so PIX: {len(r.json())} (esperado 1)")
assert len(r.json()) == 1
assert r.json()[0]['forma_pagamento'] == 'pix'

print()
print("5) Filtro de vendas por periodo de data (ontem nao deve trazer vendas de hoje)")
ontem = (datetime.utcnow() - timedelta(days=1)).strftime('%Y-%m-%dT00:00:00')
ontem_fim = (datetime.utcnow() - timedelta(days=1)).strftime('%Y-%m-%dT23:59:59')
r = client.get(f'/api/vendas?data_inicio={ontem}&data_fim={ontem_fim}', headers=headers)
print(f"Vendas de ontem: {len(r.json())} (esperado 0)")
assert len(r.json()) == 0

r = client.get('/api/vendas', headers=headers)
print(f"Vendas sem filtro: {len(r.json())} (esperado 2)")
assert len(r.json()) == 2

print("\n✅ TODOS OS TESTES DA FASE 1 PASSARAM")

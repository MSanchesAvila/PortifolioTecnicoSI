from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) GET /vendas (pagina)")
r = client.get('/vendas')
print(r.status_code, "tem 'Historico de vendas':", "Histórico de vendas" in r.text)

print("2) Cadastrar produto e fazer venda")
p = client.post('/api/produtos', json={'nome':'Case Aurora','preco_custo':12.5,'preco_venda':39.9,'quantidade_estoque':10}, headers=headers).json()
v = client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':2}]}, headers=headers).json()
print("Venda criada:", v['id'], "| Estoque apos venda deve ser 8")
r = client.get('/api/produtos', headers=headers)
print("Estoque atual:", r.json()[0]['quantidade_estoque'])

print("3) Listar vendas")
r = client.get('/api/vendas', headers=headers)
print(r.status_code, len(r.json()), "vendas")

print("4) Excluir a venda (deve devolver estoque)")
r = client.delete(f"/api/vendas/{v['id']}", headers=headers)
print(r.status_code, r.json())

print("5) Conferir que o estoque voltou pra 10")
r = client.get('/api/produtos', headers=headers)
print("Estoque apos exclusao:", r.json()[0]['quantidade_estoque'])
assert r.json()[0]['quantidade_estoque'] == 10

print("6) Conferir que a venda sumiu da lista")
r = client.get('/api/vendas', headers=headers)
print(r.status_code, len(r.json()), "vendas (deveria ser 0)")

print("7) Atendente tentando excluir venda (deve bloquear)")
v2 = client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=headers).json()
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.delete(f"/api/vendas/{v2['id']}", headers=headers_a)
print(r.status_code, r.json())

print("\n✅ TODOS OS TESTES PASSARAM")

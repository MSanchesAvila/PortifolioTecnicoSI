from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

print("1) Login com senha padrao")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
print(r.status_code)
token = r.json()['access_token']
headers = {'Authorization': f'Bearer {token}'}

print("2) Tentando trocar com senha ATUAL errada (deve bloquear)")
r = client.patch('/api/auth/me/senha', json={'senha_atual': 'errada', 'senha_nova': 'novaSenha123'}, headers=headers)
print(r.status_code, r.json())

print("3) Tentando trocar pra senha curta (deve bloquear)")
r = client.patch('/api/auth/me/senha', json={'senha_atual': 'royalcases123', 'senha_nova': '123'}, headers=headers)
print(r.status_code, r.json())

print("4) Trocando a senha corretamente")
r = client.patch('/api/auth/me/senha', json={'senha_atual': 'royalcases123', 'senha_nova': 'NovaSenh@Segura2026'}, headers=headers)
print(r.status_code, r.json())

print("5) Login com a senha ANTIGA (deve falhar agora)")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
print(r.status_code, r.json())

print("6) Login com a senha NOVA (deve funcionar)")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'NovaSenh@Segura2026'})
print(r.status_code, r.json()['perfil'] if r.status_code == 200 else r.json())

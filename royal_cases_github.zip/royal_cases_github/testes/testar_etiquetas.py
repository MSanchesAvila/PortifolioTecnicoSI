from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Etiqueta individual - novo formato (nome/valor passados)")
p1 = client.post('/api/produtos', json={'nome':'Case Aurora Premium','preco_custo':10,'preco_venda':39.9,'quantidade_estoque':10}, headers=headers).json()
r = client.get(f"/api/produtos/{p1['id']}/etiqueta", headers=headers)
print(r.status_code, "tamanho:", len(r.content), "bytes")
assert r.status_code == 200

print()
print("2) Configuracao padrao da folha")
r = client.get('/api/etiquetas/configuracao-padrao', headers=headers)
print(r.status_code, r.json())
assert r.json()['colunas'] == 5
assert r.json()['linhas'] == 13

print()
print("3) Gerar folha com poucos produtos (1 pagina)")
p2 = client.post('/api/produtos', json={'nome':'Pelicula Hidrogel','preco_custo':4,'preco_venda':24.9,'quantidade_estoque':20}, headers=headers).json()
r = client.post('/api/etiquetas/gerar-folha', json={
    'itens': [{'produto_id': p1['id'], 'quantidade': 3}, {'produto_id': p2['id'], 'quantidade': 2}]
}, headers=headers)
print(r.status_code, "Content-Type:", r.headers['content-type'], "Tamanho:", len(r.content), "bytes")
assert r.status_code == 200
assert r.headers['content-type'] == 'application/pdf'
with open('/tmp/teste_folha_1pagina.pdf', 'wb') as f:
    f.write(r.content)

print()
print("4) Gerar folha com MAIS de 65 etiquetas (deve gerar 2 paginas)")
r = client.post('/api/etiquetas/gerar-folha', json={
    'itens': [{'produto_id': p1['id'], 'quantidade': 65}, {'produto_id': p2['id'], 'quantidade': 10}]
}, headers=headers)
print(r.status_code, "Tamanho:", len(r.content), "bytes (deve ser maior, 2 paginas)")
with open('/tmp/teste_folha_2paginas.pdf', 'wb') as f:
    f.write(r.content)

# Conferir numero de paginas no PDF gerado
import subprocess
resultado = subprocess.run(['python3', '-c', '''
import PyPDF2
with open("/tmp/teste_folha_2paginas.pdf", "rb") as f:
    leitor = PyPDF2.PdfReader(f)
    print("Paginas:", len(leitor.pages))
'''], capture_output=True, text=True)
print(resultado.stdout, resultado.stderr)

print()
print("5) Produto invalido deve bloquear")
r = client.post('/api/etiquetas/gerar-folha', json={'itens': [{'produto_id': 9999, 'quantidade': 1}]}, headers=headers)
print(r.status_code, r.json())

print()
print("6) Lista vazia deve bloquear")
r = client.post('/api/etiquetas/gerar-folha', json={'itens': []}, headers=headers)
print(r.status_code, r.json())

print()
print("7) Produto com preco promocional usa o valor promocional na etiqueta")
p3 = client.post('/api/produtos', json={'nome':'Case Premium','preco_custo':10,'preco_venda':50,'preco_promocional':35,'quantidade_estoque':5}, headers=headers).json()
r = client.post('/api/etiquetas/gerar-folha', json={'itens': [{'produto_id': p3['id'], 'quantidade': 1}]}, headers=headers)
print(r.status_code, "gerado com sucesso (preco promocional aplicado)")

print("\n✅ TODOS OS TESTES DE ETIQUETAS PASSARAM")

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

print("1) Sistema subiu (lifespan deve ter rodado 1 backup na subida)")
import os
pasta = "/home/claude/royal_cases/backups"
print("Pasta backups existe?", os.path.exists(pasta))
if os.path.exists(pasta):
    print("Arquivos:", os.listdir(pasta))

print()
print("2) Login gestor")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
token = r.json()['access_token']
headers = {'Authorization': f'Bearer {token}'}

print()
print("3) Forcar backup manual via endpoint")
r = client.post('/api/sistema/backup-agora', headers=headers)
print(r.status_code, r.json())

print()
print("4) Atendente tentando forcar backup (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ze','login':'ze','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login': 'ze', 'senha': '123456'})
token_a = r.json()['access_token']
r = client.post('/api/sistema/backup-agora', headers={'Authorization': f'Bearer {token_a}'})
print(r.status_code, r.json())

print()
print("5) Conferindo arquivos de backup gerados")
print(sorted(os.listdir(pasta)))

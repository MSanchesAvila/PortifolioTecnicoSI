from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

p1 = client.post('/api/produtos', json={'nome':'Case Aurora','preco_custo':10,'preco_venda':30,'quantidade_estoque':10}, headers=headers).json()
p2 = client.post('/api/produtos', json={'nome':'Pelicula','preco_custo':4,'preco_venda':20,'quantidade_estoque':20}, headers=headers).json()
cli = client.post('/api/clientes', json={'nome': 'Ana Souza'}, headers=headers).json()

print("1) Pausar venda vazia deve bloquear")
r = client.post('/api/comandas', json={'identificador': 'Mesa 1', 'itens': []}, headers=headers)
print(r.status_code, "(esperado 400)")

print()
print("2) Pausar uma venda de verdade")
r = client.post('/api/comandas', json={
    'identificador': 'Mesa 3', 'cliente_id': cli['id'],
    'itens': [{'produto_id': p1['id'], 'quantidade': 2}, {'produto_id': p2['id'], 'quantidade': 1}]
}, headers=headers)
print(r.status_code, r.json())
comanda_id = r.json()['id']

print()
print("3) Confirmar que o estoque NAO foi mexido so por pausar")
r = client.get('/api/produtos', headers=headers)
estoques = {p['nome']: p['quantidade_estoque'] for p in r.json()}
print(estoques)
assert estoques['Case Aurora'] == 10
assert estoques['Pelicula'] == 20

print()
print("4) Listar comandas em aberto")
r = client.get('/api/comandas', headers=headers)
print(r.status_code, r.json())
assert len(r.json()) == 1

print()
print("5) Detalhar a comanda pra retomar (deve trazer nome/preco atual dos produtos)")
r = client.get(f'/api/comandas/{comanda_id}', headers=headers)
print(r.status_code, r.json())
assert len(r.json()['itens']) == 2

print()
print("6) Finalizar a venda de verdade (fluxo normal) e SO ENTAO excluir a comanda")
r = client.post('/api/vendas', json={
    'cliente_id': cli['id'], 'forma_pagamento': 'pix', 'numero_parcelas': 1, 'taxa_assumida_por': 'loja',
    'itens': [{'produto_id': p1['id'], 'quantidade': 2}, {'produto_id': p2['id'], 'quantidade': 1}]
}, headers=headers)
print("Venda finalizada:", r.status_code)
r = client.delete(f'/api/comandas/{comanda_id}', headers=headers)
print("Comanda removida:", r.status_code, r.json())

print()
print("7) Confirmar que o estoque baixou (so agora, na venda de verdade)")
r = client.get('/api/produtos', headers=headers)
estoques = {p['nome']: p['quantidade_estoque'] for p in r.json()}
print(estoques)
assert estoques['Case Aurora'] == 8
assert estoques['Pelicula'] == 19

print()
print("8) Lista de comandas deve estar vazia de novo")
r = client.get('/api/comandas', headers=headers)
print(r.status_code, r.json())
assert len(r.json()) == 0

print()
print("9) Comanda com produto que foi desativado depois - detalhe nao deve quebrar")
r = client.post('/api/comandas', json={'identificador': 'Balcao', 'itens': [{'produto_id': p1['id'], 'quantidade': 1}]}, headers=headers)
comanda2_id = r.json()['id']
client.put(f"/api/produtos/{p1['id']}", json={'ativo': False}, headers=headers)
r = client.get(f'/api/comandas/{comanda2_id}', headers=headers)
print(r.status_code, r.json())
assert len(r.json()['itens']) == 0

print("\n✅ TODOS OS TESTES DE COMANDA PASSARAM")

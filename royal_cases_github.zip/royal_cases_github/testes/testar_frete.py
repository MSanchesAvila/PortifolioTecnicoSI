from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Cadastrar regiao de entrega")
regiao = client.post('/api/regioes-entrega', json={'nome': 'Centro', 'valor_frete': 8.0}, headers=headers).json()
print(regiao)

print()
print("2) Atendente sem gestor tentando cadastrar regiao (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana3@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.post('/api/regioes-entrega', json={'nome': 'Zona Norte', 'valor_frete': 15.0}, headers=headers_a)
print(r.status_code, "(esperado 403)")

print()
print("3) Venda SEM frete (comportamento normal, nao deve mudar nada)")
p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':50,'quantidade_estoque':10}, headers=headers).json()
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("valor_cobrado:", v['valor_cobrado_cliente'], "| valor_frete_aplicado:", v['valor_frete_aplicado'])
assert v['valor_cobrado_cliente'] == 50.0
assert v['valor_frete_aplicado'] == 0.0

print()
print("4) Venda COM frete, CLIENTE assume (soma ao total)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("valor_cobrado:", v['valor_cobrado_cliente'], "| valor_recebido_loja:", v['valor_recebido_loja'], "| frete:", v['valor_frete_aplicado'])
assert v['valor_cobrado_cliente'] == 58.0  # 50 + 8 de frete
assert v['valor_recebido_loja'] == 50.0    # loja recebe o valor cheio dos produtos

print()
print("5) Venda COM frete, LOJA assume (gratis pro cliente, loja perde margem)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'loja',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
v = r.json()
print("valor_cobrado:", v['valor_cobrado_cliente'], "| valor_recebido_loja:", v['valor_recebido_loja'], "| lucro:", v['lucro_total'])
assert v['valor_cobrado_cliente'] == 50.0  # cliente paga so o produto
assert v['valor_recebido_loja'] == 42.0    # 50 - 8 de frete que a loja assumiu

print()
print("6) regiao_entrega_id informado SEM frete_assumido_por deve bloquear")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'],
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, r.json())

print()
print("7) Regiao invalida/desativada deve bloquear")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': 999, 'frete_assumido_por': 'cliente',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers)
print(r.status_code, r.json())

print()
print("8) Atendente ve valor_frete_aplicado mas NAO ve lucro (visao restrita, mesmo padrao de sempre)")
r = client.post('/api/vendas', json={
    'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja',
    'regiao_entrega_id': regiao['id'], 'frete_assumido_por': 'cliente',
    'itens':[{'produto_id':p['id'],'quantidade':1}]
}, headers=headers_a)
v = r.json()
print(list(v.keys()))
assert 'valor_frete_aplicado' in v
assert 'lucro_total' not in v

print("\n✅ TODOS OS TESTES DE FRETE PASSARAM")

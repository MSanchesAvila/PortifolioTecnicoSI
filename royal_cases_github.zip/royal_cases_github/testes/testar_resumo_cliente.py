from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

cli = client.post('/api/clientes', json={'nome': 'Ana Souza', 'telefone': '11988887777'}, headers=headers).json()
p1 = client.post('/api/produtos', json={'nome':'Case Aurora','preco_custo':12.5,'preco_venda':39.9,'quantidade_estoque':10}, headers=headers).json()
p2 = client.post('/api/produtos', json={'nome':'Pelicula','preco_custo':4,'preco_venda':24.9,'quantidade_estoque':10}, headers=headers).json()

print("1) Cliente SEM compras ainda")
r = client.get(f"/api/clientes/{cli['id']}/resumo", headers=headers)
print(r.status_code, r.json())

print("2) Fazendo 2 vendas pro mesmo cliente (Case Aurora comprado mais vezes)")
client.post('/api/vendas', json={'cliente_id': cli['id'], 'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p1['id'],'quantidade':2},{'produto_id':p2['id'],'quantidade':1}]}, headers=headers)
client.post('/api/vendas', json={'cliente_id': cli['id'], 'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p1['id'],'quantidade':1}]}, headers=headers)

print("3) Resumo do cliente agora")
r = client.get(f"/api/clientes/{cli['id']}/resumo", headers=headers)
resumo = r.json()
print(r.status_code, resumo)
assert resumo['status'] == 'ativo'
assert resumo['produtos_favoritos'][0]['nome'] == 'Case Aurora'
assert resumo['produtos_favoritos'][0]['quantidade_total'] == 3

print("\n✅ TODOS OS TESTES PASSARAM")

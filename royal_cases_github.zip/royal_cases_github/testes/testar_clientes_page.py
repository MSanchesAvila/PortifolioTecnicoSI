from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

print("1) Login do gestor inicial")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
print(r.status_code, r.json())
token_gestor = r.json()['access_token']
headers_gestor = {'Authorization': f'Bearer {token_gestor}'}

print()
print("2) GET /clientes (pagina HTML)")
r = client.get('/clientes')
print(r.status_code, "| tem 'Novo cliente':", "Novo cliente" in r.text)

print()
print("3) Criar cliente via API /api/clientes")
r = client.post('/api/clientes', json={'nome': 'Bruno Costa', 'telefone': '11955554444'}, headers=headers_gestor)
print(r.status_code, r.json())

print()
print("4) Listar usuarios (gestor)")
r = client.get('/api/auth/usuarios', headers=headers_gestor)
print(r.status_code, r.json())

print()
print("5) Criar atendente")
r = client.post('/api/auth/usuarios', json={'nome': 'Joana Atendente', 'login': 'joana', 'senha': '123456', 'perfil': 'atendente'}, headers=headers_gestor)
print(r.status_code, r.json())
joana_id = r.json()['id']

print()
print("6) Atendente tentando listar usuarios (deve BLOQUEAR)")
r = client.post('/api/auth/login', json={'login': 'joana', 'senha': '123456'})
token_atendente = r.json()['access_token']
headers_atendente = {'Authorization': f'Bearer {token_atendente}'}
r = client.get('/api/auth/usuarios', headers=headers_atendente)
print(r.status_code, r.json())

print()
print("7) Gestor desativa a Joana")
r = client.patch(f'/api/auth/usuarios/{joana_id}/alternar-ativo', headers=headers_gestor)
print(r.status_code, r.json())

print()
print("8) Joana tenta logar de novo (deve falhar - inativa)")
r = client.post('/api/auth/login', json={'login': 'joana', 'senha': '123456'})
print(r.status_code, r.json())

print()
print("9) Gestor tenta desativar A SI MESMO (deve bloquear)")
r = client.patch(f'/api/auth/usuarios/1/alternar-ativo', headers=headers_gestor)
print(r.status_code, r.json())

print()
print("10) Verificando que rotas antigas sem /api NAO existem mais (produtos)")
r = client.get('/produtos', headers=headers_gestor)
print(r.status_code, "(esperado 404, pois produtos migrou pra /api/produtos)")

from fastapi.testclient import TestClient
from app.main import app
import json
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Cadastrar fornecedor")
f = client.post('/api/fornecedores', json={'nome': 'Distribuidora XYZ', 'telefone': '11988887777', 'cnpj': '12.345.678/0001-99'}, headers=headers).json()
print(f)

print()
print("2) Cadastrar produto com variacao e fornecedor vinculado")
p1 = client.post('/api/produtos', json={
    'nome': 'Case Aurora', 'preco_custo': 12.5, 'preco_venda': 39.9, 'quantidade_estoque': 10,
    'fornecedor_id': f['id'], 'grupo_variacao': 'Case Aurora', 'variacao': 'Azul - M'
}, headers=headers).json()
print(p1)
assert p1['grupo_variacao'] == 'Case Aurora'
assert p1['variacao'] == 'Azul - M'
assert p1['fornecedor_id'] == f['id']

print()
print("3) Cadastrar uma segunda variacao (mesma grade, cor diferente)")
p2 = client.post('/api/produtos', json={
    'nome': 'Case Aurora', 'preco_custo': 12.5, 'preco_venda': 39.9, 'quantidade_estoque': 8,
    'fornecedor_id': f['id'], 'grupo_variacao': 'Case Aurora', 'variacao': 'Vermelho - M'
}, headers=headers).json()
print(p2)

print()
print("4) Listar produtos do fornecedor")
r = client.get(f"/api/fornecedores/{f['id']}/produtos", headers=headers)
print(r.status_code, r.json())
assert len(r.json()) == 2

print()
print("5) Exportar backup")
r = client.get('/api/sistema/exportar-backup', headers=headers)
dados_export = json.loads(r.content)
print("Produtos exportados:", len(dados_export['produtos']))
assert dados_export['produtos'][0]['grupo_variacao'] == 'Case Aurora'

print()
print("6) Restaurar o MESMO backup (deve so ATUALIZAR, nao duplicar)")
import io
arquivo = io.BytesIO(json.dumps(dados_export).encode())
r = client.post('/api/sistema/importar-backup', files={'arquivo': ('backup.json', arquivo, 'application/json')}, headers=headers)
print(r.status_code, r.json())
assert r.json()['produtos_atualizados'] == 2
assert r.json()['produtos_criados'] == 0

r = client.get('/api/produtos', headers=headers)
print("Total de produtos apos restaurar (nao deveria ter duplicado):", len(r.json()))
assert len(r.json()) == 2

print()
print("7) Atendente sem permissao tentando restaurar backup (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana2@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
arquivo2 = io.BytesIO(json.dumps(dados_export).encode())
r = client.post('/api/sistema/importar-backup', files={'arquivo': ('backup.json', arquivo2, 'application/json')}, headers=headers_a)
print(r.status_code, "(esperado 403)")

print("\n✅ TODOS OS TESTES DA FASE 3A PASSARAM")

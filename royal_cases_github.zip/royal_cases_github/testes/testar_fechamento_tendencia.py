from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':30,'quantidade_estoque':20}, headers=headers).json()
client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=headers)
client.post('/api/vendas', json={'forma_pagamento':'dinheiro','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':2}]}, headers=headers)
client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=headers)

print("1) Fechamento de caixa de hoje")
r = client.get('/api/dashboard/fechamento-caixa', headers=headers)
print(r.status_code, r.json())
assert r.json()['por_forma_pagamento']['pix']['quantidade'] == 2
assert r.json()['por_forma_pagamento']['dinheiro']['quantidade'] == 1
assert r.json()['quantidade_vendas'] == 3

print()
print("2) Tendencia dos ultimos 7 dias")
r = client.get('/api/dashboard/tendencia?dias=7', headers=headers)
dados = r.json()
print(r.status_code, "dias retornados:", len(dados))
assert len(dados) == 7
print("Ultimo dia (hoje):", dados[-1])
assert dados[-1]['faturamento'] > 0

print()
print("3) Atendente sem permissao tentando acessar (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.get('/api/dashboard/fechamento-caixa', headers=headers_a)
print(r.status_code, "(esperado 403)")

print("\n✅ TODOS OS TESTES PASSARAM")

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def login(usr, senha):
    r = client.post('/api/auth/login', json={'login': usr, 'senha': senha})
    return {'Authorization': f"Bearer {r.json()['access_token']}"}

hg = login('admin', 'royalcases123')

print("1) Gestor cria atendente SEM nenhuma permissao extra")
r = client.post('/api/auth/usuarios', json={'nome':'Carla','login':'carla','senha':'123456','perfil':'atendente'}, headers=hg)
print(r.status_code, r.json())

ha = login('carla', '123456')

print()
print("2) Carla tenta cadastrar produto (deve BLOQUEAR - sem permissao)")
r = client.post('/api/produtos', json={'nome':'X','preco_custo':1,'preco_venda':2,'quantidade_estoque':1}, headers=ha)
print(r.status_code, r.json())

print()
print("3) Carla lista produtos (deve vir SEM custo, pois nao tem 'produtos.ver_custo')")
client.post('/api/produtos', json={'nome':'Case Aurora','preco_custo':12.5,'preco_venda':39.9,'quantidade_estoque':10}, headers=hg)
r = client.get('/api/produtos', headers=ha)
print(r.status_code, r.json())

print()
print("4) Gestor concede 'produtos.cadastrar' e 'produtos.ver_custo' pra Carla")
r = client.get('/api/auth/usuarios', headers=hg)
carla_id = [u for u in r.json() if u['login'] == 'carla'][0]['id']
r = client.put(f'/api/auth/usuarios/{carla_id}/permissoes', json={'permissoes': ['produtos.cadastrar', 'produtos.ver_custo']}, headers=hg)
print(r.status_code, r.json())

print()
print("5) Carla tenta cadastrar produto de novo (AGORA deve funcionar, sem precisar logar de novo!)")
r = client.post('/api/produtos', json={'nome':'Pelicula','preco_custo':4,'preco_venda':24.9,'quantidade_estoque':5}, headers=ha)
print(r.status_code, r.json())

print()
print("6) Carla lista produtos (AGORA deve vir COM custo)")
r = client.get('/api/produtos', headers=ha)
print(r.status_code, r.json())

print()
print("7) Carla ainda NAO pode ver dashboard (nao tem essa permissao)")
r = client.get('/api/dashboard/faturamento', headers=ha)
print(r.status_code, r.json())

print()
print("8) Gestor revoga 'produtos.cadastrar' da Carla")
r = client.put(f'/api/auth/usuarios/{carla_id}/permissoes', json={'permissoes': ['produtos.ver_custo']}, headers=hg)
print(r.status_code, r.json())

print()
print("9) Carla tenta cadastrar produto de novo (deve BLOQUEAR - foi revogado)")
r = client.post('/api/produtos', json={'nome':'Cabo','preco_custo':5,'preco_venda':15,'quantidade_estoque':3}, headers=ha)
print(r.status_code, r.json())

print()
print("10) Carla com 'usuarios.gerenciar'? Testando escalada de privilegio: tenta criar um GESTOR")
r = client.put(f'/api/auth/usuarios/{carla_id}/permissoes', json={'permissoes': ['usuarios.gerenciar']}, headers=hg)
print("permissao concedida:", r.status_code)
ha = login('carla', '123456')  # relogar so pra pegar token atualizado (perfil nao mudou, mas por clareza)
r = client.post('/api/auth/usuarios', json={'nome':'Fake Gestor','login':'fake','senha':'123456','perfil':'gestor'}, headers=ha)
print("tentando criar GESTOR:", r.status_code, r.json())
r = client.post('/api/auth/usuarios', json={'nome':'Atendente Legitimo','login':'legit','senha':'123456','perfil':'atendente'}, headers=ha)
print("criando ATENDENTE (deve funcionar):", r.status_code, r.json())

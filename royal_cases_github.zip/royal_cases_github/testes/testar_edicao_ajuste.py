from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Cadastrar produto e editar (corrigir preco errado)")
p = client.post('/api/produtos', json={'nome':'Case Aurroa','preco_custo':12.5,'preco_venda':39.9,'quantidade_estoque':10}, headers=headers).json()
r = client.put(f"/api/produtos/{p['id']}", json={'nome': 'Case Aurora', 'preco_venda': 44.9}, headers=headers)
print(r.status_code, r.json())
assert r.json()['nome'] == 'Case Aurora'
assert r.json()['preco_venda'] == 44.9
assert r.json()['preco_custo'] == 12.5, "custo nao deveria mudar, nao foi enviado no PUT"
assert r.json()['quantidade_estoque'] == 10, "estoque nao deveria mudar via PUT"

print()
print("2) Ajustar estoque (chegada de mercadoria, +20)")
r = client.post(f"/api/produtos/{p['id']}/ajustar-estoque", json={'quantidade_delta': 20, 'motivo': 'Reposicao do fornecedor'}, headers=headers)
print(r.status_code, "Estoque agora:", r.json()['quantidade_estoque'])
assert r.json()['quantidade_estoque'] == 30

print()
print("3) Ajustar estoque removendo (produto danificado, -5)")
r = client.post(f"/api/produtos/{p['id']}/ajustar-estoque", json={'quantidade_delta': -5, 'motivo': 'Produto danificado'}, headers=headers)
print(r.status_code, "Estoque agora:", r.json()['quantidade_estoque'])
assert r.json()['quantidade_estoque'] == 25

print()
print("4) Ajuste que deixaria negativo deve ser bloqueado")
r = client.post(f"/api/produtos/{p['id']}/ajustar-estoque", json={'quantidade_delta': -999, 'motivo': 'Teste'}, headers=headers)
print(r.status_code, r.json())

print()
print("5) Ajuste sem motivo deve ser bloqueado (validacao)")
r = client.post(f"/api/produtos/{p['id']}/ajustar-estoque", json={'quantidade_delta': 5, 'motivo': 'ab'}, headers=headers)
print(r.status_code, "(esperado 422, motivo muito curto)")

print()
print("6) Atendente sem permissao tentando editar produto (deve bloquear)")
client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.put(f"/api/produtos/{p['id']}", json={'nome': 'Hackeado'}, headers=headers_a)
print(r.status_code, r.json())

print()
print("7) Cadastrar cliente e editar telefone")
cli = client.post('/api/clientes', json={'nome': 'Ana Souza', 'telefone': '11999998888'}, headers=headers).json()
r = client.put(f"/api/clientes/{cli['id']}", json={'telefone': '11988887777'}, headers=headers)
print(r.status_code, r.json())
assert r.json()['telefone'] == '11988887777'
assert r.json()['nome'] == 'Ana Souza', "nome nao deveria mudar, nao foi enviado"

print()
print("8) Editar cliente pra um CPF que ja existe em outro cliente (deve bloquear)")
cli2 = client.post('/api/clientes', json={'nome': 'Bruno', 'cpf': '11122233344'}, headers=headers).json()
r = client.put(f"/api/clientes/{cli['id']}", json={'cpf': '11122233344'}, headers=headers)
print(r.status_code, r.json())

print("\n✅ TODOS OS TESTES PASSARAM")

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Validacao: preco negativo deve ser bloqueado")
r = client.post('/api/produtos', json={'nome':'X','preco_custo':-5,'preco_venda':10,'quantidade_estoque':1}, headers=headers)
print(r.status_code, "(esperado 422)")

print("2) Validacao: quantidade zero/negativa numa venda deve ser bloqueada")
p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':20,'quantidade_estoque':5}, headers=headers).json()
r = client.post('/api/vendas', json={'forma_pagamento':'pix','numero_parcelas':1,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':-3}]}, headers=headers)
print(r.status_code, "(esperado 422)")

print("3) Validacao: numero_parcelas fora de 1-12 deve ser bloqueado")
r = client.post('/api/vendas', json={'forma_pagamento':'cartao_credito','numero_parcelas':50,'taxa_assumida_por':'loja','itens':[{'produto_id':p['id'],'quantidade':1}]}, headers=headers)
print(r.status_code, "(esperado 422)")

print("4) Usuario DESATIVADO nao consegue mais usar o token que ja tinha")
client.post('/api/auth/usuarios', json={'nome':'Bia','login':'bia','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login': 'bia', 'senha': '123456'})
token_bia = r.json()['access_token']
headers_bia = {'Authorization': f'Bearer {token_bia}'}
r = client.get('/api/produtos', headers=headers_bia)
print("Antes de desativar:", r.status_code, "(esperado 200)")

usuarios = client.get('/api/auth/usuarios', headers=headers).json()
bia_id = [u for u in usuarios if u['login'] == 'bia'][0]['id']
client.patch(f'/api/auth/usuarios/{bia_id}/alternar-ativo', headers=headers)

r = client.get('/api/produtos', headers=headers_bia)
print("Depois de desativar, MESMO TOKEN de antes:", r.status_code, "(esperado 401)")

print("5) Rate limiting: 6 logins errados seguidos devem bloquear o 6o")
for i in range(6):
    r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'senhaerrada'})
    print(f"  tentativa {i+1}: {r.status_code}")
print("(as 5 primeiras devem ser 401, a 6a deve ser 429)")

print("\n✅ TODOS OS TESTES DE SEGURANCA EXECUTADOS")

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

print("1) Login gestor")
r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
token = r.json()['access_token']
headers = {'Authorization': f'Bearer {token}'}

print("2) GET /produtos (pagina)")
r = client.get('/produtos')
print(r.status_code, "tem 'Cadastrar produto':", "Cadastrar produto" in r.text)

print("3) GET /dashboard (pagina)")
r = client.get('/dashboard')
print(r.status_code, "tem 'Estoque baixo':", "Estoque baixo" in r.text)

print("4) Cadastrar produto via API e baixar etiqueta")
r = client.post('/api/produtos', json={'nome': 'Case Aurora', 'preco_custo': 12.5, 'preco_venda': 39.9, 'quantidade_estoque': 2, 'estoque_minimo': 5}, headers=headers)
produto = r.json()
print(r.status_code, produto)
r = client.get(f"/api/produtos/{produto['id']}/etiqueta", headers=headers)
print("etiqueta:", r.status_code, r.headers['content-type'], len(r.content), "bytes")

print("5) Registrar venda pra gerar dado no dashboard")
r = client.post('/api/vendas', json={'canal':'presencial','forma_pagamento':'pix','itens':[{'produto_id': produto['id'], 'quantidade': 1}]}, headers=headers)
print(r.status_code, r.json())

print("6) Dashboard - faturamento")
r = client.get('/api/dashboard/faturamento', headers=headers)
print(r.status_code, r.json())

print("7) Dashboard - estoque baixo (deve aparecer Case Aurora, ficou com 1, minimo 5)")
r = client.get('/api/dashboard/estoque-baixo', headers=headers)
print(r.status_code, r.json())

print("8) Dashboard - margem por produto")
r = client.get('/api/dashboard/margem-por-produto', headers=headers)
print(r.status_code, r.json())

print("9) Atendente tentando acessar pagina /dashboard (a pagina carrega, mas API bloqueia - JS redireciona)")
r = client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
token_a = r.json()['access_token']
headers_a = {'Authorization': f'Bearer {token_a}'}
r = client.get('/api/dashboard/faturamento', headers=headers_a)
print(r.status_code, r.json())

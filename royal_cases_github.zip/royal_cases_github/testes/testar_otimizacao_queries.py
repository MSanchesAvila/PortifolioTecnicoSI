from fastapi.testclient import TestClient
from app.main import app
from sqlalchemy import event
from app.database import engine
client = TestClient(app)

# Conta quantas queries SQL sao executadas de verdade
contador = {"queries": 0}
@event.listens_for(engine, "before_cursor_execute")
def contar(conn, cursor, statement, parameters, context, executemany):
    contador["queries"] += 1

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana6@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
client.put('/api/auth/usuarios/2/permissoes', json={'permissoes': ['produtos.cadastrar', 'produtos.ver_custo']}, headers=headers)
r = client.post('/api/auth/login', json={'login':'ana','senha':'123456'})
headers_a = {'Authorization': f"Bearer {r.json()['access_token']}"}

p = client.post('/api/produtos', json={'nome':'Case','preco_custo':10,'preco_venda':30,'quantidade_estoque':5}, headers=headers).json()

print("1) Testando ATENDENTE com permissao, listando produtos com incluir_inativos=true")
print("   (esse é o pior caso: exigir_permissao ja teria buscado 1x, e o endpoint faz mais 2 checagens)")
contador["queries"] = 0
r = client.get('/api/produtos?incluir_inativos=true', headers=headers_a)
print(f"   Queries SQL executadas: {contador['queries']}")
assert r.status_code == 200

print()
print("2) Confirma que a permissao ainda funciona corretamente (edicao de produto)")
r = client.put(f"/api/produtos/{p['id']}", json={'nome': 'Case Editado'}, headers=headers_a)
print(f"   Status: {r.status_code} (esperado 200, atendente TEM produtos.cadastrar)")
assert r.status_code == 200

print()
print("3) Atendente SEM permissao (usuario novo, sem nada liberado) deve continuar bloqueado")
client.post('/api/auth/usuarios', json={'nome':'Bia','login':'bia','email':'bia@teste.com','senha':'123456','perfil':'atendente'}, headers=headers)
r = client.post('/api/auth/login', json={'login':'bia','senha':'123456'})
headers_b = {'Authorization': f"Bearer {r.json()['access_token']}"}
r = client.put(f"/api/produtos/{p['id']}", json={'nome': 'Tentativa'}, headers=headers_b)
print(f"   Status: {r.status_code} (esperado 403)")
assert r.status_code == 403

print()
print("4) Usuario DESATIVADO continua bloqueado imediatamente (nao quebrou a seguranca)")
usuarios = client.get('/api/auth/usuarios', headers=headers).json()
bia_id = [u for u in usuarios if u['login'] == 'bia'][0]['id']
client.patch(f'/api/auth/usuarios/{bia_id}/alternar-ativo', headers=headers)
r = client.get('/api/produtos', headers=headers_b)
print(f"   Status: {r.status_code} (esperado 401)")
assert r.status_code == 401

print("\n✅ TODOS OS TESTES DE OTIMIZACAO PASSARAM (permissoes continuam corretas)")

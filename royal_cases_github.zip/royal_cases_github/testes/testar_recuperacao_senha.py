from fastapi.testclient import TestClient
from app.main import app
import re
client = TestClient(app)

r = client.post('/api/auth/login', json={'login': 'admin', 'senha': 'royalcases123'})
headers = {'Authorization': f"Bearer {r.json()['access_token']}"}

print("1) Admin edita o proprio perfil pra adicionar e-mail")
r = client.patch('/api/auth/me', json={'email': 'admin@royalcases.com'}, headers=headers)
print(r.status_code, r.json())
assert r.json()['email'] == 'admin@royalcases.com'

print()
print("2) Criar usuario SEM e-mail deve falhar (obrigatorio)")
r = client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','senha':'123456','perfil':'atendente'}, headers=headers)
print(r.status_code, "(esperado 422, falta email)")

print()
print("3) Criar usuario com e-mail duplicado deve falhar")
r = client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'admin@royalcases.com','senha':'123456','perfil':'atendente'}, headers=headers)
print(r.status_code, r.json())

print()
print("4) Criar usuario certo, com e-mail unico")
r = client.post('/api/auth/usuarios', json={'nome':'Ana','login':'ana','email':'ana@royalcases.com','senha':'123456','perfil':'atendente'}, headers=headers)
print(r.status_code, r.json())

print()
print("5) Esqueci senha - e-mail que EXISTE (sem SMTP configurado, mas resposta deve ser generica e nao quebrar)")
r = client.post('/api/auth/esqueci-senha', json={'email': 'ana@royalcases.com'})
print(r.status_code, r.json())

print()
print("6) Esqueci senha - e-mail que NAO EXISTE (resposta deve ser IDENTICA a anterior)")
r2 = client.post('/api/auth/esqueci-senha', json={'email': 'naoexiste@nada.com'})
print(r2.status_code, r2.json())
assert r.json() == r2.json(), "as respostas devem ser IDENTICAS pra nao revelar quais emails existem"
print("Respostas identicas: confirmado (protege contra enumeracao)")

print()
print("7) Gerar token manualmente pra testar o fluxo de redefinicao completo (sem depender de SMTP)")
from app.database import SessionLocal
from app.models import Usuario, RedefinicaoSenha
from app.auth_utils import gerar_token_redefinicao, hash_token_redefinicao
from datetime import datetime, timedelta

db = SessionLocal()
usuario_ana = db.query(Usuario).filter(Usuario.login == 'ana').first()
token = gerar_token_redefinicao()
redef = RedefinicaoSenha(usuario_id=usuario_ana.id, token_hash=hash_token_redefinicao(token), expira_em=datetime.utcnow() + timedelta(minutes=30))
db.add(redef)
db.commit()
db.close()

print("8) Redefinir com token valido")
r = client.post('/api/auth/redefinir-senha', json={'token': token, 'senha_nova': 'NovaSenh@Ana123'})
print(r.status_code, r.json())

print()
print("9) Login com a senha NOVA deve funcionar")
r = client.post('/api/auth/login', json={'login': 'ana', 'senha': 'NovaSenh@Ana123'})
print(r.status_code, "(esperado 200)")

print()
print("10) Tentar usar o MESMO token de novo deve falhar (uso unico)")
r = client.post('/api/auth/redefinir-senha', json={'token': token, 'senha_nova': 'OutraSenha123'})
print(r.status_code, r.json())

print()
print("11) Token invalido/inventado deve falhar")
r = client.post('/api/auth/redefinir-senha', json={'token': 'token-fake-inventado', 'senha_nova': 'Teste123'})
print(r.status_code, r.json())

print("\n✅ TODOS OS TESTES DE RECUPERACAO DE SENHA PASSARAM")
